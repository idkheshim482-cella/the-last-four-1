// LAST FOUR — render pipeline: shadowed forward rendering + an optional post chain
// (SSAO -> bloom -> SMAA -> output). The chain is rebuilt when the preset changes.

import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { SMAAPass } from "three/examples/jsm/postprocessing/SMAAPass.js";
import { GTAOPass } from "three/examples/jsm/postprocessing/GTAOPass.js";
import type { GfxPreset } from "./presets";

export class RenderPipeline {
  composer: EffectComposer | null = null;
  bloom: UnrealBloomPass | null = null;
  ao: GTAOPass | null = null;
  smaa: SMAAPass | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private preset: GfxPreset;

  constructor(scene: THREE.Scene, camera: THREE.PerspectiveCamera, renderer: THREE.WebGLRenderer, preset: GfxPreset) {
    this.scene = scene;
    this.camera = camera;
    this.renderer = renderer;
    this.preset = preset;
  }

  setPreset(p: GfxPreset) {
    this.preset = p;
    this.build();
  }

  build() {
    const p = this.preset;
    if (this.composer) { this.composer.dispose?.(); this.composer = null; }
    this.ao = null; this.bloom = null; this.smaa = null;
    if (!p.ambientOcclusion && !p.bloom && !p.smaa) return;   // LOW = raw forward render

    const size = this.renderer.getSize(new THREE.Vector2());
    const composer = new EffectComposer(this.renderer);
    composer.setSize(size.x, size.y);
    composer.setPixelRatio(this.renderer.getPixelRatio());
    composer.addPass(new RenderPass(this.scene, this.camera));

    if (p.ambientOcclusion) {
      try {
        const ao = new GTAOPass(this.scene, this.camera, size.x, size.y);
        ao.output = GTAOPass.OUTPUT.Default;
        ao.updateGtaoMaterial({
          radius: 0.6, distanceExponent: 1.4, thickness: 1.2,
          scale: 1.0, samples: p.id >= 3 ? 16 : 8,
          distanceFallOff: 1.0, screenSpaceRadius: false,
        });
        ao.blendIntensity = 0.85;
        composer.addPass(ao);
        this.ao = ao;
      } catch { /* GTAO unsupported on this device — carry on without it */ }
    }

    if (p.bloom) {
      const bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), p.bloomStrength, 0.75, 0.86);
      composer.addPass(bloom);
      this.bloom = bloom;
    }

    if (p.smaa) {
      try {
        const smaa = new SMAAPass();
        composer.addPass(smaa);
        this.smaa = smaa;
      } catch { /* ignore */ }
    }

    composer.addPass(new OutputPass());
    this.composer = composer;
  }

  setSize(w: number, h: number) {
    this.composer?.setSize(w, h);
    this.composer?.setPixelRatio(this.renderer.getPixelRatio());
    this.ao?.setSize(w, h);
    this.bloom?.setSize(w, h);
  }

  render() {
    if (this.composer) this.composer.render();
    else this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.composer?.dispose?.();
    this.composer = null;
  }
}
