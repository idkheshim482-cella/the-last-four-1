// Chapter 2 — "THE ESCAPE": exactly four missions.
// 1) RESCUE MISSION   — help Mina rescue her sister Astra from the pharmacy.
// 2) TOOLBOX RECOVERY — find Ravi's missing toolbox (minimart storeroom).
// 3) RADIO SIGNAL     — travel to the radio signal and find out if help is coming.
// 4) CLEAR THE WAY    — defeat the horde blocking the road to the boat.

export type MType = "kill" | "fetch" | "reach";

export interface MissionDef {
  id: number;
  title: string;
  giver: string;             // who gives it ("MINA" | "RAVI")
  type: MType;
  wp: { x: number; y: number; z: number; label: string };
  ret: { x: number; y: number; z: number; label: string } | null; // turn-in point
  need?: number;             // kill count
  area?: { x: number; z: number; r: number }; // kill zone
  item?: string;             // fetch: pickup kind
  brief: string;             // briefing dialogue
  done: string;              // turn-in dialogue
  reward: string;            // human readable reward
}

export const MISSIONS: MissionDef[] = [
  {
    id: 1, title: "RESCUE MISSION", giver: "MINA", type: "kill", need: 6,
    wp: { x: 78, y: 1.5, z: 22, label: "PHARMACY CROSSING" },
    ret: { x: 48, y: 1.5, z: 28, label: "RETURN TO MINA" },
    area: { x: 78, z: 22, r: 30 },
    brief: "You came out of the school?! Nobody comes out of there... I'm Mina. My little sister Astra is trapped in the pharmacy across the avenue — the crossing is crawling with infected. Clear them out and I'll get her out. Please. She's eleven.",
    done: "You got them? ...She's safe. I don't know what to say. Here — my dad's map of the city. Everything's marked: the safehouse, the garage, the harbor. Take it.",
    reward: "Astra rescued · City Map · 24 rounds",
  },
  {
    id: 2, title: "TOOLBOX RECOVERY", giver: "RAVI", type: "fetch", item: "toolbox",
    wp: { x: 49, y: 1.5, z: 37, label: "MINIMART STOREROOM" },
    ret: { x: 104, y: 1.5, z: 55, label: "RETURN TO RAVI" },
    brief: "Mina's runner, huh? Good. I need a favour before any boat leaves this city. My TOOLBOX — the big red one — got dragged off by looters into the minimart storeroom by the gas station. Bring it back and every set of wheels out there is yours. Cars, bikes, all of it.",
    done: "My tools! Give me two minutes... aand done. Jump pack's charged, tyres are good. Sedans, my bike, the sports car — they're yours now. One more thing: the harbor's broadcasting a signal. Someone's still out there.",
    reward: "All vehicles unlocked",
  },
  {
    id: 3, title: "RADIO SIGNAL", giver: "RAVI", type: "reach",
    wp: { x: 68, y: 1.5, z: -60, label: "BROADCAST VAN — STREET C" },
    ret: null,
    brief: "Listen. The harbor's been repeating the same broadcast for two days: a rescue boat, a pickup point, a schedule. But the signal's been drifting. There's a news van at the Street C junction — if its transmitter still works we can hear the real one. Find out if help's actually coming.",
    done: "There it is. 'Evacuees report to the harbor pier. Departure is final.' A boat IS coming — but the message says the pier's under heavy contact. The route east is crawling with them. We'll need a clean road to get there.",
    reward: "Evac confirmed · 5.56 ammo",
  },
  {
    id: 4, title: "CLEAR THE WAY", giver: "MINA", type: "kill", need: 12,
    wp: { x: 235, y: 1.5, z: 53, label: "THE ROAD TO THE HARBOR" },
    ret: null,
    area: { x: 235, z: 53, r: 42 },
    brief: "Mina: The road to the pier is blocked. Not a few of them — a horde. Twelve at least, and more coming down from the hospital road. If the boat's coming, it's coming to that gate, and we cannot let them own it. Clear the way and the pier's ours.",
    done: "That's it — the road's open! The boat's spotted us. Everybody MOVE!",
    reward: "The road is clear — the last boat is waiting",
  },
];

export function prereqs(id: number): number[] {
  switch (id) {
    case 1: return [];
    case 2: return [1];
    case 3: return [2];
    case 4: return [3];
    default: return [];
  }
}
