// LAST FOUR — PBR material + procedural texture foundry.
// Every surface in the game is generated here: albedo + normal + roughness maps,
// authored at load time so there are zero image files to ship.

import * as THREE from "three";

export interface TexSet {
  map: THREE.Texture;
  normalMap?: THREE.Texture;
  roughnessMap?: THREE.Texture;
  aoMap?: THREE.Texture;
  repeat?: number;
}

/** Apply the same world-scale repeat to every map in the set. */
export function setRepeat(set: TexSet, rep: number) {
  for (const t of [set.map, set.normalMap, set.roughnessMap]) if (t) t.repeat.set(rep, rep);
  return set;
}

const cache = new Map<string, TexSet>();

function cnv(size = 256) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  return { c, g: c.getContext("2d")! };
}

function toTex(c: HTMLCanvasElement, rep = 1, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rep, rep);
  t.anisotropy = 4;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Derive a normal map from a height field (Sobel). */
function normalFromHeight(height: Float32Array, size: number, strength: number): THREE.Texture {
  const { c, g } = cnv(size);
  const img = g.createImageData(size, size);
  const at = (x: number, y: number) => height[((y + size) % size) * size + ((x + size) % size)];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (at(x + 1, y) - at(x - 1, y)) * strength;
      const dy = (at(x, y + 1) - at(x, y - 1)) * strength;
      let nx = -dx, ny = -dy, nz = 1;
      const l = Math.hypot(nx, ny, nz);
      nx /= l; ny /= l; nz /= l;
      const i = (y * size + x) * 4;
      img.data[i] = (nx * 0.5 + 0.5) * 255;
      img.data[i + 1] = (ny * 0.5 + 0.5) * 255;
      img.data[i + 2] = (nz * 0.5 + 0.5) * 255;
      img.data[i + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  return toTex(c, 1, false);
}

/** Greyscale roughness map from a height field. */
function roughFromHeight(height: Float32Array, size: number, base: number, range: number): THREE.Texture {
  const { c, g } = cnv(size);
  const img = g.createImageData(size, size);
  for (let i = 0; i < height.length; i++) {
    const v = Math.max(0, Math.min(255, (base + (1 - height[i]) * range) * 255));
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = v;
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return toTex(c, 1, false);
}

function noiseField(size: number, octaves: number, seed: number): Float32Array {
  const f = new Float32Array(size * size);
  let amp = 1, total = 0;
  for (let o = 0; o < octaves; o++) {
    const cells = 2 << o;
    const grid = new Float32Array((cells + 1) * (cells + 1));
    for (let i = 0; i < grid.length; i++) {
      const s = Math.sin((i + seed * 97 + o * 31) * 12.9898) * 43758.5453;
      grid[i] = s - Math.floor(s);
    }
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const fx = (x / size) * cells, fy = (y / size) * cells;
        const x0 = Math.floor(fx), y0 = Math.floor(fy);
        const tx = fx - x0, ty = fy - y0;
        const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
        const g = (a: number, b: number) => grid[b * (cells + 1) + a];
        const v = (g(x0, y0) * (1 - sx) + g(x0 + 1, y0) * sx) * (1 - sy) + (g(x0, y0 + 1) * (1 - sx) + g(x0 + 1, y0 + 1) * sx) * sy;
        f[y * size + x] += v * amp;
      }
    }
    total += amp;
    amp *= 0.5;
  }
  for (let i = 0; i < f.length; i++) f[i] /= total;
  return f;
}

/** Weathered concrete: aggregate, cracks, stains, water streaks. */
export function concreteSet(rep = 2, tint = "#a3a09a"): TexSet {
  const key = `concrete${rep}${tint}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 5, 7);
  const img = g.createImageData(size, size);
  const base = new THREE.Color(tint);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const nv = n[i];
      // aggregate speckle
      const sp = ((Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1 + 1) % 1;
      let v = 0.78 + nv * 0.3 + (sp > 0.96 ? 0.16 : 0) - (sp < 0.04 ? 0.12 : 0);
      h[i] = nv * 0.7 + (sp > 0.96 ? 0.3 : 0);
      const dirt = Math.max(0, nv - 0.55) * 0.9;
      const r = base.r * v * (1 - dirt * 0.45);
      const gg = base.g * v * (1 - dirt * 0.5);
      const b = base.b * v * (1 - dirt * 0.55);
      img.data[i * 4] = Math.min(255, r * 255);
      img.data[i * 4 + 1] = Math.min(255, gg * 255);
      img.data[i * 4 + 2] = Math.min(255, b * 255);
      img.data[i * 4 + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  // cracks
  g.strokeStyle = "rgba(35,32,30,0.55)";
  for (let k = 0; k < 10; k++) {
    g.lineWidth = 0.6 + Math.random() * 1.6;
    g.beginPath();
    let x = Math.random() * size, y = Math.random() * size;
    g.moveTo(x, y);
    for (let s = 0; s < 16; s++) {
      x += (Math.random() - 0.5) * 26;
      y += (Math.random() - 0.5) * 26;
      g.lineTo(x, y);
    }
    g.stroke();
  }
  // water streaks (subtle)
  for (let k = 0; k < 10; k++) {
    const x = Math.random() * size, w = 1.5 + Math.random() * 5;
    const gr = g.createLinearGradient(0, 0, 0, size);
    gr.addColorStop(0, "rgba(48,44,38,0.10)");
    gr.addColorStop(1, "rgba(48,44,38,0)");
    g.fillStyle = gr;
    g.fillRect(x, 0, w, size);
  }
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 2.2), roughnessMap: roughFromHeight(h, size, 0.92, 0.35) };
  cache.set(key, set);
  return set;
}

/** Brick with mortar, chips and moss. */
export function brickSet(rep = 2): TexSet {
  const key = `brick${rep}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 4, 3);
  g.fillStyle = "#6d635a"; g.fillRect(0, 0, size, size); // mortar
  const rows = 8, bh = size / rows;
  for (let r = 0; r < rows; r++) {
    const off = (r % 2) * 0.5;
    const cols = 4;
    for (let cc = 0; cc < cols; cc++) {
      const bw = size / cols;
      const x = (cc + off) * bw - (off ? bw / 2 : 0);
      const y = r * bh;
      const s = Math.sin(x * 3.1 + r * 7.7) * 0.5 + 0.5;
      const cr = 122 + s * 26 + n[(y | 0) * size + (x | 0)] * 30;
      const cg = 68 + s * 18 + n[(y | 0) * size + (x | 0)] * 20;
      const cb = 54 + s * 14 + n[(y | 0) * size + (x | 0)] * 16;
      g.fillStyle = `rgb(${cr | 0},${cg | 0},${cb | 0})`;
      g.fillRect(x + 1.5, y + 1.5, bw - 3, bh - 3);
      // chipped edges
      if (Math.random() < 0.25) {
        g.fillStyle = "rgba(96,88,80,0.85)";
        g.fillRect(x + 1.5 + Math.random() * (bw - 8), y + 1.5 + Math.random() * (bh - 8), 3 + Math.random() * 5, 2 + Math.random() * 4);
      }
      for (let yy = 0; yy < bh; yy++) for (let xx = 0; xx < bw; xx++) {
        const px = ((y + yy) | 0) * size + ((x + xx) | 0);
        if (px >= 0 && px < h.length) h[px] = 0.75;
      }
    }
  }
  // mortar recessed
  for (let i = 0; i < h.length; i++) h[i] *= 0.55;
  // moss in the lower area
  g.globalAlpha = 0.25;
  g.fillStyle = "#4a5c38";
  for (let k = 0; k < 26; k++) {
    const x = Math.random() * size, y = size * (0.6 + Math.random() * 0.4);
    g.beginPath(); g.ellipse(x, y, 6 + Math.random() * 18, 3 + Math.random() * 9, 0, 0, Math.PI * 2); g.fill();
  }
  g.globalAlpha = 1;
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 3.2), roughnessMap: roughFromHeight(h, size, 0.88, 0.3) };
  cache.set(key, set);
  return set;
}

/** Painted plaster with peeling patches revealing brick. */
export function plasterSet(rep = 2, tint = "#d2ccbb"): TexSet {
  const key = `plaster${rep}${tint}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 4, 11);
  const img = g.createImageData(size, size);
  const base = new THREE.Color(tint);
  for (let i = 0; i < size * size; i++) {
    const v = 0.86 + n[i] * 0.26;
    const dirt = Math.max(0, n[i] - 0.6) * 0.8;
    img.data[i * 4] = Math.min(255, base.r * v * (1 - dirt * 0.4) * 255);
    img.data[i * 4 + 1] = Math.min(255, base.g * v * (1 - dirt * 0.45) * 255);
    img.data[i * 4 + 2] = Math.min(255, base.b * v * (1 - dirt * 0.5) * 255);
    img.data[i * 4 + 3] = 255;
    h[i] = n[i] * 0.6;
  }
  g.putImageData(img, 0, 0);
  // peeling paint: small, sparse, low-contrast chips near the edges
  for (let k = 0; k < 14; k++) {
    const x = Math.random() * size, y = Math.random() * size;
    const r = 1.6 + Math.random() * 3.4;
    g.fillStyle = `rgba(146,124,104,${0.18 + Math.random() * 0.22})`;
    g.beginPath();
    for (let a = 0; a < 7; a++) {
      const ang = (a / 7) * Math.PI * 2;
      g.lineTo(x + Math.cos(ang) * r, y + Math.sin(ang) * r * 0.8);
    }
    g.closePath(); g.fill();
  }
  // grime at the bottom
  const gr = g.createLinearGradient(0, size * 0.6, 0, size);
  gr.addColorStop(0, "rgba(60,52,40,0)");
  gr.addColorStop(1, "rgba(60,52,40,0.4)");
  g.fillStyle = gr; g.fillRect(0, size * 0.6, size, size * 0.4);
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.6), roughnessMap: roughFromHeight(h, size, 0.9, 0.25) };
  cache.set(key, set);
  return set;
}

/** Asphalt road with gravel, cracks and oil. */
export function asphaltSet(rep = 4): TexSet {
  const key = `asphalt${rep}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 5, 19);
  const img = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const sp = ((Math.sin(i * 12.9898) * 43758.5453) % 1 + 1) % 1;
    const v = 0.52 + n[i] * 0.34 + (sp > 0.93 ? 0.28 : 0);
    h[i] = n[i] * 0.5 + (sp > 0.93 ? 0.5 : 0);
    img.data[i * 4] = Math.min(255, v * 78);
    img.data[i * 4 + 1] = Math.min(255, v * 78);
    img.data[i * 4 + 2] = Math.min(255, v * 80);
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  g.strokeStyle = "rgba(24,24,26,0.7)";
  for (let k = 0; k < 8; k++) {
    g.lineWidth = 0.7 + Math.random() * 1.5;
    g.beginPath();
    let x = Math.random() * size, y = Math.random() * size;
    g.moveTo(x, y);
    for (let s = 0; s < 10; s++) { x += (Math.random() - 0.5) * 30; y += (Math.random() - 0.5) * 30; g.lineTo(x, y); }
    g.stroke();
  }
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 2.6), roughnessMap: roughFromHeight(h, size, 0.95, 0.3) };
  cache.set(key, set);
  return set;
}

/** Dry, patchy earth/grass ground. */
export function groundSet(rep = 12): TexSet {
  const key = `ground${rep}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 6, 23);
  const n2 = noiseField(size, 3, 41);
  const img = g.createImageData(size, size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const sp = ((Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1 + 1) % 1;
      const grass = Math.max(0, n2[i] - 0.42) * 1.6;
      const dirt = 0.34 + n[i] * 0.24 + (sp > 0.95 ? 0.12 : 0);
      const r = dirt * 96 + grass * 22;
      const gg = dirt * 78 + grass * 62;
      const b = dirt * 52 + grass * 26;
      h[i] = n[i] * 0.5 + grass * 0.5;
      img.data[i * 4] = Math.min(255, r);
      img.data[i * 4 + 1] = Math.min(255, gg);
      img.data[i * 4 + 2] = Math.min(255, b);
      img.data[i * 4 + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.4), roughnessMap: roughFromHeight(h, size, 0.98, 0.15) };
  cache.set(key, set);
  return set;
}

/** Weathered wood planks with grain and knots. */
export function woodSet(rep = 1, dark = false): TexSet {
  const key = `wood${rep}${dark}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 4, dark ? 61 : 29);
  const planks = 6, pw = size / planks;
  const img = g.createImageData(size, size);
  for (let p = 0; p < planks; p++) {
    const base = dark ? 74 : 116;
    const tone = 0.82 + ((p * 37) % 11) / 40;
    const plankShift = p * 3;
    for (let y = 0; y < pw; y++) {
      for (let x = 0; x < size; x++) {
        const i = ((p * pw + y) | 0) * size + x;
        const grain = Math.sin(x * 0.35 + n[i] * 9 + plankShift) * 0.5 + 0.5;
        const v = tone * (0.78 + grain * 0.3);
        h[i] = grain * 0.4;
        const o = i * 4;
        img.data[o] = Math.min(255, base * v * 1.5);
        img.data[o + 1] = Math.min(255, base * v * 1.02);
        img.data[o + 2] = Math.min(255, base * v * 0.62);
        img.data[o + 3] = 255;
      }
    }
  }
  g.putImageData(img, 0, 0);
  // plank gaps
  g.fillStyle = "rgba(24,18,12,0.75)";
  for (let p = 0; p < planks; p++) g.fillRect(0, p * pw, size, 1.6);
  // knots
  for (let k = 0; k < 6; k++) {
    const x = Math.random() * size, y = Math.random() * size;
    const gr = g.createRadialGradient(x, y, 1, x, y, 9);
    gr.addColorStop(0, "rgba(40,26,14,0.9)");
    gr.addColorStop(1, "rgba(40,26,14,0)");
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, 9, 0, Math.PI * 2); g.fill();
  }
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.8), roughnessMap: roughFromHeight(h, size, 0.78, 0.3) };
  cache.set(key, set);
  return set;
}

/** Brushed / oxidised metal. */
export function metalSet(rep = 1, rust = 0.25): TexSet {
  const key = `metal${rep}${rust}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 4, 71);
  const img = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const brush = Math.sin(i % size * 0.9) * 0.5 + 0.5;
    const v = 0.55 + n[i] * 0.25 + brush * 0.08;
    const rr = 150 * v + rust * n[i] * 90;
    const gg = 152 * v + rust * n[i] * 40;
    const bb = 158 * v + rust * n[i] * 12;
    h[i] = n[i] * 0.4 + brush * 0.2;
    img.data[i * 4] = Math.min(255, rr);
    img.data[i * 4 + 1] = Math.min(255, gg);
    img.data[i * 4 + 2] = Math.min(255, bb);
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.2), roughnessMap: roughFromHeight(h, size, 0.45, 0.5) };
  cache.set(key, set);
  return set;
}

/** Skin: subtle pores, veins, blemishes. */
export function skinSet(tint = "#c89a74"): TexSet {
  const key = `skin${tint}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 128;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 5, 83);
  const base = new THREE.Color(tint);
  const img = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const pore = ((Math.sin(i * 78.233) * 43758.5453) % 1 + 1) % 1;
    const v = 0.93 + n[i] * 0.12 - (pore > 0.97 ? 0.06 : 0);
    const mott = Math.max(0, n[i] - 0.66) * 0.5;
    img.data[i * 4] = Math.min(255, base.r * v * (1 - mott * 0.25) * 255);
    img.data[i * 4 + 1] = Math.min(255, base.g * v * (1 - mott * 0.3) * 255);
    img.data[i * 4 + 2] = Math.min(255, base.b * v * (1 - mott * 0.25) * 255);
    img.data[i * 4 + 3] = 255;
    h[i] = n[i] * 0.25 + (pore > 0.97 ? 0.3 : 0);
  }
  g.putImageData(img, 0, 0);
  const set: TexSet = { map: toTex(c, 1), normalMap: normalFromHeight(h, size, 0.7), roughnessMap: roughFromHeight(h, size, 0.72, 0.15) };
  cache.set(key, set);
  return set;
}

/** Woven cloth / fabric. */
export function fabricSet(tint: string, rep = 1): TexSet {
  const key = `fab${tint}${rep}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 128;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 4, 97);
  const base = new THREE.Color(tint);
  const img = g.createImageData(size, size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const weave = (Math.sin(x * 1.6) * 0.5 + 0.5) * 0.5 + (Math.sin(y * 1.6) * 0.5 + 0.5) * 0.5;
      const v = 0.82 + n[i] * 0.2 + weave * 0.12;
      img.data[i * 4] = Math.min(255, base.r * v * 255);
      img.data[i * 4 + 1] = Math.min(255, base.g * v * 255);
      img.data[i * 4 + 2] = Math.min(255, base.b * v * 255);
      img.data[i * 4 + 3] = 255;
      h[i] = weave * 0.6 + n[i] * 0.4;
    }
  }
  g.putImageData(img, 0, 0);
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.1), roughnessMap: roughFromHeight(h, size, 0.96, 0.12) };
  cache.set(key, set);
  return set;
}

/** Ceiling tile grid with recessed fixtures. */
export function ceilingSet(rep = 4): TexSet {
  const key = `ceil${rep}`;
  if (cache.has(key)) return cache.get(key)!;
  const size = 256;
  const { c, g } = cnv(size);
  const h = new Float32Array(size * size);
  const n = noiseField(size, 3, 53);
  g.fillStyle = "#cfcbc0"; g.fillRect(0, 0, size, size);
  const img = g.getImageData(0, 0, size, size);
  for (let i = 0; i < size * size; i++) {
    const v = 0.92 + n[i] * 0.14;
    img.data[i * 4] *= v; img.data[i * 4 + 1] *= v; img.data[i * 4 + 2] *= v;
  }
  g.putImageData(img, 0, 0);
  const tile = size / 4;
  g.strokeStyle = "rgba(126,122,112,0.85)"; g.lineWidth = 2.5;
  for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(i * tile, 0); g.lineTo(i * tile, size); g.moveTo(0, i * tile); g.lineTo(size, i * tile); g.stroke(); }
  // stains
  for (let k = 0; k < 10; k++) {
    g.fillStyle = `rgba(96,84,62,${0.05 + Math.random() * 0.12})`;
    g.beginPath(); g.ellipse(Math.random() * size, Math.random() * size, 8 + Math.random() * 30, 6 + Math.random() * 22, Math.random() * 3, 0, Math.PI * 2); g.fill();
  }
  for (let i = 0; i < size * size; i++) h[i] = 0.7;
  const set: TexSet = { map: toTex(c, rep), normalMap: normalFromHeight(h, size, 1.0), roughnessMap: roughFromHeight(h, size, 0.95, 0.2) };
  cache.set(key, set);
  return set;
}

/** Build a PBR material from a texture set. */
export function pbr(set: TexSet, o: Partial<THREE.MeshStandardMaterialParameters> = {}) {
  const m = new THREE.MeshStandardMaterial({
    map: set.map,
    normalMap: set.normalMap,
    roughnessMap: set.roughnessMap,
    roughness: 1,
    metalness: 0,
    ...o,
  });
  if (m.normalMap) m.normalScale.set(1, 1);
  return m;
}
