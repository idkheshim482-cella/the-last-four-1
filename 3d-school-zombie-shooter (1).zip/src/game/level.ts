import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { makeTextures, signTexture, cityTexture, smokeTexture, skyTexture } from "./textures";
import { concreteSet, brickSet, plasterSet, asphaltSet, groundSet, woodSet, metalSet, fabricSet, ceilingSet, pbr, setRepeat } from "../gfx/pbr";
import { buildCity as buildCity2 } from "./city";

export interface AABB { minx: number; maxx: number; miny: number; maxy: number; minz: number; maxz: number }
export interface Slab { minx: number; maxx: number; minz: number; maxz: number; top: number }

export interface Door {
  id: string;
  label: string;
  x: number; y: number; z: number;
  width: number;
  locked: boolean;
  keyId?: string;
  open: boolean;
  angle: number;
  openAngle: number;
  pivot: THREE.Object3D;
  box: AABB;
  forceT: number;
}

export type PickupKind =
  | "pistol" | "shotgun" | "rifle"
  | "ammo_pistol" | "ammo_shotgun" | "ammo_rifle"
  | "health" | "key_janitor" | "key_principal" | "key_office" | "flashlight"
  | "toolbox" | "city_map" | "file_4b" | "helix_keycard";

export interface PickupDef { id: string; kind: PickupKind; x: number; y: number; z: number; where: string }
export interface NavNode { id: number; x: number; y: number; z: number; edges: { to: number; door?: string }[] }
export interface Note { id: string; x: number; y: number; z: number; title: string; text: string }
export interface Exit { x: number; y: number; z: number; text: string }

function rng(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FH = 4; // floor height

interface RoomDef { id: string; name: string; floor: number; side: "N" | "S"; x0: number; x1: number; door: number; type: string; lock?: string }

export const ROOMS: RoomDef[] = [
  { id: "c1a", name: "CLASSROOM 1A", floor: 0, side: "N", x0: -30, x1: -18, door: -21, type: "classroom" },
  { id: "lab", name: "SCIENCE LAB", floor: 0, side: "N", x0: -18, x1: -6, door: -9, type: "lab" },
  { id: "lib", name: "LIBRARY", floor: 0, side: "N", x0: -6, x1: 10, door: 2, type: "library" },
  { id: "c1b", name: "CLASSROOM 1B", floor: 0, side: "S", x0: -30, x1: -18, door: -21, type: "classroom" },
  { id: "staff", name: "STAFF ROOM", floor: 0, side: "S", x0: -18, x1: -6, door: -9, type: "staff" },
  { id: "sec", name: "SECURITY", floor: 0, side: "S", x0: -6, x1: 2, door: -2, type: "security", lock: "key_janitor" },
  { id: "caf", name: "CAFETERIA", floor: 0, side: "S", x0: 2, x1: 18, door: 10, type: "cafeteria" },
  { id: "c2a", name: "CLASSROOM 2A", floor: 1, side: "N", x0: -30, x1: -18, door: -21, type: "classroom" },
  { id: "c2b", name: "CLASSROOM 2B", floor: 1, side: "N", x0: -18, x1: -6, door: -9, type: "classroom" },
  { id: "c2c", name: "CLASSROOM 2C", floor: 1, side: "N", x0: -6, x1: 10, door: 2, type: "classroom" },
  { id: "prin", name: "PRINCIPAL", floor: 1, side: "S", x0: -30, x1: -18, door: -21, type: "principal", lock: "key_principal" },
  { id: "office", name: "SCHOOL OFFICE", floor: 1, side: "S", x0: -18, x1: -6, door: -9, type: "office", lock: "key_office" },
  { id: "rec", name: "RECORDS", floor: 1, side: "S", x0: -6, x1: 2, door: -2, type: "records" },
  { id: "c2d", name: "CLASSROOM 2D", floor: 1, side: "S", x0: 2, x1: 18, door: 10, type: "classroom" },
];

// world size (metres) of one texture tile for each material family
const TILE: Record<string, number> = { floor: 2.4, wall: 2.6, ceiling: 2.4, wood: 1.6, brick: 2.6, ground: 9, plaster: 3.2, darkwood: 1.6, carpet: 2.2, concrete: 2.2, asphalt: 5, lamp: 1, lampOff: 1, emergency: 1, exit: 1, bottle: 1, military: 1, yellow: 1, white: 1, black: 1, red: 1, green: 1, fabric: 1.2, blood: 1, paper: 1, locker: 1, books: 1, blackboard: 1, glass: 1, rubble: 1, rubbleDark: 1, slab: 1, brickEdge: 1, ivy: 1, ivyDark: 1, paintY: 1, concreteRoof: 1 };

export class Level {
  scene: THREE.Scene;
  root = new THREE.Group();
  geos = new Map<string, THREE.BufferGeometry[]>();
  mats: Record<string, THREE.Material> = {};
  colliders: AABB[] = [];
  slabs: Slab[] = [];
  doors: Door[] = [];
  pickups: PickupDef[] = [];
  nav: NavNode[] = [];
  notes: Note[] = [];
  exits: Exit[] = [];
  flickerLights: { light: THREE.PointLight; base: number; phase: number; red: boolean }[] = [];
  lampMat!: THREE.MeshStandardMaterial;
  barricade = new THREE.Group();
  radio = new THREE.Group();
  radioPos = new THREE.Vector3(-12, FH + 0.85, -10.6);
  radioDial!: THREE.Mesh;
  hemi!: THREE.HemisphereLight;
  playerStart = new THREE.Vector3(-27.2, 0, 9.2);
  restPoint: { x: number; y: number; z: number } | null = null;
  barricadeBox: AABB | null = null;
  r = rng(1337);
  quality: number;

  constructor(scene: THREE.Scene, quality: number) {
    this.scene = scene;
    this.quality = quality;
    scene.add(this.root);
    this.makeMaterials();
    this.build();
    this.finalize();
  }

  makeMaterials() {
    const t = makeTextures();
    // PBR material foundry: albedo + normal + roughness for every surface family.
    // NOTE: geometry UVs are already scaled to world units (1 tile = TILE metres),
    // so these texture sets must keep repeat = 1 or the tiling is applied twice.
    const conc = concreteSet(2, "#a3a09a");
    const concRoof = concreteSet(2, "#7c7d7a");
    const brickT = brickSet(2);
    const plasterT = plasterSet(2, "#d2ccbb");
    const asphaltT = asphaltSet(5);
    const groundT = groundSet(14);
    const woodT = woodSet(1, false);
    const woodDarkT = woodSet(1, true);
    const metalT = metalSet(1, 0.22);
    const metalRustT = metalSet(1, 0.75);
    const ceilT = ceilingSet(4);
    const S = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(o);
    this.lampMat = S({ color: 0x1a1a1a, emissive: 0xfff0d6, emissiveIntensity: 1.4, roughness: 0.4, metalness: 0 });
    this.mats = {
      floor: pbr(concreteSet(3, "#9a978f"), { roughness: 0.94, metalness: 0.02, color: 0xb9b6ae }),
      wall: pbr(plasterT, { roughness: 0.93, metalness: 0, color: 0xffffff }),
      plaster: pbr(plasterT, { roughness: 0.95, metalness: 0 }),
      ceiling: pbr(ceilT, { roughness: 0.96, metalness: 0 }),
      wood: pbr(woodT, { roughness: 0.76, metalness: 0.02 }),
      darkwood: pbr(woodDarkT, { roughness: 0.8, metalness: 0.02 }),
      metal: pbr(metalT, { roughness: 0.46, metalness: 0.82, color: 0xa9aeb4 }),
      darkmetal: pbr(metalRustT, { roughness: 0.62, metalness: 0.7, color: 0x6a6a6e }),
      blackboard: S({ map: t.blackboard, roughness: 0.88, metalness: 0.02 }),
      locker: pbr(metalT, { roughness: 0.52, metalness: 0.65, color: 0x8fa2b4 }),
      books: S({ map: t.books, roughness: 0.9, metalness: 0 }),
      ground: pbr(groundT, { roughness: 0.99, metalness: 0, color: 0x9aa08c }),
      brick: pbr(brickT, { roughness: 0.93, metalness: 0 }),
      paper: S({ map: t.paper, side: THREE.DoubleSide, roughness: 0.95, metalness: 0 }),
      blood: S({ color: 0x3d0606, roughness: 0.28, metalness: 0.05 }),
      glass: new THREE.MeshPhysicalMaterial({
        color: 0x9fb4c4, transparent: true, opacity: 0.24, roughness: 0.08, metalness: 0,
        transmission: 0.55, thickness: 0.4, side: THREE.DoubleSide,
      }),
      white: S({ color: 0xd8d8d4, roughness: 0.7, metalness: 0.04 }),
      black: S({ color: 0x16181a, roughness: 0.55, metalness: 0.25 }),
      red: S({ color: 0x8e201c, roughness: 0.62, metalness: 0.18 }),
      green: S({ color: 0x3d5c3c, roughness: 0.68, metalness: 0.12 }),
      fabric: pbr(fabricSet("#5d4040", 2), { roughness: 0.97, metalness: 0 }),
      carpet: pbr(fabricSet("#3f3650", 3), { roughness: 0.99, metalness: 0 }),
      lamp: this.lampMat,
      lampOff: S({ color: 0x2a2c2e, roughness: 0.5, metalness: 0.4 }),
      emergency: S({ color: 0x2a0606, emissive: 0xff2418, emissiveIntensity: 1.8, roughness: 0.4 }),
      exit: S({ color: 0x062a10, emissive: 0x2aff5e, emissiveIntensity: 1.6, roughness: 0.4 }),
      bottle: new THREE.MeshPhysicalMaterial({ color: 0x69b3ad, roughness: 0.12, metalness: 0, transmission: 0.6, thickness: 0.2 }),
      military: pbr(fabricSet("#4c5424", 2), { roughness: 0.9, metalness: 0.05 }),
      yellow: S({ color: 0xc8a020, roughness: 0.6, metalness: 0.25 }),
      concrete: pbr(conc, { roughness: 0.95, metalness: 0.02, color: 0xa8a49c }),
      concreteRoof: pbr(concRoof, { roughness: 0.96, metalness: 0.02, color: 0x9a9c98 }),
      asphalt: pbr(asphaltT, { roughness: 0.93, metalness: 0.02, color: 0x8b8d92 }),
      paintY: S({ color: 0x9a8a2c, emissive: 0x2a2408, emissiveIntensity: 0.35, roughness: 0.85 }),
      rubble: pbr(concRoof, { roughness: 0.98, metalness: 0, color: 0x8f8b82 }),
      rubbleDark: pbr(concRoof, { roughness: 0.98, metalness: 0, color: 0x6d6a63 }),
      slab: pbr(ceilT, { roughness: 0.95, metalness: 0, color: 0xcfccc2 }),
      brickEdge: pbr(brickT, { roughness: 0.94, metalness: 0, color: 0xb09486 }),
      ivy: S({ color: 0x446e35, roughness: 0.9, metalness: 0 }),
      ivyDark: S({ color: 0x2f4f27, roughness: 0.92, metalness: 0 }),
    };
  }

  // ------------- primitives -------------
  box(mat: string, cx: number, y0: number, cz: number, sx: number, sy: number, sz: number,
    o: { collide?: boolean; ry?: number; rx?: number; rz?: number; slab?: boolean } = {}) {
    const g = new THREE.BoxGeometry(sx, sy, sz);
    const ts = TILE[mat];
    if (ts) {
      const uv = g.attributes.uv as THREE.BufferAttribute;
      for (let f = 0; f < 6; f++) {
        for (let k = 0; k < 4; k++) {
          const i = f * 4 + k;
          let u = uv.getX(i), v = uv.getY(i);
          if (f < 2) { u = (u * sz) / ts; v = (v * sy + y0) / ts; }
          else if (f < 4) { u = (u * sx) / ts; v = (v * sz) / ts; }
          else { u = (u * sx) / ts; v = (v * sy + y0) / ts; }
          uv.setXY(i, u, v);
        }
      }
    }
    if (o.rx || o.ry || o.rz) g.applyMatrix4(new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(o.rx || 0, o.ry || 0, o.rz || 0)));
    g.translate(cx, y0 + sy / 2, cz);
    if (!this.geos.has(mat)) this.geos.set(mat, []);
    this.geos.get(mat)!.push(g);
    if (o.collide) {
      let hx = sx / 2, hz = sz / 2;
      if (o.ry) {
        const c = Math.abs(Math.cos(o.ry)), s = Math.abs(Math.sin(o.ry));
        hx = (sx / 2) * c + (sz / 2) * s;
        hz = (sx / 2) * s + (sz / 2) * c;
      }
      this.colliders.push({ minx: cx - hx, maxx: cx + hx, miny: y0, maxy: y0 + sy, minz: cz - hz, maxz: cz + hz });
    }
    if (o.slab) this.slabs.push({ minx: cx - sx / 2, maxx: cx + sx / 2, minz: cz - sz / 2, maxz: cz + sz / 2, top: y0 + sy });
  }

  wallX(z: number, x0: number, x1: number, y0: number, h: number, ops: { c: number; w: number; h: number }[] = [], mat = "wall", th = 0.2) {
    ops = [...ops].sort((a, b) => a.c - b.c);
    let cur = x0;
    for (const o of ops) {
      const a = o.c - o.w / 2, b = o.c + o.w / 2;
      if (a > cur) this.box(mat, (cur + a) / 2, y0, z, a - cur, h, th, { collide: true });
      if (o.h < h) this.box(mat, o.c, y0 + o.h, z, o.w, h - o.h, th, { collide: true });
      cur = b;
    }
    if (x1 > cur) this.box(mat, (cur + x1) / 2, y0, z, x1 - cur, h, th, { collide: true });
  }

  wallZ(x: number, z0: number, z1: number, y0: number, h: number, ops: { c: number; w: number; h: number }[] = [], mat = "wall", th = 0.2) {
    ops = [...ops].sort((a, b) => a.c - b.c);
    let cur = z0;
    for (const o of ops) {
      const a = o.c - o.w / 2, b = o.c + o.w / 2;
      if (a > cur) this.box(mat, x, y0, (cur + a) / 2, th, h, a - cur, { collide: true });
      if (o.h < h) this.box(mat, x, y0 + o.h, o.c, th, h - o.h, o.w, { collide: true });
      cur = b;
    }
    if (z1 > cur) this.box(mat, x, y0, (cur + z1) / 2, th, h, z1 - cur, { collide: true });
  }

  addDoor(id: string, label: string, x: number, y: number, z: number, side: 1 | -1, keyId?: string, startOpen = false) {
    const width = 2.0;
    const pivot = new THREE.Group();
    pivot.position.set(x - width / 2, y, z);
    // (leaf extends +width from the pivot along local X)
    const panelMat = keyId ? (this.mats.darkwood as THREE.Material) : (this.mats.wood as THREE.Material);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(width, 2.4, 0.06), panelMat);
    panel.position.set(width / 2, 1.2, 0);
    pivot.add(panel);
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.6, 0.09), this.mats.glass);
    win.position.set(width / 2, 1.65, 0);
    pivot.add(win);
    const knob = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.16), this.mats.metal);
    knob.position.set(width - 0.15, 1.05, 0);
    pivot.add(knob);
    if (keyId) {
      const lockM = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.16, 0.12), this.mats.yellow);
      lockM.position.set(width - 0.15, 1.25, 0);
      lockM.name = "lock";
      pivot.add(lockM);
    }
    this.root.add(pivot);
    // swing past 90° so the leaf rests flat against the wall, clear of the opening
    const openAngle = side === 1 ? -Math.PI * 0.58 : Math.PI * 0.58;
    const d: Door = {
      id, label, x, y, z, width, locked: !!keyId, keyId, open: startOpen, angle: startOpen ? openAngle : 0, openAngle,
      pivot, box: { minx: x - width / 2, maxx: x + width / 2, miny: y, maxy: y + 2.4, minz: z - 0.06, maxz: z + 0.06 }, forceT: 0,
    };
    pivot.rotation.y = d.angle;
    this.doors.push(d);
    // frame — sits just OUTSIDE the opening so it never narrows the walkable gap
    this.box("darkwood", x - width / 2 - 0.11, y, z, 0.12, 2.5, 0.28);
    this.box("darkwood", x + width / 2 + 0.11, y, z, 0.12, 2.5, 0.28);
    this.box("darkwood", x, y + 2.45, z, width + 0.34, 0.12, 0.28);
  }

  sign(text: string, x: number, y: number, z: number, ry: number, bg = "#1b3a4d", w = 1.6) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, w / 4), new THREE.MeshLambertMaterial({ map: signTexture(text, bg), emissive: 0x222222 }));
    m.position.set(x, y, z);
    m.rotation.y = ry;
    this.root.add(m);
  }

  light(x: number, y: number, z: number, color: number, intensity: number, dist: number, red = false) {
    const l = new THREE.PointLight(color, intensity, dist, 1.6);
    l.position.set(x, y, z);
    this.root.add(l);
    this.flickerLights.push({ light: l, base: intensity, phase: Math.random() * 100, red });
    return l;
  }

  ceilingLamp(x: number, y: number, z: number, on: boolean, alongZ = false) {
    this.box(on ? "lamp" : "lampOff", x, y - 0.06, z, alongZ ? 0.3 : 1.2, 0.05, alongZ ? 1.2 : 0.3);
  }

  papers(x0: number, x1: number, z0: number, z1: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      this.box("paper", x0 + this.r() * (x1 - x0), y + 0.005 + i * 0.0005, z0 + this.r() * (z1 - z0), 0.3, 0.004, 0.22, { ry: this.r() * 6 });
    }
  }

  bloodPool(x: number, y: number, z: number, s = 1) {
    this.box("blood", x, y + 0.006, z, 1.0 * s, 0.004, 0.7 * s, { ry: this.r() * 3 });
    this.box("blood", x + 0.4 * s, y + 0.007, z + 0.2, 0.4 * s, 0.004, 0.3 * s, { ry: this.r() * 3 });
  }

  // ------------- furniture -------------
  desk(x: number, y: number, z: number, ry = 0, messy = false) {
    if (messy && this.r() < 0.25) {
      // flipped desk
      this.box("wood", x, y, z, 1.2, 0.6, 0.05, { ry, collide: true });
      this.box("metal", x, y + 0.03, z + 0.3, 1.1, 0.05, 0.05, { ry });
      return;
    }
    this.box("wood", x, y + 0.72, z, 1.2, 0.05, 0.6, { ry, collide: false });
    this.box("metal", x, y, z, 1.1, 0.72, 0.5, { ry, collide: true });
    this.colliders.pop();
    this.colliders.push({ minx: x - 0.6, maxx: x + 0.6, miny: y, maxy: y + 0.77, minz: z - 0.32, maxz: z + 0.32 });
  }

  chair(x: number, y: number, z: number, ry = 0, over = false) {
    if (over) {
      this.box("darkmetal", x, y, z, 0.45, 0.45, 0.45, { rx: Math.PI / 2, ry });
      this.box("wood", x, y + 0.02, z + 0.2, 0.42, 0.04, 0.42, { ry });
      return;
    }
    this.box("darkmetal", x, y, z, 0.4, 0.43, 0.4, { ry });
    this.box("wood", x, y + 0.43, z, 0.44, 0.04, 0.42, { ry });
    const bx = Math.sin(ry) * 0.2, bz = Math.cos(ry) * 0.2;
    this.box("wood", x + bx, y + 0.45, z + bz, 0.44, 0.45, 0.04, { ry });
  }

  locker(x: number, y: number, z: number, ry: number, n: number) {
    const dx = Math.cos(ry), dz = -Math.sin(ry);
    for (let i = 0; i < n; i++) {
      const lx = x + dx * (i - (n - 1) / 2) * 0.5, lz = z + dz * (i - (n - 1) / 2) * 0.5;
      this.box("locker", lx, y, lz, 0.48, 1.9, 0.45, { ry });
    }
    const w = n * 0.5;
    const hx = Math.abs(dx) * w / 2 + Math.abs(dz) * 0.23, hz = Math.abs(dz) * w / 2 + Math.abs(dx) * 0.23;
    this.colliders.push({ minx: x - hx, maxx: x + hx, miny: y, maxy: y + 1.9, minz: z - hz, maxz: z + hz });
  }

  shelf(x: number, y: number, z: number, ry: number, w = 2, h = 2.2) {
    this.box("books", x, y, z, w, h, 0.4, { ry, collide: true });
    this.box("darkwood", x, y + h, z, w + 0.05, 0.05, 0.45, { ry });
  }

  // ------------- rooms -------------
  classroom(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    const zi = rd.side === "N" ? 2 : -2, zo = rd.side === "N" ? 12 : -12, s = rd.side === "N" ? 1 : -1;
    const zm = (zi + zo) / 2;
    // blackboard on west wall
    this.box("blackboard", x0 + 0.15, y + 1, zm, 0.05, 1.3, 4.2);
    this.box("darkwood", x0 + 0.2, y + 0.95, zm, 0.12, 0.05, 4.2);
    // teacher desk
    this.box("darkwood", x0 + 2, y, zm, 0.8, 0.78, 1.8, { collide: true });
    this.chair(x0 + 1.3, y, zm, -Math.PI / 2);
    // student desks
    const messy = true;
    for (let cx = x0 + 4.5; cx < x1 - 1.2; cx += 2.1) {
      for (let k = -1.5; k <= 1.5; k += 1) {
        const cz = zm + k * 2;
        if (Math.abs(cx - rd.door) < 1.6 && Math.abs(cz - zi) < 2.6) continue;
        const jitter = (this.r() - 0.5) * 0.5;
        this.desk(cx, y, cz, jitter, messy);
        this.chair(cx + 0.6, y, cz + (this.r() - 0.5) * 0.3, Math.PI / 2 + jitter, this.r() < 0.3);
      }
    }
    // lockers along east wall
    this.locker(x1 - 0.35, y, zm + s * 1.5, Math.PI / 2, 6);
    this.papers(x0 + 1, x1 - 1, Math.min(zi, zo) + 1, Math.max(zi, zo) - 1, y, 14);
    if (this.r() < 0.6) this.bloodPool(x0 + 3 + this.r() * (x1 - x0 - 6), y, zm + (this.r() - 0.5) * 4);
    this.ceilingLamp((x0 + x1) / 2 - 2, y + FH - 0.2, zm, this.r() < 0.6);
    this.ceilingLamp((x0 + x1) / 2 + 2, y + FH - 0.2, zm, this.r() < 0.35);
    this.light((x0 + x1) / 2 - 2, y + FH - 0.5, zm, 0xffe4bc, 4.2, 13);
    this.light((x0 + x1) / 2 + 2, y + FH - 0.5, zm, 0xffe4bc, 2.6, 12);
    this.light((x0 + x1) / 2, y + 2.2, rd.side === "N" ? 10.4 : -10.4, 0xcfe0ff, 2.2, 13);
  }

  lab(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    const zm = 7;
    for (let i = 0; i < 2; i++) {
      const cx = x0 + 4 + i * 4.5;
      this.box("white", cx, y, zm, 1.2, 0.85, 5, { collide: true });
      this.box("black", cx, y + 0.85, zm, 1.3, 0.05, 5.1);
      for (let b = 0; b < 5; b++) this.box("bottle", cx + (this.r() - 0.5) * 0.8, y + 0.9, zm - 2 + b + this.r() * 0.5, 0.08, 0.22, 0.08);
      this.chair(cx - 1, y, zm - 1, -Math.PI / 2, this.r() < 0.4);
      this.chair(cx + 1, y, zm + 1, Math.PI / 2, this.r() < 0.4);
    }
    // wall cabinets with bottles
    this.box("white", x1 - 0.4, y, zm, 0.6, 0.9, 5, { collide: true });
    this.box("black", x1 - 0.4, y + 0.9, zm, 0.65, 0.04, 5);
    this.box("glass", x1 - 0.3, y + 1.4, zm, 0.4, 1.4, 4.5);
    // fume hood
    this.box("metal", x0 + 0.6, y, 10.5, 1, 2.3, 1.6, { collide: true });
    this.box("glass", x0 + 1.12, y + 1, 10.5, 0.02, 0.8, 1.4);
    this.box("blackboard", x0 + 0.15, y + 1, 5.5, 0.05, 1.3, 3.5);
    this.papers(x0 + 1, x1 - 1, 3, 11, y, 10);
    this.box("bottle", x0 + 5, y + 0.005, 4, 1.4, 0.004, 0.9, { ry: 0.4 }); // spilled chemicals
    this.bloodPool(x0 + 7, y, 9.5, 1.3);
    this.ceilingLamp(x0 + 4, y + FH - 0.2, zm, true);
    this.ceilingLamp(x0 + 8, y + FH - 0.2, zm, false);
  }

  library(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    for (let i = 0; i < 3; i++) {
      this.shelf(x0 + 3 + i * 3.2, y, 9.5, 0, 2.4);
      this.shelf(x0 + 3 + i * 3.2, y, 9.95, Math.PI, 2.4);
    }
    // fallen shelf
    this.box("books", x0 + 12.5, y, 9.4, 2.4, 0.4, 2.2, { collide: true });
    this.shelf(x1 - 0.35, y, 6, Math.PI / 2, 4);
    this.shelf(x0 + 0.35, y, 7, -Math.PI / 2, 4);
    // reading tables
    for (let i = 0; i < 2; i++) {
      const cx = x0 + 4 + i * 5;
      this.box("wood", cx, y + 0.74, 5.6, 2.6, 0.06, 1.2);
      this.box("darkwood", cx, y, 5.6, 2.4, 0.74, 1.0, { collide: true });
      this.chair(cx - 0.7, y, 4.6, Math.PI, this.r() < 0.4);
      this.chair(cx + 0.7, y, 6.6, 0, this.r() < 0.4);
    }
    // librarian desk
    this.box("darkwood", x1 - 3, y, 3.6, 2.4, 1.0, 0.7, { collide: true });
    this.box("wood", x1 - 3, y + 1.0, 3.6, 2.5, 0.05, 0.8);
    for (let i = 0; i < 25; i++) this.box("books", x0 + 1 + this.r() * (x1 - x0 - 2), y + 0.02, 3 + this.r() * 8, 0.25, 0.05, 0.18, { ry: this.r() * 6 });
    this.papers(x0 + 1, x1 - 1, 3, 11, y, 12);
    this.ceilingLamp(x0 + 4, y + FH - 0.2, 7, false);
    this.ceilingLamp(x0 + 11, y + FH - 0.2, 7, true);
  }

  staff(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    // meeting table
    this.box("wood", x0 + 6, y + 0.74, -7, 4, 0.06, 1.4);
    this.box("darkwood", x0 + 6, y, -7, 3.8, 0.74, 1.2, { collide: true });
    for (let i = 0; i < 3; i++) { this.chair(x0 + 4.7 + i * 1.3, y, -8, Math.PI, this.r() < 0.3); this.chair(x0 + 4.7 + i * 1.3, y, -6, 0, this.r() < 0.3); }
    // sofa
    this.box("fabric", x0 + 1, y, -10, 1, 0.45, 2.6, { collide: true });
    this.box("fabric", x0 + 0.6, y + 0.45, -10, 0.25, 0.5, 2.6);
    // cupboards
    this.box("wood", x1 - 0.4, y, -9, 0.6, 2.0, 3, { collide: true });
    this.box("darkwood", x1 - 0.69, y + 0.1, -9, 0.02, 1.8, 0.02);
    // fridge + counter
    this.box("white", x1 - 0.5, y, -4, 0.8, 1.9, 0.8, { collide: true });
    this.box("wood", x0 + 3, y, -11.6, 4, 0.9, 0.6, { collide: true });
    this.box("black", x0 + 2, y + 0.9, -11.6, 0.4, 0.35, 0.3); // coffee machine
    this.papers(x0 + 1, x1 - 1, -11, -3, y, 12);
    this.bloodPool(x0 + 8, y, -4.5);
    this.ceilingLamp(x0 + 6, y + FH - 0.2, -7, true);
  }

  security(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    for (let i = 0; i < 2; i++) {
      const sx = x0 + 1.5 + i * 2.6;
      this.box("darkmetal", sx, y, -11.4, 2, 2.2, 0.7, { collide: true });
      for (let k = 0; k < 4; k++) this.box("metal", sx, y + 0.3 + k * 0.55, -11.1, 2.02, 0.04, 0.2);
    }
    this.box("military", x1 - 1.3, y, -8.5, 1.0, 0.8, 1.6, { collide: true }); // crate
    this.box("military", x1 - 1.3, y + 0.8, -8.3, 0.8, 0.6, 0.9, { collide: true });
    this.box("darkmetal", x0 + 0.5, y, -6, 0.8, 1.9, 1.6, { collide: true }); // gun locker
    // monitors desk
    this.box("darkmetal", 0.6, y, -3.4, 2.4, 0.78, 0.7, { collide: true });
    for (let i = 0; i < 3; i++) this.box("glass", -0.2 + i * 0.8, y + 0.8, -3.6, 0.65, 0.5, 0.05);
    this.ceilingLamp(x0 + 4, y + FH - 0.2, -7, true);
    this.papers(x0 + 1, x1 - 1, -11, -3, y, 6);
  }

  cafeteria(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    for (let i = 0; i < 3; i++)
      for (let j = 0; j < 2; j++) {
        const cx = x0 + 4 + i * 4, cz = -5.5 - j * 3.8;
        const ry = (this.r() - 0.5) * 0.4;
        this.box("white", cx, y + 0.72, cz, 3, 0.05, 1.1, { ry });
        this.box("darkmetal", cx, y, cz, 2.6, 0.72, 0.6, { ry, collide: true });
        this.box("darkmetal", cx, y, cz - 0.85, 2.6, 0.42, 0.3, { ry });
        this.box("darkmetal", cx, y, cz + 0.85, 2.6, 0.42, 0.3, { ry });
      }
    // serving counter
    this.box("metal", x1 - 1, y, -7, 1, 1, 6, { collide: true });
    this.box("white", x1 - 1, y + 1, -7, 1.1, 0.05, 6.1);
    // food trays scattered
    for (let i = 0; i < 12; i++) this.box("red", x0 + 1 + this.r() * 12, y + 0.01, -3 + -this.r() * 8, 0.45, 0.02, 0.32, { ry: this.r() * 6 });
    this.bloodPool(x0 + 7, y, -4, 1.5);
    this.bloodPool(x0 + 10, y, -9.5);
    this.ceilingLamp(x0 + 4, y + FH - 0.2, -7, false);
    this.ceilingLamp(x0 + 9, y + FH - 0.2, -7, true);
    this.ceilingLamp(x0 + 13, y + FH - 0.2, -7, false);
  }

  principal(rd: RoomDef, y: number) {
    const { x0 } = rd;
    this.box("carpet", x0 + 6, y + 0.001, -7, 8, 0.01, 6);
    this.box("darkwood", x0 + 6, y, -9, 2.6, 0.8, 1.1, { collide: true });
    this.box("wood", x0 + 6, y + 0.8, -9, 2.7, 0.05, 1.2);
    this.chair(x0 + 6, y, -10.2, 0);
    this.chair(x0 + 5.3, y, -7.6, Math.PI, true);
    this.shelf(x0 + 3, y, -11.7, 0, 3);
    this.shelf(x0 + 9, y, -11.7, 0, 3);
    this.box("darkmetal", x0 + 0.6, y, -4, 0.8, 1.3, 1.0, { collide: true }); // safe/cabinet
    this.box("fabric", x0 + 11, y, -5, 1, 0.45, 2.2, { collide: true });
    this.papers(x0 + 1, x0 + 11, -11, -3, y, 10);
    this.ceilingLamp(x0 + 6, y + FH - 0.2, -7, true);
  }

  office(rd: RoomDef, y: number) {
    const { x0, x1 } = rd;
    // front counter
    this.box("wood", -12.5, y, -4.8, 5.5, 1.1, 0.6, { collide: true });
    this.box("darkwood", -12.5, y + 1.1, -4.8, 5.6, 0.05, 0.8);
    // filing cabinets
    for (let i = 0; i < 4; i++) this.box("metal", x0 + 0.4, y, -6.5 - i * 1.0, 0.6, 1.4, 0.9, { collide: true });
    // radio desk (by the exterior wall)
    this.box("darkwood", -12, y, -10.6, 3, 0.8, 1.1, { collide: true });
    this.box("wood", -12, y + 0.8, -10.6, 3.1, 0.05, 1.2);
    this.chair(-12, y, -9.5, Math.PI);
    // side desks
    this.box("darkwood", x1 - 1.2, y, -9, 1.2, 0.8, 2.2, { collide: true });
    this.box("black", x1 - 1.2, y + 0.8, -9.3, 0.5, 0.4, 0.05); // monitor
    this.papers(x0 + 1, x1 - 1, -11, -3, y, 16);
    this.ceilingLamp(x0 + 6, y + FH - 0.2, -8, true);
    // radio model
    const R = this.radio;
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.35, 0.4), this.mats.military);
    body.position.y = 0.175;
    R.add(body);
    const face = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.27, 0.02), this.mats.black);
    face.position.set(0, 0.18, 0.205);
    R.add(face);
    const dialMat = new THREE.MeshBasicMaterial({ color: 0xffaa22 });
    this.radioDial = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.08, 0.01), dialMat);
    this.radioDial.position.set(-0.13, 0.22, 0.217);
    R.add(this.radioDial);
    for (let i = 0; i < 3; i++) {
      const k = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.04, 8), this.mats.metal);
      k.rotation.x = Math.PI / 2;
      k.position.set(0.1 + i * 0.09, 0.14, 0.23);
      k.name = "knob" + i;
      R.add(k);
    }
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.012, 0.9, 4), this.mats.darkmetal);
    ant.position.set(0.28, 0.75, -0.1);
    ant.rotation.z = -0.15;
    R.add(ant);
    const handset = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.22, 0.06), this.mats.black);
    handset.position.set(-0.45, 0.11, 0.05);
    R.add(handset);
    const led = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.01), new THREE.MeshBasicMaterial({ color: 0x33ff55 }));
    led.position.set(0.25, 0.27, 0.217);
    R.add(led);
    R.position.copy(this.radioPos);
    R.position.y = y + 0.85;
    this.root.add(R);
  }

  records(rd: RoomDef, y: number) {
    const { x0 } = rd;
    for (let r = 0; r < 3; r++) for (let i = 0; i < 3; i++) {
      if (r === 1 && i === 2) continue;
      this.box("metal", x0 + 1.5 + i * 2.5, y, -5.2 - r * 2.6, 1.6, 1.5, 0.6, { collide: true });
    }
    this.papers(x0 + 0.5, x0 + 7.5, -11.5, -2.5, y, 30);
    this.ceilingLamp(x0 + 4, y + FH - 0.2, -7, false);
  }

  windowsX(z: number, x0: number, x1: number, y: number, inward: number) {
    for (let x = x0 + 2; x < x1 - 1; x += 3) {
      this.box("glass", x, y + 1.1, z + inward * 0.11, 1.8, 1.5, 0.02);
      this.box("white", x, y + 1.05, z + inward * 0.15, 2.0, 0.06, 0.1);
      if (this.r() < 0.4) {
        // boarded up
        this.box("wood", x, y + 1.3, z + inward * 0.17, 2.1, 0.18, 0.04, { rz: 0.25 });
        this.box("wood", x, y + 1.8, z + inward * 0.17, 2.1, 0.18, 0.04, { rz: -0.2 });
      } else if (this.r() < 0.5) {
        // broken: shards on floor
        for (let k = 0; k < 6; k++) this.box("glass", x + (this.r() - 0.5) * 2, y + 0.01, z + inward * (0.4 + this.r()), 0.15, 0.01, 0.1, { ry: this.r() * 6 });
      }
    }
  }

  // ------------- build -------------
  build() {
    // ground outside + interior floor
    this.box("ground", 50, -0.3, -20, 560, 0.28, 560);
    this.slabs.push({ minx: -230, maxx: 330, minz: -300, maxz: 260, top: 0 });
    this.box("floor", 0, -0.02, 0, 60, 0.02, 24);
    // second floor slabs (hole for stairs, open over lobby)
    const f2 = (minx: number, maxx: number, minz: number, maxz: number) => {
      this.box("floor", (minx + maxx) / 2, FH - 0.2, (minz + maxz) / 2, maxx - minx, 0.2, maxz - minz, { slab: true });
      this.box("ceiling", (minx + maxx) / 2, FH - 0.22, (minz + maxz) / 2, maxx - minx, 0.02, maxz - minz);
    };
    f2(-30, 10, -12, 12);
    f2(10, 18, -12, 2);
    // roof terrace (hole over stairwell x 14..18, z 2..11)
    const roofPiece = (minx: number, maxx: number, minz: number, maxz: number) => {
      const cx = (minx + maxx) / 2, cz = (minz + maxz) / 2;
      this.box("ceiling", cx, 2 * FH - 0.2, cz, maxx - minx, 0.2, maxz - minz);
      this.box("concrete", cx, 2 * FH, cz, maxx - minx, 0.3, maxz - minz, { slab: true });
    };
    roofPiece(-30, 14, -12, 12);
    roofPiece(14, 18, -12, 2);
    roofPiece(14, 18, 11, 12);
    roofPiece(18, 30, -12, 12);
    // parapet
    this.box("brick", 0, 8.1, 11.9, 60.4, 1.0, 0.25, { collide: true });
    this.box("brick", 0, 8.1, -11.9, 60.4, 1.0, 0.25, { collide: true });
    this.box("brick", -29.9, 8.1, 0, 0.25, 1.0, 24.2, { collide: true });
    this.box("brick", 29.9, 8.1, 0, 0.25, 1.0, 24.2, { collide: true });
    this.box("concrete", 0, 9.08, 11.9, 60.5, 0.08, 0.35);
    this.box("concrete", 0, 9.08, -11.9, 60.5, 0.08, 0.35);
    this.box("concrete", -29.9, 9.08, 0, 0.35, 0.08, 24.3);
    this.box("concrete", 29.9, 9.08, 0, 0.35, 0.08, 24.3);

    // exterior walls
    this.wallX(12, -30, 30, 0, 2 * FH, [], "wall", 0.2);
    this.wallX(-12, -30, 30, 0, 2 * FH, [{ c: 6, w: 1.6, h: 2.5 }], "wall", 0.2);
    this.wallZ(-30, -12, 12, 0, 2 * FH, [{ c: 0, w: 1.6, h: 2.5 }], "wall", 0.2);
    this.wallZ(30, -12, 12, 0, 2 * FH, [{ c: 0, w: 3, h: 3 }], "wall", 0.2);
    this.box("brick", 0, 0, 12.2, 60.6, 2 * FH, 0.2);
    this.box("brick", 0, 0, -12.2, 60.6, 2 * FH, 0.2);
    this.box("brick", -30.2, 0, 0, 0.2, 2 * FH, 24.6);
    this.box("brick", 30.2, 0, -7.25, 0.2, 2 * FH, 9.5);
    this.box("brick", 30.2, 0, 7.25, 0.2, 2 * FH, 9.5);
    this.box("brick", 30.2, 3, 0, 0.2, 2 * FH - 3, 5);

    for (let f = 0; f < 2; f++) {
      const y = f * FH;
      this.windowsX(12, -30, f === 0 ? 18 : 18, y, -1);
      this.windowsX(-12, -30, 18, y, 1);
    }
    this.windowsX(12, 18, 30, 0, -1);
    this.windowsX(-12, 18, 30, 0, 1);
    this.windowsX(12, 18, 30, FH, -1);
    this.windowsX(-12, 18, 30, FH, 1);

    // corridor walls
    for (let f = 0; f < 2; f++) {
      const y = f * FH;
      const nOps = ROOMS.filter((r) => r.floor === f && r.side === "N").map((r) => ({ c: r.door, w: 2.2, h: 2.6 }));
      const sOps = ROOMS.filter((r) => r.floor === f && r.side === "S").map((r) => ({ c: r.door, w: 2.2, h: 2.6 }));
      this.wallX(2, -30, 10, y, FH, nOps);
      this.wallX(-2, -30, 18, y, FH, sOps);
      // room dividers
      for (const x of [-18, -6]) { this.wallZ(x, 2, 12, y, FH); this.wallZ(x, -12, -2, y, FH); }
      this.wallZ(2, -12, -2, y, FH);
      this.wallZ(10, 2, 12, y, FH);
      this.wallZ(18, -12, -2, y, FH);
      this.wallZ(18, 2, 12, y, FH);
      // corridor ceiling lamps
      for (let x = -27; x < 18; x += 4.5) {
        const on = this.r() < 0.7;
        this.ceilingLamp(x, y + FH - 0.2, 0, on, true);
        if (on) {
          this.light(x, y + FH - 0.45, 0, 0xffe8c4, 5.5, 15);
          this.light(x, y + FH - 1.3, 0, 0xffdcb0, 2.4, 18);   // soft wall wash
          this.light(x, y + 1.9, 0, 0xffe0b8, 1.3, 13);        // floor bounce
        }
      }

      this.papers(-29, 17, -1.7, 1.7, y, 25);
    }
    // stairs region
    this.wallX(2, 14, 18, 0, FH); // under run 2
    // F2 railing with gap for roof-access door at x=12
    this.box("metal", 10.6, FH, 2, 1.2, 1.05, 0.08);
    this.box("metal", 13.4, FH, 2, 1.2, 1.05, 0.08);
    this.colliders.push({ minx: 10, maxx: 11.3, miny: FH, maxy: FH + 2.2, minz: 1.9, maxz: 2.1 });
    this.colliders.push({ minx: 12.7, maxx: 14, miny: FH, maxy: FH + 2.2, minz: 1.9, maxz: 2.1 });
    this.wallZ(14, 2, 11, 0, 2 * FH, [], "plaster");
    // stair steps
    for (let i = 0; i < 8; i++) {
      const z0 = 2 + i * 1.125, top = (i + 1) * 0.25;
      this.box("floor", 12, 0, z0 + 0.5625, 3.9, top, 1.125, { slab: true });
    }
    this.box("floor", 14, 0, 11.5, 7.9, 2, 1, { slab: true }); // landing
    for (let j = 0; j < 8; j++) {
      const top = 2 + (j + 1) * 0.25;
      const z1 = 11 - j * 1.125;
      this.box("floor", 16, top - 0.25, z1 - 0.5625, 3.9, 0.25, 1.125, { slab: true });
      this.box("plaster", 16, top - 0.45, z1 - 0.5625, 3.9, 0.2, 1.125);
    }
    this.colliders.push({ minx: 14, maxx: 18, miny: 0, maxy: 2, minz: 2, maxz: 11 }); // solid under run2 (behind wall)
    this.light(15, 3, 11.5, 0xff2222, 1.2, 9, true);
    this.box("emergency", 17.85, 3, 11.5, 0.08, 0.2, 0.4);
    this.sign("STAIRS  ↑", 12, 2.8, 1.88, Math.PI, "#3a3a3a");
    // F2 -> roof: run C (x=12, z 2->11, y 4->6)
    for (let i = 0; i < 8; i++) {
      const top = FH + (i + 1) * 0.25;
      const zc = 2 + i * 1.125 + 0.5625;
      this.box("floor", 12, top - 0.25, zc, 3.9, 0.25, 1.125, { slab: true });
      this.box("plaster", 12, top - 0.45, zc, 3.9, 0.2, 1.125);
    }
    this.box("floor", 14, FH + 1.75, 11.5, 7.9, 0.25, 1, { slab: true });
    this.box("plaster", 14, FH + 1.55, 11.5, 7.9, 0.2, 1);
    // run D (x=16, z 11->2, y 6->8)
    for (let j = 0; j < 8; j++) {
      const top = FH + 2 + (j + 1) * 0.25;
      const zc = 11 - j * 1.125 - 0.5625;
      this.box("floor", 16, top - 0.25, zc, 3.9, 0.25, 1.125, { slab: true });
      this.box("plaster", 16, top - 0.45, zc, 3.9, 0.2, 1.125);
    }
    // roof access door (sealed until the military override)
    this.addDoor("roof", "ROOF ACCESS", 12, FH, 2, 1, "key_roof");
    this.sign("ROOF ACCESS", 12, FH + 2.85, 1.88, Math.PI, "#5a1a1a");
    this.light(12, FH + 3.2, 6, 0xff2222, 1.1, 9, true);
    // roof bulkhead around the stair hole
    this.box("brick", 14, 8.3, 6.6, 0.25, 2.3, 9.2, { collide: true });
    this.box("brick", 18, 8.3, 6.6, 0.25, 2.3, 9.2, { collide: true });
    this.box("brick", 16, 8.3, 11.2, 4.25, 2.3, 0.25, { collide: true });
    this.box("brick", 14.55, 8.3, 2, 1.1, 2.3, 0.25, { collide: true });
    this.box("brick", 17.45, 8.3, 2, 1.1, 2.3, 0.25, { collide: true });
    this.box("brick", 16, 10.1, 2, 4.25, 0.5, 0.25, { collide: true });
    this.box("darkmetal", 16, 10.6, 6.6, 4.8, 0.25, 9.8);
    this.sign("ROOF", 16, 9.8, 1.86, Math.PI, "#0a5a1a", 1.2);
    // roof props
    this.box("metal", -20, 8.3, -8, 2.4, 1.3, 1.8, { collide: true });
    this.box("darkmetal", -20, 9.6, -8, 1.0, 0.1, 1.0);
    this.box("metal", -2, 8.3, 8.5, 2.0, 1.1, 1.6, { collide: true });
    this.box("white", 23, 9.3, 8, 2.6, 2.4, 2.6, { collide: true });
    for (const [lx, lz] of [[21.9, 6.9], [24.1, 6.9], [21.9, 9.1], [24.1, 9.1]]) this.box("darkmetal", lx, 8.3, lz, 0.18, 1.0, 0.18);
    this.colliders.push({ minx: 21.6, maxx: 24.4, miny: 8.3, maxy: 11.7, minz: 6.6, maxz: 9.4 });
    this.box("darkmetal", 19, 8.3, 10.8, 0.15, 3.4, 0.15);
    this.box("emergency", 19, 11.7, 10.8, 0.22, 0.22, 0.22);
    this.light(19, 11.6, 10.4, 0xff2020, 1.4, 16, true);
    for (let v = 0; v < 4; v++) this.box("darkmetal", -26 + v * 3, 8.3, 9.5, 0.6, 0.5, 0.6, { collide: true });
    this.box("military", -4, 8.3, 3.2, 1.2, 0.8, 0.8, { collide: true });
    this.box("emergency", -6.5, 8.32, 2.2, 0.1, 0.06, 0.25);
    this.light(-6.5, 8.6, 2.2, 0xff3010, 1.2, 8, true);
    this.papers(-24, 20, -10, 10, 8.3, 14);
    // helipad "H"
    this.box("paintY", -9.5, 8.305, 0, 0.55, 0.012, 4.6);
    this.box("paintY", -6.5, 8.305, 0, 0.55, 0.012, 4.6);
    this.box("paintY", -8, 8.305, 0, 2.6, 0.012, 0.55);
    this.box("paintY", -8, 8.302, 4.2, 9, 0.01, 0.45);
    this.box("paintY", -8, 8.302, -4.2, 9, 0.01, 0.45);
    this.box("paintY", -12.3, 8.302, 0, 0.45, 0.01, 8.9);
    this.box("paintY", -3.7, 8.302, 0, 0.45, 0.01, 8.9);

    // F2 railing overlooking lobby
    this.box("metal", 18, FH, 0, 0.08, 1.05, 4);
    this.box("metal", 18, FH + 1.0, 0, 0.12, 0.06, 4.1);
    this.colliders.push({ minx: 17.9, maxx: 18.1, miny: FH, maxy: FH + 2.2, minz: -2, maxz: 2 });

    // lobby
    this.box("ceiling", 24, 2 * FH - 0.22, 0, 12, 0.02, 24);
    this.box("darkwood", 22.5, 0, 6, 1, 1.1, 3.4, { collide: true }); // reception desk
    this.box("wood", 22.5, 1.1, 6, 1.2, 0.05, 3.6);
    this.box("glass", 21.5, 0, -10.5, 3, 2.2, 0.8, { collide: true }); // trophy case
    this.box("darkwood", 25, 0, -11.5, 3, 0.45, 0.5, { collide: true });
    this.sign("RIVERSIDE HIGH SCHOOL", 24, 6, 11.85, Math.PI, "#1b3a4d", 6);
    this.sign("MAIN ENTRANCE", 29.85, 3.4, 0, -Math.PI / 2, "#5a1010", 2.4);
    this.box("exit", 29.85, 3.15, 0, 0.04, 0.15, 0.6);
    this.bloodPool(26, 0, 1.5, 1.6);
    this.bloodPool(23, 0, -3);
    this.papers(19, 29, -11, 11, 0, 30);
    for (let x = 21; x < 30; x += 4) for (const z of [-6, 6]) this.ceilingLamp(x, 2 * FH - 0.22, z, this.r() < 0.4);
    this.light(28, 3.5, -4, 0xff2020, 1.4, 12, true);
    this.box("emergency", 29.85, 3.5, -4, 0.06, 0.2, 0.4);
    // entrance doors (glass) + barricade
    const bm = this.mats;
    const addB = (mat: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number, rx = 0, ry = 0, rz = 0) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat);
      m.position.set(x, y, z);
      m.rotation.set(rx, ry, rz);
      this.barricade.add(m);
    };
    for (let i = 0; i < 9; i++) addB(bm.wood, 29 - (i % 3) * 0.7, 0.4 + Math.floor(i / 3) * 0.7, -1.6 + (i % 4) * 1.0, 1.2, 0.08, 0.6, this.r(), this.r() * 3, this.r());
    for (let i = 0; i < 4; i++) addB(bm.darkmetal, 28.7, 0.2 + i * 0.5, -1 + i * 0.6, 0.5, 0.5, 0.5, this.r(), this.r(), 0);
    addB(bm.wood, 29.6, 1.3, 0, 0.1, 0.2, 3.4, 0.3, 0, 0);
    addB(bm.wood, 29.6, 2.0, 0, 0.1, 0.2, 3.4, -0.3, 0, 0);
    addB(bm.yellow, 29.95, 1.2, 0, 0.05, 0.6, 0.05);
    this.root.add(this.barricade);
    this.barricadeBox = { minx: 27.8, maxx: 30, miny: 0, maxy: 3, minz: -1.8, maxz: 1.8 };
    this.colliders.push(this.barricadeBox);
    this.exits.push({ x: 28.5, y: 0, z: 0, text: "Main entrance is barricaded and chained shut. The street outside is swarming." });

    // west emergency exit (chained)
    this.box("red", -29.85, 0, 0, 0.1, 2.5, 1.6);
    this.box("metal", -29.75, 1.1, 0, 0.06, 0.08, 1.5);
    this.box("yellow", -29.72, 0.9, 0, 0.04, 0.5, 0.06);
    this.box("exit", -29.85, 2.7, 0, 0.04, 0.2, 0.7);
    this.sign("EMERGENCY EXIT", -29.85, 3.1, 0, Math.PI / 2, "#0a5a1a", 1.8);
    this.exits.push({ x: -29.2, y: 0, z: 0, text: "Emergency exit is chained from the outside. Something keeps pushing on it..." });
    this.light(-29, 3.2, 0, 0xff2020, 1.2, 10, true);
    // cafeteria back exit (debris)
    this.box("red", 6, 0, -11.85, 1.6, 2.5, 0.1);
    for (let i = 0; i < 6; i++) this.box(i % 2 ? "darkmetal" : "wood", 6 + (this.r() - 0.5) * 2, i * 0.35, -11.2 + this.r() * 0.4, 1.2, 0.35, 0.7, { ry: this.r(), collide: true });
    this.exits.push({ x: 6, y: 0, z: -10.4, text: "Back exit is buried under collapsed debris. No way through." });
    // F2 corridor west window blocked
    this.box("wood", -29.8, FH + 0.8, 0, 0.1, 1.8, 2.2);

    // rooms
    for (const rd of ROOMS) {
      const y = rd.floor * FH;
      const s = rd.side === "N" ? 1 : -1;
      const fn: Record<string, (r: RoomDef, y: number) => void> = {
        classroom: this.classroom, lab: this.lab, library: this.library, staff: this.staff, security: this.security,
        cafeteria: this.cafeteria, principal: this.principal, office: this.office, records: this.records,
      };
      fn[rd.type].call(this, rd, y);
      const startOpen = !rd.lock && rd.id !== "c1a" && this.r() < 0.6;
      this.addDoor(rd.id, rd.name, rd.door, y, s * 2, s as 1 | -1, rd.lock, startOpen);
      this.sign(rd.name, rd.door, y + 2.85, s * 1.88, s === 1 ? Math.PI : 0, rd.lock ? "#5a1a1a" : "#1b3a4d");
    }

    // corridor props: lockers + blood + lights
    for (let f = 0; f < 2; f++) {
      const y = f * FH;
      for (const x of [-25, -14, -4, 6]) this.locker(x, y, 1.65, Math.PI, 4);
      for (const x of [-26, -15, 5]) this.locker(x, y, -1.65, 0, 3);
      this.bloodPool(-12 + f * 8, y, 0.3, 1.3);
      this.bloodPool(8 - f * 20, y, -0.6);
    }
    // overturned stuff in corridor
    this.chair(-17, 0, -0.8, 1.2, true);
    this.desk(-3.5, 0, 0.9, 1.4, true);
    this.chair(9, FH, 0.6, 0.3, true);
    this.box("military", -10, FH, -1.3, 1.2, 0.9, 0.6, { collide: true }); // barricade remains
    this.box("wood", -10.3, FH, 0.2, 0.3, 1.2, 1.5, { collide: true, ry: 0.4 });

    // Lighting (budget scales with quality)
    // PBR surfaces need a strong ambient term or everything reads black
    this.hemi = new THREE.HemisphereLight(0x93a9c6, 0x413629, 1.25);
    this.root.add(this.hemi);
    this.root.add(new THREE.AmbientLight(0x6d7789, 0.85));
    // cold moonlight — mainly sells the rooftop and exterior
    const moon = new THREE.DirectionalLight(0xa8bce0, 0.55);
    moon.position.set(-60, 90, 40);
    this.root.add(moon);
    this.light(-24, 3.2, 7, 0xffe6c0, 1.6, 10); // start classroom
    this.light(-12, FH + 3.2, -8, 0xffe6c0, 1.8, 11); // office
    this.light(-8, 3.4, 0, 0xff2020, 1.3, 12, true);
    this.light(-16, FH + 3.4, 0, 0xff2020, 1.3, 12, true);
    if (this.quality >= 1) {
      this.light(4, 3.2, 0, 0xd0e0ff, 1.2, 10);
      this.light(6, FH + 3.2, 0, 0xff2020, 1.2, 11, true);
      this.light(-2, 3.2, 8, 0xd0e0ff, 1.0, 10);
    }
    if (this.quality >= 2) {
      this.light(10, 3.2, -7, 0xffe6c0, 1.0, 10);
      this.light(-24, FH + 3.2, -7, 0xffe6c0, 1.0, 10);
      this.light(24, 5, 0, 0x8899ff, 1.0, 14);
    }

    // exterior: fence, cars, trees silhouettes
    for (let x = -50; x <= 50; x += 4) { this.box("darkmetal", x, 0, 25, 0.1, 2.2, 0.1); this.box("darkmetal", x, 0, -25, 0.1, 2.2, 0.1); }
    this.box("darkmetal", 0, 1.9, 25, 100, 0.08, 0.06);
    this.box("darkmetal", 0, 1.9, -25, 100, 0.08, 0.06);
    const carCols = ["red", "darkmetal", "white", "green"];
    for (let i = 0; i < 6; i++) {
      const cx = 36 + (i % 2) * 6, cz = -14 + i * 5.5, ry = this.r() * 0.6;
      const c = carCols[i % 4];
      this.box(c, cx, 0.2, cz, 4.2, 0.7, 1.8, { ry });
      this.box(c, cx - 0.3, 0.9, cz, 2.2, 0.6, 1.6, { ry });
      this.box("glass", cx - 0.3, 0.95, cz, 2.25, 0.45, 1.65, { ry });
    }
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2, rr = 34 + this.r() * 7;
      this.box("darkwood", Math.cos(a) * rr, 0, Math.sin(a) * rr, 0.4, 3, 0.4);
      this.box("green", Math.cos(a) * rr, 2.5, Math.sin(a) * rr, 3, 3, 3, { ry: this.r() });
    }
    this.buildOutskirts();
    this.buildCity();
    this.buildSky();
    this.buildLab();

    this.buildPickups();
    this.buildNotes();
    this.buildNav();
    buildCity2(this);
  }

  car(cx: number, cz: number, ry: number, c: string, wreck = false) {
    this.box(c, cx, 0.2, cz, 4.2, 0.7, 1.8, { ry });
    this.box(c, cx - 0.3, 0.9, cz, 2.2, 0.6, 1.6, { ry });
    this.box("glass", cx - 0.3, 0.95, cz, 2.25, 0.45, 1.65, { ry });
    if (wreck) this.box("black", cx + 1.2, 0.9, cz, 1.2, 0.5, 1.4, { ry: ry + 0.4 });
  }

  buildOutskirts() {
    // street lights (a few still on)
    for (let z = -72; z <= 72; z += 18) {
      this.box("darkmetal", 61, 0, z, 0.22, 6.2, 0.22);
      this.box("darkmetal", 62, 6.1, z, 2.2, 0.15, 0.15);
      this.box(this.r() < 0.4 ? "lamp" : "lampOff", 63, 5.95, z, 0.6, 0.15, 0.3);
    }
    for (let x = -60; x <= 40; x += 22) {
      this.box("darkmetal", x, 0, 44.5, 0.22, 6.2, 0.22);
      this.box(this.r() < 0.35 ? "lamp" : "lampOff", x, 6.0, 45.8, 0.3, 0.15, 0.6);
    }
    // abandoned vehicles on the roads
    const cc = ["red", "darkmetal", "white", "green", "fabric"];
    for (let i = 0; i < 7; i++) this.car(66 + (i % 2) * 4, -60 + i * 18 + this.r() * 6, this.r() * 0.9 - 0.45 + (i % 2) * Math.PI, cc[i % 5], this.r() < 0.4);
    for (let i = 0; i < 4; i++) this.car(-50 + i * 26, 49 + this.r() * 4, Math.PI / 2 + this.r() * 0.8, cc[(i + 2) % 5], this.r() < 0.4);
    // crashed school bus at the junction
    this.box("yellow", 64, 0.3, 42, 9, 2.1, 2.5, { ry: 0.5 });
    this.box("glass", 64, 1.5, 42, 9.1, 0.7, 2.55, { ry: 0.5 });
    this.box("black", 60.5, 0.1, 44.5, 1.1, 1.1, 0.4, { ry: 0.5 });
  }

  fireGlows: THREE.MeshBasicMaterial[] = [];

  buildCity() {
    const texs = [cityTexture(0), cityTexture(1), cityTexture(2)];
    const mats = texs.map((t) => new THREE.MeshBasicMaterial({ map: t, fog: false }));
    const geoLists: THREE.BufferGeometry[][] = [[], [], []];
    const addB = (x: number, z: number, sx: number, sy: number, sz: number, v: number) => {
      const g = new THREE.BoxGeometry(sx, sy, sz);
      const uv = g.attributes.uv as THREE.BufferAttribute;
      for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * Math.max(1, Math.round(sx / 14)), uv.getY(i) * Math.max(1, Math.round(sy / 26)));
      g.translate(x, sy / 2 - 0.5, z);
      geoLists[v].push(g);
    };
    const spots: { x: number; z: number }[] = [];
    const place = (n: number, gen: () => { x: number; z: number }) => {
      for (let i = 0; i < n; i++) {
        const p = gen();
        if (spots.some((s) => Math.abs(s.x - p.x) < 24 && Math.abs(s.z - p.z) < 24)) continue;
        spots.push(p);
        const d = Math.hypot(p.x - 50, p.z);
        const sy = 14 + this.r() * (d * 0.12);
        addB(p.x, p.z, 14 + this.r() * 16, sy, 14 + this.r() * 16, Math.floor(this.r() * 3));
        if (this.r() < 0.35) addB(p.x + 5, p.z - 4, 7 + this.r() * 6, sy + 5 + this.r() * 12, 7 + this.r() * 6, Math.floor(this.r() * 3));
      }
    };
    // decorative skyline ring — kept OUTSIDE the playable city (x -230..330, z -300..260 is play space)
    place(40, () => {
      const a = this.r() * Math.PI * 2, rr = 360 + this.r() * 140;
      return { x: 50 + Math.cos(a) * rr, z: -20 + Math.sin(a) * rr };
    });
    geoLists.forEach((list, i) => {
      if (!list.length) return;
      const merged = mergeGeometries(list, false);
      if (!merged) return;
      const m = new THREE.Mesh(merged, mats[i]);
      m.matrixAutoUpdate = false;
      m.updateMatrix();
      m.frustumCulled = true;
      this.root.add(m);
      list.forEach((g) => g.dispose());
    });
    // burning buildings: glow + smoke columns
    const smokeT = smokeTexture();
    const firePts = [{ x: 390, z: 60 }, { x: 310, z: -250 }, { x: -200, z: 210 }, { x: -120, z: -280 }];
    for (const f of firePts) {
      const h = 14 + this.r() * 20;
      const glowM = new THREE.MeshBasicMaterial({ color: 0xff5a10, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
      this.fireGlows.push(glowM);
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(8, 5), glowM);
      const ang = Math.atan2(-f.x, -f.z);
      glow.position.set(f.x + Math.sin(ang) * 7.5, h, f.z + Math.cos(ang) * 7.5);
      glow.rotation.y = ang;
      this.root.add(glow);
      for (let s = 0; s < 3; s++) {
        const sm = new THREE.Mesh(new THREE.PlaneGeometry(22 + s * 14, 30 + s * 16), new THREE.MeshBasicMaterial({ map: smokeT, transparent: true, opacity: 0.8, depthWrite: false, side: THREE.DoubleSide, fog: false }));
        sm.position.set(f.x + (this.r() - 0.5) * 10, h + 16 + s * 18, f.z + (this.r() - 0.5) * 10);
        sm.rotation.y = ang + (this.r() - 0.5) * 0.6;
        this.root.add(sm);
      }
    }
  }

  // Secret laboratory — cutscene-only set, hidden far below the world (never reachable in gameplay)
  labY = -60;
  labLight!: THREE.PointLight;
  labAlarm!: THREE.PointLight;
  labTank!: THREE.Mesh;
  labMonitors: THREE.Mesh[] = [];
  buildLab() {
    const y = this.labY;
    const cx = 0, cz = -200;
    // room shell 16 x 10
    this.box("darkmetal", cx, y - 0.2, cz, 16, 0.2, 10);
    this.box("floor", cx, y - 0.02, cz, 16, 0.02, 10);
    this.box("darkmetal", cx, y + 4, cz, 16, 0.2, 10);
    this.box("plaster", cx, y, cz - 5, 16, 4, 0.2);
    this.box("plaster", cx, y, cz + 5, 16, 4, 0.2);
    this.box("plaster", cx - 8, y, cz, 0.2, 4, 10);
    this.box("plaster", cx + 8, y, cz, 0.2, 4, 10);
    // exit door frame on east wall
    this.box("darkmetal", cx + 7.9, y, cz + 3, 0.15, 2.6, 1.4);
    this.box("exit", cx + 7.85, y + 2.8, cz + 3, 0.05, 0.2, 0.7);
    // containment tank (subject stands inside)
    const tankMat = new THREE.MeshLambertMaterial({ color: 0x2a6a7a, emissive: 0x16404a, emissiveIntensity: 0.9, transparent: true, opacity: 0.32 });
    this.labTank = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 2.6, 14, 1, true), tankMat);
    this.labTank.position.set(cx - 2, y + 1.5, cz - 1);
    this.root.add(this.labTank);
    this.box("metal", cx - 2, y, cz - 1, 2.4, 0.25, 2.4);
    this.box("metal", cx - 2, y + 2.8, cz - 1, 2.4, 0.3, 2.4);
    for (let i = 0; i < 6; i++) this.box("darkmetal", cx - 2 + Math.cos(i) * 1.0, y + 0.25, cz - 1 + Math.sin(i) * 1.0, 0.08, 2.6, 0.08);
    // cables + pump
    this.box("black", cx - 2, y + 3.1, cz - 2.5, 0.12, 0.12, 3.2);
    this.box("darkmetal", cx - 2, y, cz - 4.2, 1.6, 1.4, 1.0);
    this.box("emergency", cx - 2.4, y + 1.0, cz - 3.68, 0.1, 0.1, 0.05);
    // monitor desk
    this.box("darkmetal", cx + 2.5, y, cz - 3.6, 4.5, 0.8, 1.0);
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.6, 0.06), new THREE.MeshBasicMaterial({ color: 0x1a4a3a }));
      m.position.set(cx + 1 + i * 1.0, y + 1.25, cz - 3.9);
      this.root.add(m);
      this.labMonitors.push(m);
    }
    this.chair(cx + 2.5, y, cz - 2.6, Math.PI);
    // lab benches with glassware
    this.box("white", cx + 4, y, cz + 2, 3.6, 0.9, 1.2);
    this.box("black", cx + 4, y + 0.9, cz + 2, 3.7, 0.05, 1.3);
    for (let i = 0; i < 7; i++) this.box("bottle", cx + 2.6 + i * 0.45, y + 0.95, cz + 1.7 + (i % 2) * 0.5, 0.1, 0.25 + (i % 3) * 0.1, 0.1);
    this.box("metal", cx - 6, y, cz + 2.5, 1.2, 2.2, 3.5); // fridge/cabinets
    this.box("glass", cx - 5.38, y + 0.6, cz + 2.5, 0.02, 1.2, 3.0);
    // framed photo of the wife on the desk
    this.box("darkwood", cx + 4.4, y + 0.95, cz - 3.5, 0.22, 0.28, 0.03);
    this.box("white", cx + 4.4, y + 1.0, cz - 3.49, 0.16, 0.18, 0.01);
    // papers everywhere
    this.papers(cx - 7, cx + 7, cz - 4, cz + 4, y, 18);
    this.papers(cx - 7, cx + 7, cz - 4, cz + 4, y, 10);
    // lights
    this.labLight = new THREE.PointLight(0x7ad0e0, 3.2, 18, 1.3);
    const fill = new THREE.PointLight(0x8aa0b8, 1.2, 20, 1.2);
    fill.position.set(cx + 5, y + 3.2, cz + 3);
    this.root.add(fill);
    this.labLight.position.set(cx - 2, y + 2.4, cz - 1);
    this.root.add(this.labLight);
    const warm = new THREE.PointLight(0xffd0a0, 1.6, 14, 1.4);
    warm.position.set(cx + 3, y + 3, cz - 2);
    this.root.add(warm);
    this.labAlarm = new THREE.PointLight(0xff2020, 0, 18, 1.2);
    this.labAlarm.position.set(cx, y + 3.5, cz);
    this.root.add(this.labAlarm);
    this.box("emergency", cx, y + 3.7, cz + 4.9, 0.4, 0.15, 0.1);
    this.sign("BIO-LEVEL 4 — AUTHORIZED PERSONNEL ONLY", cx, y + 3.2, cz + 4.88, Math.PI, "#5a1a1a", 5);
    this.sign("PROJECT LAZARUS", cx - 7.88, y + 3.0, cz, Math.PI / 2, "#1a3a5a", 3);
  }

  buildSky() {
    const sky = new THREE.Mesh(new THREE.SphereGeometry(420, 20, 14), new THREE.MeshBasicMaterial({ map: skyTexture(), side: THREE.BackSide, fog: false, depthWrite: false }));
    sky.rotation.y = 1.2;
    sky.renderOrder = -10;
    this.root.add(sky);
  }

  buildPickups() {
    const P = (id: string, kind: PickupKind, x: number, y: number, z: number, where: string) => this.pickups.push({ id, kind, x, y, z, where });
    const F = FH;
    P("flash1", "flashlight", -28, 0.8, 7.4, "teacher's desk");
    P("pistol0", "pistol", -28, 0.82, 6.4, "teacher's desk — from the security guard");
    P("hp_c1a", "health", -19.2, 1.0, 9, "locker");
    P("hp_c1b", "health", -28, 0.8, -7.2, "teacher's desk");
    P("pistol1", "pistol", -14, 0.93, -11.6, "staff counter");
    P("ap_staff1", "ammo_pistol", -12, 0.8, -7, "meeting table");
    P("ap_staff2", "ammo_pistol", -16.5, 0.95, -11.6, "counter");
    P("key_jan", "key_janitor", -14, 0.9, 7.5, "lab bench");
    P("hp_lab", "health", -6.6, 0.95, 5.5, "lab cabinet");
    P("shotgun1", "shotgun", -5.5, 1.93, -6, "gun locker");
    P("as_sec1", "ammo_shotgun", 0.7, 1.42, -8.3, "supply crate");
    P("as_sec2", "ammo_shotgun", 0.6, 0.82, -3.4, "security desk");
    P("ap_sec", "ammo_pistol", -4.5, 0.55, -11.1, "metal shelf");
    P("key_prin", "key_principal", 7, 1.07, 3.6, "librarian's desk");
    P("ap_lib", "ammo_pistol", 2.2, 0.8, 5.8, "reading table");
    P("hp_caf", "health", 17, 1.05, -8, "serving counter");
    P("as_caf", "ammo_shotgun", 10, 0.78, -9.3, "cafeteria table");
    P("ap_lobby", "ammo_pistol", 22.5, 1.15, 5, "reception desk");
    P("ap_c2a", "ammo_pistol", -28, F + 0.8, 7.2, "teacher's desk");
    P("hp_c2a", "health", -19, F + 0.05, 4, "floor");
    P("as_c2b", "ammo_shotgun", -16, F + 0.8, 6.6, "teacher's desk");
    P("ap_c2c", "ammo_pistol", -4, F + 0.8, 7.2, "teacher's desk");
    P("hp_c2d", "health", 4, F + 0.8, -6.8, "teacher's desk");
    P("ar_c2d", "ammo_rifle", 16.5, F + 0.05, -11.3, "floor");
    P("rifle1", "rifle", -24, F + 0.85, -9, "principal's desk");
    P("ar_prin1", "ammo_rifle", -29.4, F + 1.32, -4, "cabinet");
    P("ar_prin2", "ammo_rifle", -19, F + 0.46, -5, "sofa");
    P("key_off", "key_office", -24.8, F + 0.85, -8.7, "principal's desk");
    P("ar_rec", "ammo_rifle", -2, F + 1.52, -7.8, "filing cabinet");
    P("hp_rec", "health", -4.5, F + 1.52, -5.2, "filing cabinet");
    P("hp_off", "health", -7.2, F + 0.82, -9, "office desk");
    P("as_off", "ammo_shotgun", -14, F + 1.17, -4.8, "front counter");
  }

  buildNotes() {
    const N = (id: string, x: number, y: number, z: number, title: string, text: string) => this.notes.push({ id, x, y, z, title, text });
    N("n1", -25.5, 0.8, 4.2, "Crumpled note", "Mr. Thomas told us to hide here and stay quiet. He went to get help. That was hours ago. I can hear them scratching at the lockers.");
    N("n2", -11, 0.8, -7.2, "Staff memo", "EMERGENCY: Keep the Security room locked. The janitor took the spare key to the Science Lab when he went to seal the windows. Principal Rao has the office keys.");
    N("n3", -9.5, 0.9, 6.2, "Lab journal", "The sample arrived from the hospital this morning... no. Don't think about it. The janitor's key is on bench two. Whoever finds this: the military radio is in the School Office upstairs.");
    N("n4", 4, 0.8, 5.4, "Library sign-out sheet", "Principal Rao left her keys here before running upstairs. Her office has the ONLY copy of the School Office key.");
    N("n5", -23.2, FH + 0.85, -9.2, "Principal's diary", "Day 1. Army dropped off an emergency radio for the evacuation drill. Locked it in the School Office. The roads are gone. If anyone reads this, USE THE RADIO.");
    N("n6", 24, 0, 2.5, "Blood-stained flyer", "SPRING CONCERT CANCELLED. Written over it in marker: 'WE BARRICADED THE DOORS. DON'T OPEN THEM. —D.'");
  }

  buildNav() {
    const nodes: NavNode[] = this.nav;
    const add = (x: number, y: number, z: number) => { const n = { id: nodes.length, x, y, z, edges: [] }; nodes.push(n); return n; };
    const link = (a: NavNode, b: NavNode, door?: string) => { a.edges.push({ to: b.id, door }); b.edges.push({ to: a.id, door }); };
    const corridor: NavNode[][] = [[], []];
    for (let f = 0; f < 2; f++) {
      let prev: NavNode | null = null;
      for (let x = -28; x <= 16; x += 4) {
        const n = add(x, f * FH, 0);
        corridor[f].push(n);
        if (prev) link(prev, n);
        prev = n;
      }
    }
    const nearestCor = (f: number, x: number) => corridor[f].reduce((a, b) => (Math.abs(b.x - x) < Math.abs(a.x - x) ? b : a));
    for (const rd of ROOMS) {
      const y = rd.floor * FH, s = rd.side === "N" ? 1 : -1;
      const out = add(rd.door, y, s * 0.9);
      const inn = add(rd.door, y, s * 3.2);
      const center = add((rd.x0 + rd.x1) / 2, y, s * 7);
      link(nearestCor(rd.floor, rd.door), out);
      link(out, inn, rd.id);
      link(inn, center);
      const corners = [add(rd.x0 + 1.5, y, s * 3.2), add(rd.x0 + 1.5, y, s * 10.8), add(rd.x1 - 1.5, y, s * 10.8)];
      link(center, corners[0]); link(center, corners[1]); link(center, corners[2]);
    }
    // lobby
    const l1 = add(20, 0, 0), l2 = add(24, 0, 4), l3 = add(24, 0, -4), l4 = add(27, 0, 8), l5 = add(27, 0, -8);
    link(corridor[0][corridor[0].length - 1], l1); link(l1, l2); link(l1, l3); link(l2, l4); link(l3, l5); link(l2, l3);
    // stairs
    const s1 = add(12, 0.25, 2.8), s2 = add(12, 2, 11.3), s3 = add(16, 2, 11.3), s4 = add(16, FH, 2.6);
    link(nearestCor(0, 12), s1); link(s1, s2); link(s2, s3); link(s3, s4); link(s4, nearestCor(1, 16));
    // roof route
    const rd0 = add(12, FH, 1.2), rc1 = add(12, FH + 0.25, 2.8), rc2 = add(12, FH + 2, 11.3), rc3 = add(16, FH + 2, 11.3), rc4 = add(16, FH + 4, 2.4);
    const rf1 = add(16, 8.3, 0), rf2 = add(-8, 8.3, 0), rf3 = add(24, 8.3, 0), rf4 = add(-22, 8.3, -5), rf5 = add(0, 8.3, 7);
    link(nearestCor(1, 12), rd0); link(rd0, rc1, "roof"); link(rc1, rc2); link(rc2, rc3); link(rc3, rc4); link(rc4, rf1);
    link(rf1, rf2); link(rf1, rf3); link(rf2, rf4); link(rf2, rf5);
  }

  finalize() {
    for (const [mat, list] of this.geos) {
      const merged = mergeGeometries(list, false);
      if (!merged) continue;
      const m = new THREE.Mesh(merged, this.mats[mat]);
      m.matrixAutoUpdate = false;
      m.updateMatrix();
      this.root.add(m);
      list.forEach((g) => g.dispose());
    }
    this.geos.clear();
  }

  groundAt(x: number, z: number, y: number) {
    let best = -100;
    for (const s of this.slabs) {
      if (x >= s.minx && x <= s.maxx && z >= s.minz && z <= s.maxz && s.top <= y + 0.45 && s.top > best) best = s.top;
    }
    return best;
  }

  setNormalDay(on: boolean) {
    this.hemi.intensity = on ? 1.9 : 1.25;
    this.lampMat.emissiveIntensity = on ? 1.8 : 1.5;
    this.barricade.visible = !on;
  }
}
