import * as THREE from "three";

export type WeaponId = "pistol" | "shotgun" | "rifle";

export interface WeaponDef {
  id: WeaponId; name: string; mag: number; dmg: number; pellets: number; spread: number;
  rate: number; auto: boolean; reload: number; recoil: number; range: number; pickupAmmo: number;
  hip: THREE.Vector3; ads: THREE.Vector3; adsFov: number;
}

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  pistol: { id: "pistol", name: "M9 PISTOL", mag: 12, dmg: 34, pellets: 1, spread: 0.014, rate: 0.2, auto: false, reload: 1.3, recoil: 1, range: 60, pickupAmmo: 24,
    hip: new THREE.Vector3(0.2, -0.2, -0.42), ads: new THREE.Vector3(0, -0.118, -0.34), adsFov: 55 },
  shotgun: { id: "shotgun", name: "PUMP SHOTGUN", mag: 6, dmg: 17, pellets: 9, spread: 0.075, rate: 0.85, auto: false, reload: 2.0, recoil: 2.4, range: 25, pickupAmmo: 8,
    hip: new THREE.Vector3(0.2, -0.2, -0.5), ads: new THREE.Vector3(0, -0.135, -0.42), adsFov: 58 },
  rifle: { id: "rifle", name: "M4 ASSAULT RIFLE", mag: 30, dmg: 27, pellets: 1, spread: 0.02, rate: 0.095, auto: true, reload: 2.0, recoil: 0.8, range: 80, pickupAmmo: 60,
    hip: new THREE.Vector3(0.2, -0.21, -0.5), ads: new THREE.Vector3(0, -0.142, -0.4), adsFov: 45 },
};

const skin = new THREE.MeshLambertMaterial({ color: 0xc08a64 });
const sleeve = new THREE.MeshLambertMaterial({ color: 0x2d3a4a });
const glove = new THREE.MeshLambertMaterial({ color: 0x222222 });
const gun = new THREE.MeshLambertMaterial({ color: 0x2a2c30 });
const gunLight = new THREE.MeshLambertMaterial({ color: 0x4a4d52 });
const woodM = new THREE.MeshLambertMaterial({ color: 0x6b4426 });
const sightM = new THREE.MeshBasicMaterial({ color: 0xff5522 });

function bx(parent: THREE.Object3D, mat: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  parent.add(m);
  return m;
}

function arm(parent: THREE.Object3D, hx: number, hy: number, hz: number, side: number) {
  // hand at (hx,hy,hz); forearm extends back/down/outward
  const g = new THREE.Group();
  g.position.set(hx, hy, hz);
  bx(g, glove, 0, 0, 0, 0.06, 0.07, 0.09);
  bx(g, skin, 0, -0.01, 0.07, 0.055, 0.055, 0.06);
  const fore = bx(g, sleeve, side * 0.04, -0.06, 0.22, 0.075, 0.075, 0.32, 0.35, side * 0.15, 0);
  fore.name = "fore";
  parent.add(g);
  return g;
}

export function muzzleTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, "rgba(255,255,220,1)");
  grd.addColorStop(0.3, "rgba(255,200,80,0.9)");
  grd.addColorStop(1, "rgba(255,80,0,0)");
  g.fillStyle = grd;
  g.beginPath();
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2, r = i % 2 ? 12 : 32;
    g.lineTo(32 + Math.cos(a) * r, 32 + Math.sin(a) * r);
  }
  g.fill();
  return new THREE.CanvasTexture(c);
}

export interface ViewModel { group: THREE.Group; muzzle: THREE.Object3D; mag?: THREE.Object3D; pump?: THREE.Object3D; leftArm: THREE.Object3D }

export function buildViewModel(id: WeaponId | "hands", flashTex: THREE.Texture): ViewModel {
  const g = new THREE.Group();
  const muzzle = new THREE.Object3D();
  let mag: THREE.Object3D | undefined, pump: THREE.Object3D | undefined;
  let leftArm: THREE.Object3D;
  if (id === "hands") {
    arm(g, 0.05, 0, 0, 1);
    leftArm = arm(g, -0.33, 0, 0, -1);
  } else if (id === "pistol") {
    bx(g, gun, 0, 0.035, -0.05, 0.035, 0.04, 0.2);
    bx(g, gunLight, 0, 0.01, -0.06, 0.03, 0.02, 0.18);
    bx(g, gun, 0, -0.04, 0.02, 0.032, 0.11, 0.05, -0.25);
    bx(g, sightM, 0, 0.06, -0.14, 0.006, 0.01, 0.006);
    bx(g, sightM, -0.008, 0.06, 0.04, 0.005, 0.012, 0.005);
    bx(g, sightM, 0.008, 0.06, 0.04, 0.005, 0.012, 0.005);
    mag = bx(g, gunLight, 0, -0.09, 0.03, 0.025, 0.03, 0.035, -0.25);
    muzzle.position.set(0, 0.035, -0.17);
    arm(g, 0.0, -0.045, 0.04, 1);
    leftArm = arm(g, -0.02, -0.06, 0.02, -1);
    leftArm.rotation.z = 0.4;
  } else if (id === "shotgun") {
    bx(g, gun, 0, 0.03, -0.25, 0.03, 0.03, 0.6);
    bx(g, gun, 0, 0.0, -0.22, 0.026, 0.026, 0.5);
    pump = bx(g, woodM, 0, 0.0, -0.3, 0.05, 0.045, 0.18);
    bx(g, gun, 0, 0.015, 0.06, 0.05, 0.07, 0.2);
    bx(g, woodM, 0, -0.03, 0.26, 0.045, 0.08, 0.24, 0.15);
    bx(g, sightM, 0, 0.05, -0.54, 0.006, 0.01, 0.006);
    muzzle.position.set(0, 0.03, -0.56);
    arm(g, 0, -0.04, 0.13, 1);
    leftArm = arm(pump, 0, -0.035, 0, -1);
  } else {
    bx(g, gun, 0, 0.02, -0.02, 0.045, 0.07, 0.3);
    bx(g, gun, 0, 0.025, -0.3, 0.05, 0.05, 0.26);
    bx(g, gun, 0, 0.03, -0.5, 0.018, 0.018, 0.2);
    bx(g, gun, 0, 0.075, -0.05, 0.02, 0.025, 0.2);
    bx(g, gunLight, 0, 0.1, -0.02, 0.03, 0.03, 0.08); // optic
    bx(g, sightM, 0, 0.1, -0.061, 0.004, 0.004, 0.001);
    mag = bx(g, gun, 0, -0.06, -0.08, 0.035, 0.12, 0.06, 0.2);
    bx(g, gun, 0, -0.045, 0.05, 0.035, 0.09, 0.04, -0.3);
    bx(g, gunLight, 0, 0.0, 0.22, 0.04, 0.07, 0.18);
    muzzle.position.set(0, 0.03, -0.6);
    arm(g, 0, -0.06, 0.07, 1);
    leftArm = arm(g, 0, -0.02, -0.3, -1);
  }
  g.add(muzzle);
  const flash = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.22), new THREE.MeshBasicMaterial({ map: flashTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  flash.name = "flash";
  flash.visible = false;
  muzzle.add(flash);
  const flash2 = flash.clone();
  flash2.rotation.y = Math.PI / 2;
  flash2.scale.set(0.6, 1.6, 1);
  flash.add(flash2);
  return { group: g, muzzle, mag, pump, leftArm };
}

// world pickup models (small, shared materials)
export function buildPickupModel(kind: string): THREE.Object3D {
  const g = new THREE.Group();
  const ammoBox = (c: number) => {
    const m = new THREE.MeshLambertMaterial({ color: c, emissive: c, emissiveIntensity: 0.25 });
    bx(g, m, 0, 0.06, 0, 0.22, 0.12, 0.14);
    bx(g, new THREE.MeshLambertMaterial({ color: 0xd8c070 }), 0, 0.125, 0, 0.18, 0.01, 0.1);
  };
  switch (kind) {
    case "pistol": bx(g, gun, 0, 0.03, 0, 0.2, 0.04, 0.035); bx(g, gun, 0.07, -0.0, 0, 0.05, 0.1, 0.03, 0, 0, 0.25); break;
    case "shotgun": bx(g, gun, 0, 0.03, 0, 0.7, 0.04, 0.04); bx(g, woodM, 0.4, 0.02, 0, 0.25, 0.07, 0.045); bx(g, woodM, -0.15, 0.0, 0, 0.18, 0.05, 0.05); break;
    case "rifle": bx(g, gun, 0, 0.04, 0, 0.75, 0.06, 0.045); bx(g, gun, 0.02, -0.04, 0, 0.06, 0.12, 0.035, 0, 0, 0.2); bx(g, gunLight, 0.38, 0.03, 0, 0.18, 0.08, 0.04); break;
    case "ammo_pistol": ammoBox(0x8a6a20); break;
    case "ammo_shotgun": ammoBox(0xa02020); break;
    case "ammo_rifle": ammoBox(0x3a6a30); break;
    case "health": {
      bx(g, new THREE.MeshLambertMaterial({ color: 0xeeeeee, emissive: 0x333333 }), 0, 0.08, 0, 0.3, 0.16, 0.2);
      const r = new THREE.MeshBasicMaterial({ color: 0xdd1111 });
      bx(g, r, 0, 0.08, 0.101, 0.14, 0.04, 0.005); bx(g, r, 0, 0.08, 0.101, 0.04, 0.14, 0.005);
      break;
    }
    case "flashlight": bx(g, gun, 0, 0.03, 0, 0.22, 0.05, 0.05); bx(g, new THREE.MeshBasicMaterial({ color: 0xffffaa }), 0.12, 0.03, 0, 0.02, 0.06, 0.06); break;
    case "toolbox": {
      const r = new THREE.MeshLambertMaterial({ color: 0xaa2222, emissive: 0x220505 });
      bx(g, r, 0, 0.09, 0, 0.42, 0.18, 0.2);
      bx(g, gun, 0, 0.2, 0, 0.3, 0.035, 0.05);
      bx(g, gunLight, 0.1, 0.13, 0.101, 0.06, 0.06, 0.004);
      break;
    }
    case "file_4b": {
      bx(g, new THREE.MeshLambertMaterial({ color: 0xd8c8a0, emissive: 0x332a18 }), 0, 0.02, 0, 0.26, 0.03, 0.34);
      bx(g, new THREE.MeshBasicMaterial({ color: 0xaa2222 }), -0.08, 0.04, -0.12, 0.08, 0.004, 0.03);
      break;
    }
    case "helix_keycard": {
      bx(g, new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x224444 }), 0, 0.02, 0, 0.18, 0.012, 0.11);
      bx(g, new THREE.MeshBasicMaterial({ color: 0x22aaaa }), -0.05, 0.03, 0, 0.05, 0.004, 0.07);
      break;
    }
    case "city_map": {
      const p = new THREE.MeshLambertMaterial({ color: 0xe0d8b8, emissive: 0x333022 });
      bx(g, p, 0, 0.03, 0, 0.3, 0.015, 0.22);
      bx(g, new THREE.MeshBasicMaterial({ color: 0xaa3322 }), 0.04, 0.042, 0.02, 0.04, 0.004, 0.04);
      break;
    }
    default: { // keys
      const m = new THREE.MeshBasicMaterial({ color: 0xffcc22 });
      bx(g, m, 0, 0.02, 0, 0.12, 0.02, 0.04); bx(g, m, -0.08, 0.02, 0, 0.05, 0.02, 0.07);
      bx(g, new THREE.MeshBasicMaterial({ color: kind === "key_office" ? 0x2288ff : kind === "key_principal" ? 0xff3333 : 0x33ff66 }), 0.08, 0.02, 0, 0.05, 0.025, 0.03);
    }
  }
  return g;
}
