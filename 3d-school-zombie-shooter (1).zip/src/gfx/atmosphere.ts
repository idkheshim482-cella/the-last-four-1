// LAST FOUR — atmosphere & VFX: volumetric light shafts, drifting dust, embers,
// height fog and wind. All effects are subtle and gameplay-readable.

import * as THREE from "three";

/** Soft additive light-shaft cone (cheap god-ray stand-in). */
export function lightShaft(topR: number, botR: number, height: number, color = 0xffe0b0, opacity = 0.055) {
  const g = new THREE.CylinderGeometry(topR, botR, height, 10, 1, true);
  const m = new THREE.MeshBasicMaterial({
    color, transparent: true, opacity, depthWrite: false,
    blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
  });
  const mesh = new THREE.Mesh(g, m);
  mesh.renderOrder = 5;
  return mesh;
}

/** A drifting particle field (dust motes / ash / embers). */
export class ParticleField {
  points: THREE.Points;
  private vel: Float32Array;
  private base: Float32Array;
  private life: Float32Array;
  private size: number;
  private color: THREE.Color;
  private tint: THREE.Color;
  private mode: "dust" | "ember" | "ash";

  constructor(opts: {
    count: number; area: [number, number, number]; color?: number; emberColor?: number;
    size?: number; mode?: "dust" | "ember" | "ash"; rise?: number;
  }) {
    const n = opts.count;
    const [ax, ay, az] = opts.area;
    const pos = new Float32Array(n * 3);
    this.vel = new Float32Array(n * 3);
    this.base = new Float32Array(n * 3);
    this.life = new Float32Array(n);
    this.size = opts.size ?? 0.035;
    this.mode = opts.mode ?? "dust";
    this.color = new THREE.Color(opts.color ?? 0xb8c4d8);
    this.tint = new THREE.Color(opts.emberColor ?? 0xff8a3c);
    const rise = opts.rise ?? 0.12;
    for (let i = 0; i < n; i++) {
      const x = (Math.random() - 0.5) * ax;
      const y = (Math.random() - 0.5) * ay;
      const z = (Math.random() - 0.5) * az;
      pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z;
      this.base[i * 3] = x; this.base[i * 3 + 1] = y; this.base[i * 3 + 2] = z;
      this.vel[i * 3] = (Math.random() - 0.5) * 0.12;
      this.vel[i * 3 + 1] = rise * (0.5 + Math.random());
      this.vel[i * 3 + 2] = (Math.random() - 0.5) * 0.12;
      this.life[i] = Math.random();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const colors = new Float32Array(n * 3);
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    const mat = new THREE.PointsMaterial({
      size: this.size, vertexColors: true, transparent: true, opacity: 0.7,
      depthWrite: false, blending: this.mode === "ember" ? THREE.AdditiveBlending : THREE.NormalBlending,
      sizeAttenuation: true, fog: false,
    });
    this.points = new THREE.Points(g, mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 4;
    this.updateColors();
  }

  private updateColors() {
    const col = this.points.geometry.attributes.color as THREE.BufferAttribute;
    const arr = col.array as Float32Array;
    for (let i = 0; i < this.life.length; i++) {
      const c = this.mode === "ember" ? this.tint : this.color;
      const f = this.mode === "ember" ? 0.55 + this.life[i] * 0.45 : 0.6 + this.life[i] * 0.4;
      arr[i * 3] = c.r * f;
      arr[i * 3 + 1] = c.g * f;
      arr[i * 3 + 2] = c.b * f;
    }
    col.needsUpdate = true;
  }

  update(dt: number, camPos: THREE.Vector3, wind: number) {
    const pos = this.points.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < this.life.length; i++) {
      arr[i * 3] += (this.vel[i * 3] + Math.sin(performance.now() * 0.0007 + i) * 0.06) * dt;
      arr[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      arr[i * 3 + 2] += (this.vel[i * 3 + 2] + Math.cos(performance.now() * 0.0006 + i) * 0.06) * dt;
      this.life[i] -= dt * 0.12;
      if (this.life[i] <= 0) {
        // respawn around the camera so the field follows the player
        const s = 26;
        this.base[i * 3] = camPos.x + (Math.random() - 0.5) * s;
        this.base[i * 3 + 1] = camPos.y + (Math.random() - 0.5) * 8;
        this.base[i * 3 + 2] = camPos.z + (Math.random() - 0.5) * s;
        arr[i * 3] = this.base[i * 3];
        arr[i * 3 + 1] = this.base[i * 3 + 1];
        arr[i * 3 + 2] = this.base[i * 3 + 2];
        this.life[i] = 1;
      }
    }
    pos.needsUpdate = true;
    this.updateColors();
    void wind;
  }
}

/** Animated rain (used sparingly on exteriors). */
export class Rain {
  points: THREE.Points;
  private vel: Float32Array;
  constructor(count = 900, area = 22) {
    const pos = new Float32Array(count * 3);
    this.vel = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * area;
      pos[i * 3 + 1] = Math.random() * 14;
      pos[i * 3 + 2] = (Math.random() - 0.5) * area;
      this.vel[i] = 16 + Math.random() * 10;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    this.points = new THREE.Points(g, new THREE.PointsMaterial({
      color: 0xaec4dc, size: 0.03, transparent: true, opacity: 0.42, depthWrite: false, fog: false,
    }));
    this.points.frustumCulled = false;
  }
  update(dt: number, camPos: THREE.Vector3) {
    const pos = this.points.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < this.vel.length; i++) {
      arr[i * 3 + 1] -= this.vel[i] * dt;
      arr[i * 3] += 1.2 * dt;
      if (arr[i * 3 + 1] < camPos.y - 6) {
        arr[i * 3] = camPos.x + (Math.random() - 0.5) * 22;
        arr[i * 3 + 1] = camPos.y + 8 + Math.random() * 4;
        arr[i * 3 + 2] = camPos.z + (Math.random() - 0.5) * 22;
      }
    }
    pos.needsUpdate = true;
  }
}
