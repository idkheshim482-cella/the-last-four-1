import { useEffect, useRef, useState } from "react";
import { Engine, type UIState } from "./game/engine";
import { audio } from "./game/audio";
import TouchControls from "./ui/TouchControls";
import MapView from "./ui/MapView";
import Inventory from "./ui/Inventory";

const QNAMES = ["LOW", "MEDIUM", "HIGH"];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded border border-white/10 bg-black/40 p-3">
      <div className="mb-2 border-b border-white/10 pb-1 text-[11px] font-bold tracking-[0.35em] text-red-400">{title}</div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Slider({ label, value, min, max, step, fmt, onChange }: {
  label: string; value: number; min: number; max: number; step: number; fmt: (v: number) => string; onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <div className="mb-1 flex justify-between text-xs text-white/70">
        <span className="tracking-widest">{label}</span>
        <span className="font-bold text-white">{fmt(value)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} className="w-full accent-red-600"
        onChange={(e) => onChange(+e.target.value)} />
    </label>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} className="flex w-full items-center justify-between text-xs">
      <span className="tracking-widest text-white/70">{label}</span>
      <span className={`rounded border px-3 py-1 font-bold ${value ? "border-emerald-400 bg-emerald-700/50 text-emerald-100" : "border-white/25 bg-white/5 text-white/50"}`}>
        {value ? "ON" : "OFF"}
      </span>
    </button>
  );
}

function Settings({ engine }: { engine: Engine }) {
  const [q, setQ] = useState(engine.quality);
  const [sens, setSens] = useState(engine.sensitivity);
  const [fov, setFov] = useState(engine.baseFov);
  const [inv, setInv] = useState(engine.invertY);
  const [auto, setAuto] = useState(engine.autoShoot);
  const [vol, setVol] = useState(audio.volume);
  const [voice, setVoice] = useState(audio.voiceEnabled);
  return (
    <div className="max-h-[52vh] w-full space-y-2 overflow-y-auto pr-1 text-left text-sm">
      <Section title="GRAPHICS">
        <div>
          <div className="mb-1 flex justify-between text-xs text-white/70">
            <span className="tracking-widest">QUALITY</span>
            <span className="text-[10px] text-white/40">LOW = best FPS on phones</span>
          </div>
          <div className="flex gap-2">
            {QNAMES.map((n, i) => (
              <button key={n} onClick={() => { engine.setQuality(i); setQ(i); }}
                className={`flex-1 rounded border px-2 py-1.5 text-xs font-bold ${q === i ? "border-red-500 bg-red-700/60" : "border-white/20 bg-white/5"}`}>{n}</button>
            ))}
          </div>
        </div>
        <Slider label="FIELD OF VIEW" value={fov} min={60} max={95} step={1} fmt={(v) => `${v}°`}
          onChange={(v) => { setFov(v); engine.baseFov = v; localStorage.setItem("lastfour_fov", String(v)); }} />
      </Section>
      <Section title="CONTROLS">
        <Slider label="LOOK SENSITIVITY" value={sens} min={0.3} max={2.5} step={0.1} fmt={(v) => v.toFixed(1) + "x"}
          onChange={(v) => { setSens(v); engine.sensitivity = v; localStorage.setItem("lastfour_sens", String(v)); }} />
        <Toggle label="INVERT Y-AXIS" value={inv}
          onChange={(v) => { setInv(v); engine.invertY = v; localStorage.setItem("lastfour_inv", v ? "1" : "0"); }} />
        <Toggle label="AUTO-SHOOT AT TARGETS" value={auto}
          onChange={(v) => { setAuto(v); engine.autoShoot = v; localStorage.setItem("lastfour_auto", v ? "1" : "0"); }} />
        <div className="text-[9px] leading-snug text-white/35">Auto-shoot fires your equipped weapon when the crosshair is on an infected in range with a clear line of sight. Manual fire always takes priority.</div>
      </Section>
      <Section title="AUDIO">
        <Slider label="MASTER VOLUME" value={vol} min={0} max={1} step={0.05} fmt={(v) => Math.round(v * 100) + "%"}
          onChange={(v) => { setVol(v); audio.setVolume(v); localStorage.setItem("lastfour_vol", String(v)); }} />
        <Toggle label="SPOKEN DIALOGUE" value={voice}
          onChange={(v) => { setVoice(v); audio.voiceEnabled = v; localStorage.setItem("lastfour_voice", v ? "1" : "0"); }} />
      </Section>
    </div>
  );
}

interface ChapterDef { n: number; title: string; sub: string; desc: string; available: boolean; art: React.ReactNode }

function ChapterArt({ kind }: { kind: "school" | "city" | "lab" | "lock" }) {
  // tiny stylized CSS "preview scenes" — no image assets needed
  if (kind === "school")
    return (
      <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-[#0b0d12] via-[#1a1512] to-[#2a1610]">
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#3b2a1c] to-transparent" />
        <div className="absolute bottom-3 left-[12%] h-14 w-[76%] rounded-sm bg-[#4a3b2a] shadow-[inset_0_0_20px_rgba(0,0,0,0.6)]">
          {[0, 1, 2, 3, 4].map((i) => <div key={i} className={`absolute top-3 h-4 w-3 ${i % 2 ? "bg-amber-200/70 animate-pulse" : "bg-black/60"}`} style={{ left: `${10 + i * 17}%` }} />)}
          <div className="absolute bottom-0 left-1/2 h-6 w-4 -translate-x-1/2 bg-red-900/80" />
        </div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(120,0,0,0.35)_100%)]" />
        <div className="absolute right-3 top-3 text-2xl opacity-80">🧟</div>
      </div>
    );
  if (kind === "city")
    return (
      <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-[#05070f] via-[#1a1020] to-[#4a1e12]">
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="absolute bottom-0 bg-[#14161d]" style={{ left: `${i * 14}%`, width: "11%", height: `${35 + ((i * 37) % 45)}%` }}>
            {[0, 1, 2].map((k) => <div key={k} className="absolute h-1 w-1 bg-amber-200/80" style={{ left: `${25 + k * 25}%`, top: `${20 + k * 25}%` }} />)}
          </div>
        ))}
        <div className="absolute bottom-1 left-[30%] h-2 w-5 rounded-sm bg-orange-500 shadow-[0_0_10px_rgba(255,120,30,0.9)]" />
        <div className="absolute right-4 top-4 h-5 w-5 rounded-full bg-[#e8ecff] shadow-[0_0_14px_rgba(200,210,255,0.7)]" />
        <div className="absolute left-3 top-3 text-xl opacity-80">🚁</div>
      </div>
    );
  if (kind === "lab")
    return (
      <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-[#030608] to-[#0a1a20]">
        <div className="absolute left-1/2 top-1/2 h-16 w-8 -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-400/60 bg-cyan-500/20 shadow-[0_0_24px_rgba(60,200,230,0.5)]" />
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,rgba(0,0,0,0.15)_0_2px,transparent_2px_4px)]" />
        <div className="absolute bottom-2 right-2 text-[9px] tracking-widest text-cyan-200/60">PROJECT LAZARUS</div>
      </div>
    );
  return (
    <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-[#0a0a0c] to-[#1a1a1e]">
      <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,rgba(255,255,255,0.03)_0_6px,transparent_6px_12px)]" />
      <div className="absolute inset-0 flex items-center justify-center text-3xl opacity-50">🔒</div>
    </div>
  );
}

function ChapterSelect({ onBack, onPlay }: { engine: Engine; onBack: () => void; onPlay: (n: 1 | 2) => void }) {
  const chapters: ChapterDef[] = [
    { n: 1, title: "THE SCHOOL", sub: "CHAPTER 1", available: true, art: <ChapterArt kind="school" />,
      desc: "Akhil wakes in a barricaded classroom with Narendra, Mahesh and Harsha. Arm up, fight through the overrun school as a squad, reach the military radio and the rooftop. Opens with the Scientist prologue." },
    { n: 2, title: "THE ESCAPE", sub: "CHAPTER 2", available: true, art: <ChapterArt kind="city" />,
      desc: "The helicopter is gone. Four missions across the burning city: rescue Mina's sister Astra, recover Ravi's toolbox, find out whether help is really coming, and clear the horde off the road to the pier. Then race the last boat at the harbor." },
    { n: 3, title: "THE HAVEN", sub: "CHAPTER 3", available: false, art: <ChapterArt kind="lab" />,
      desc: "The boat sails north to a larger city where survivors talk over radio, and a hidden shelter waits below the streets. In development." },
    { n: 4, title: "LAST FOUR", sub: "CHAPTER 4", available: false, art: <ChapterArt kind="lock" />,
      desc: "Where the outbreak began, and why Akhil heals the way he does. Later." },
  ];
  return (
    <div className="lf-in flex w-full max-w-3xl flex-col items-center gap-3">
      <div className="text-xs tracking-[0.5em] text-white/70">SELECT CHAPTER</div>
      <div className="grid max-h-[62vh] w-full grid-cols-1 gap-3 overflow-y-auto px-1 sm:grid-cols-2">
        {chapters.map((c) => (
          <div key={c.n} className={`flex flex-col overflow-hidden rounded-md border ${c.available ? "border-white/20 bg-black/55" : "border-white/10 bg-black/40 opacity-80"}`}>
            <div className="relative h-24 w-full">
              {c.art}
              <div className={`absolute left-2 top-2 rounded px-2 py-0.5 text-[9px] font-bold tracking-widest ${c.available ? "bg-emerald-700/90 text-emerald-50" : "bg-zinc-700/90 text-zinc-200"}`}>
                {c.available ? "AVAILABLE" : "COMING SOON"}
              </div>
            </div>
            <div className="flex flex-1 flex-col p-3 text-left">
              <div className="text-[10px] tracking-[0.35em] text-red-400">{c.sub}</div>
              <div className="text-lg font-black tracking-[0.15em]">{c.title}</div>
              <div className="mt-1 flex-1 text-[11px] leading-relaxed text-white/60">{c.desc}</div>
              {c.available ? (
                <button onClick={() => onPlay(c.n as 1 | 2)}
                  className="mt-3 w-full rounded-sm border border-red-500 bg-red-800/80 py-2 text-xs font-bold tracking-[0.3em] text-white hover:bg-red-700 active:scale-95">
                  ▶ PLAY
                </button>
              ) : (
                <div className="mt-3 w-full rounded-sm border border-white/10 bg-white/5 py-2 text-center text-xs font-bold tracking-[0.3em] text-white/30">🔒 LOCKED</div>
              )}
            </div>
          </div>
        ))}
      </div>
      <MenuButton onClick={onBack}>◀ BACK</MenuButton>
    </div>
  );
}

function SquadFigures({ n }: { n: number }) {
  const cols = ["#3a6aa0", "#2a6a3a", "#8a2a2a", "#d0a030"];
  return (
    <div className="flex items-end justify-center gap-1.5">
      {cols.slice(0, n).map((c, i) => (
        <div key={i} className="flex flex-col items-center">
          <div className="h-3 w-3 rounded-sm" style={{ background: "#c08a64" }} />
          <div className="h-5 w-4 rounded-sm" style={{ background: c }} />
          <div className="flex gap-0.5"><div className="h-4 w-1.5" style={{ background: "#22262e" }} /><div className="h-4 w-1.5" style={{ background: "#22262e" }} /></div>
        </div>
      ))}
      {n === 1 && [0, 1, 2].map((i) => <div key={"g" + i} className="mb-1 h-10 w-4 rounded-sm border border-dashed border-white/15" />)}
    </div>
  );
}

function ModeSelect({ engine, onPick }: { engine: Engine; onPick: (squad: boolean) => void }) {
  const cards = [
    { squad: true, title: "SQUAD", sub: "AKHIL + NARENDRA, MAHESH & HARSHA", n: 4, accent: "border-emerald-500/70", glow: "shadow-[0_0_28px_rgba(16,185,129,0.25)]",
      desc: "Your three friends survive the outbreak with you. They follow, fight, share ammo and talk. Rescue cutscenes show all four of you.",
      tags: ["AI teammates", "Ammo sharing", "Squad banter", "Easier fights"] },
    { squad: false, title: "SOLO", sub: "AKHIL ALONE", n: 1, accent: "border-red-500/70", glow: "shadow-[0_0_28px_rgba(239,68,68,0.25)]",
      desc: "You lose your friends in the chaos and wake up alone. No backup, no ammo requests — just you, the dark corridors and whatever you can scavenge.",
      tags: ["Survival horror", "No companions", "More loot drops", "Harder"] },
  ];
  return (
    <div className="lf-in flex w-full max-w-2xl flex-col items-center gap-3">
      <div className="text-xs tracking-[0.5em] text-white/70">HOW DO YOU WANT TO SURVIVE?</div>
      <div className="grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
        {cards.map((c) => (
          <button key={c.title} onClick={() => { engine.setSquadMode(c.squad); onPick(c.squad); }}
            className={`group flex flex-col overflow-hidden rounded-md border bg-black/60 text-left transition hover:scale-[1.02] active:scale-[0.98] ${c.accent} ${c.glow}`}>
            <div className={`relative flex h-28 w-full items-end justify-center pb-3 ${c.squad ? "bg-gradient-to-b from-[#0b1a12] via-[#132a1c] to-[#1a3a24]" : "bg-gradient-to-b from-[#120a0a] via-[#1f0d0d] to-[#2a1010]"}`}>
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.6)_100%)]" />
              <div className="relative scale-125"><SquadFigures n={c.n} /></div>
            </div>
            <div className="p-3">
              <div className="text-[10px] tracking-[0.35em] text-white/50">{c.sub}</div>
              <div className="text-2xl font-black tracking-[0.2em]">{c.title}</div>
              <div className="mt-1 text-[11px] leading-relaxed text-white/60">{c.desc}</div>
              <div className="mt-2 flex flex-wrap gap-1">
                {c.tags.map((t) => <span key={t} className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] tracking-wider text-white/70">{t}</span>)}
              </div>
              <div className={`mt-3 w-full rounded-sm border py-2 text-center text-xs font-bold tracking-[0.3em] ${c.squad ? "border-emerald-500 bg-emerald-800/70" : "border-red-500 bg-red-800/70"}`}>▶ PLAY {c.title}</div>
            </div>
          </button>
        ))}
      </div>
      <div className="text-[10px] text-white/35">Your choice is remembered. You can switch any time by starting a new game.</div>
    </div>
  );
}

function MenuButton({ children, onClick, primary }: { children: React.ReactNode; onClick: () => void; primary?: boolean }) {
  return (
    <button onClick={onClick}
      className={`w-full rounded-sm border px-6 py-3 text-sm font-bold tracking-[0.25em] transition active:scale-95 ${primary ? "border-red-500 bg-red-800/80 text-white hover:bg-red-700" : "border-white/25 bg-black/40 text-white/90 hover:bg-white/10"}`}>
      {children}
    </button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [ui, setUi] = useState<UIState | null>(null);
  const [locked, setLocked] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showChapters, setShowChapters] = useState(false);
  const [modePick, setModePick] = useState<null | { kind: "new" } | { kind: "chapter"; n: 1 | 2 }>(null);
  const [showMap, setShowMap] = useState(false);
  const [showInv, setShowInv] = useState(false);
  const invRef = useRef(false);
  invRef.current = showInv;
  const mapRef = useRef(false);
  mapRef.current = showMap;
  const [, force] = useState(0);

  useEffect(() => {
    const engine = new Engine(canvasRef.current!);
    engineRef.current = engine;
    (window as any).__lf = engine;
    const s = localStorage.getItem("lastfour_sens");
    if (s) engine.sensitivity = +s;
    const v = localStorage.getItem("lastfour_vol");
    if (v) audio.setVolume(+v);
    const f = localStorage.getItem("lastfour_fov");
    if (f) engine.baseFov = +f;
    engine.invertY = localStorage.getItem("lastfour_inv") === "1";
    audio.voiceEnabled = localStorage.getItem("lastfour_voice") !== "0";
    const sq = localStorage.getItem("lastfour_squad");
    if (sq !== null) engine.squadMode = sq === "1";
    const as = localStorage.getItem("lastfour_auto");
    engine.autoShoot = as !== null ? as === "1" : engine.isTouch;
    const iv = setInterval(() => setUi({ ...engine.ui }), 80);
    return () => { clearInterval(iv); engine.dispose(); engineRef.current = null; };
  }, []);

  // desktop input
  useEffect(() => {
    const eng = () => engineRef.current;
    const kd = (e: KeyboardEvent) => {
      const en = eng();
      if (!en) return;
      if (en.ui.note) { en.ui.note = null; return; }
      if (en.ui.dialog) {
        const n = e.code.startsWith("Digit") ? +e.code.slice(5) - 1 : -1;
        if (n >= 0 && n < en.ui.dialog.options.length) en.dialogChoose(n);
        return;
      }
      if ((en.mode === "intro" || en.mode === "ending") && (e.code === "Space" || e.code === "Enter")) en.skipCutscene();
      if (e.code === "KeyP" && en.mode === "playing") en.pause();
      if (e.code === "KeyM" && en.mode === "playing") { setShowMap((v) => { const nv = !v; if (nv && document.pointerLockElement) document.exitPointerLock(); en.input.fire = false; en.input.keys.clear(); return nv; }); return; }
      if ((e.code === "KeyI" || e.code === "Tab" || (e.code === "Escape" && invRef.current)) && en.mode === "playing") {
        e.preventDefault();
        setShowInv((v) => {
          const nv = !v;
          if (nv && document.pointerLockElement) document.exitPointerLock();
          if (!nv && !en.isTouch) en.lockPointer();
          return nv;
        });
        return;
      }
      if (en.mode !== "playing") return;
      if (e.code.startsWith("Digit")) en.input.weaponSlot = +e.code.slice(5);
      en.input.keys.add(e.code);
      if (["Space", "ArrowUp", "ArrowDown"].includes(e.code)) e.preventDefault();
    };
    const ku = (e: KeyboardEvent) => { eng()?.input.keys.delete(e.code); };
    const mm = (e: MouseEvent) => {
      const en = eng();
      if (!en || !document.pointerLockElement) return;
      en.input.lookX += e.movementX;
      en.input.lookY += e.movementY;
    };
    const md = (e: MouseEvent) => {
      const en = eng();
      if (!en || !document.pointerLockElement) return;
      if (en.ui.note) { en.ui.note = null; return; }
      if (e.button === 0) en.input.fire = true;
      if (e.button === 2) en.mouseAds = true;
    };
    const mu = (e: MouseEvent) => {
      const en = eng();
      if (!en) return;
      if (e.button === 0) en.input.fire = false;
      if (e.button === 2) en.mouseAds = false;
    };
    const plc = () => {
      const l = !!document.pointerLockElement;
      setLocked(l);
      const en = eng();
      if (!l && en) {
        en.input.fire = false;
        en.mouseAds = false;
        en.input.keys.clear();
        if (!invRef.current && !mapRef.current) en.pause(); // inventory/map browsing shouldn't hard-pause
      }
    };
    const vis = () => { if (document.hidden) eng()?.pause(); };
    const cm = (e: Event) => e.preventDefault();
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("mousemove", mm);
    window.addEventListener("mousedown", md);
    window.addEventListener("mouseup", mu);
    window.addEventListener("contextmenu", cm);
    document.addEventListener("pointerlockchange", plc);
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("mousedown", md);
      window.removeEventListener("mouseup", mu);
      window.removeEventListener("contextmenu", cm);
      document.removeEventListener("pointerlockchange", plc);
      document.removeEventListener("visibilitychange", vis);
    };
  }, []);

  const engine = engineRef.current;
  const now = performance.now();
  const isTouch = engine?.isTouch ?? false;

  const goFullscreen = () => {
    if (!isTouch) return;
    try {
      document.documentElement.requestFullscreen?.().then(() => (screen.orientation as any)?.lock?.("landscape").catch(() => {})).catch(() => {});
    } catch { /* ignore */ }
  };

  const mode = ui?.mode ?? "menu";
  const dmg = ui ? Math.max(0, 1 - (now - ui.damageT) / 600) : 0;
  const hit = ui ? now - ui.hitT < 150 : false;
  const kill = ui ? now - ui.killT < 300 : false;
  const lowHp = ui && ui.health < 35 && mode === "playing";
  const fmtTime = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;

  return (
    <div className="fixed inset-0 overflow-hidden bg-black font-mono text-white select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full"
        onClick={() => { if (engine && engine.mode === "playing" && !isTouch && !document.pointerLockElement) engine.lockPointer(); }} />

      {/* vignette + grain */}
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.75) 100%)" }} />
      <div className="lf-grain pointer-events-none absolute inset-0 opacity-50" />
      {dmg > 0 && <div className="pointer-events-none absolute inset-0" style={{ background: `radial-gradient(ellipse at center, transparent 30%, rgba(160,0,0,${dmg * 0.7}) 100%)` }} />}
      {lowHp && <div className="pointer-events-none absolute inset-0 animate-pulse" style={{ background: "radial-gradient(ellipse at center, transparent 45%, rgba(120,0,0,0.5) 100%)" }} />}

      {/* fade */}
      {ui && ui.fade > 0 && <div className="pointer-events-none absolute inset-0 bg-black" style={{ opacity: ui.fade }} />}

      {/* letterbox */}
      {ui?.letterbox && (
        <>
          <div className="pointer-events-none absolute left-0 right-0 top-0 h-[11vh] bg-black" />
          <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-[11vh] bg-black" />
        </>
      )}
      {ui?.caption && (
        <div className="pointer-events-none absolute left-8 top-[14vh] text-sm tracking-[0.3em] text-white/80 sm:text-base">{ui.caption}</div>
      )}
      {ui?.bigText && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="animate-pulse text-2xl tracking-[0.5em] text-white/90 sm:text-4xl">{ui.bigText}</div>
        </div>
      )}
      {ui?.vsub && !ui.subtitle && (mode === "playing" || mode === "paused") && (
        <div className={`pointer-events-none absolute ${isTouch ? "top-[13%]" : "bottom-[16vh]"} left-1/2 w-[90%] max-w-2xl -translate-x-1/2 text-center`}>
          <div className="lf-toast inline-block rounded bg-black/70 px-3 py-1.5 text-xs leading-relaxed sm:text-sm">
            <span className={`mr-2 font-bold ${ui.vsub.color}`}>{ui.vsub.who}:</span><span className="text-white/95">{ui.vsub.text}</span>
          </div>
        </div>
      )}
      {ui?.subtitle && (
        <div className="pointer-events-none absolute bottom-[13vh] left-1/2 w-[90%] max-w-3xl -translate-x-1/2 text-center">
          <div className="inline-block rounded bg-black/70 px-4 py-2 text-sm leading-relaxed sm:text-base">
            {ui.subtitle.who && <span className={`mr-2 font-bold ${ui.subtitle.who === "AKHIL" ? "text-sky-300" : ui.subtitle.who === "SOLDIER" ? "text-lime-300" : "text-amber-300"}`}>{ui.subtitle.who}:</span>}
            <span className="text-white/95">{ui.subtitle.text}</span>
          </div>
        </div>
      )}
      {ui?.choices && engine && (
        <div className="absolute inset-x-0 bottom-[24vh] z-30 flex flex-col items-center gap-2 px-4">
          <div className="text-xs tracking-[0.3em] text-white/70">RESPOND ON THE RADIO</div>
          {ui.choices.map((c, i) => (
            <button key={i} onClick={() => engine.choose(i)}
              className="w-full max-w-2xl rounded border border-sky-400/60 bg-sky-950/80 px-4 py-3 text-left text-sm text-sky-100 hover:bg-sky-800/80 active:scale-[0.98]">
              <span className="mr-2 font-bold text-sky-300">{i + 1}.</span>{c}
            </button>
          ))}
        </div>
      )}
      {ui?.canSkip && (mode === "intro" || mode === "ending") && engine && (
        <button onClick={() => engine.skipCutscene()} className="absolute right-4 top-[12vh] z-30 rounded border border-white/30 bg-black/50 px-4 py-2 text-xs tracking-widest">
          SKIP ▸▸
        </button>
      )}

      {/* gameplay HUD */}
      {ui && (mode === "playing" || mode === "paused") && engine && (
        <>
          {/* crosshair — turns red and tightens when locked onto an infected */}
          {!ui.ads && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className={`relative transition-all duration-100 ${ui.lockOn ? "h-5 w-5" : "h-7 w-7"} ${ui.reloading ? "opacity-30" : ""}`}>
                {(["left-1/2 top-0 h-2 w-[2px] -translate-x-1/2", "bottom-0 left-1/2 h-2 w-[2px] -translate-x-1/2", "left-0 top-1/2 h-[2px] w-2 -translate-y-1/2", "right-0 top-1/2 h-[2px] w-2 -translate-y-1/2"]).map((c) => (
                  <div key={c} className={`absolute ${c} ${ui.lockOn ? "bg-red-500 shadow-[0_0_4px_rgba(255,0,0,0.9)]" : "bg-white/80"}`} />
                ))}
                <div className={`absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full ${ui.lockOn ? "bg-red-500" : "bg-red-400/80"}`} />
                {ui.lockOn && <div className="absolute -inset-1 rounded-full border border-red-500/40" />}
              </div>
            </div>
          )}
          {ui.ads && ui.lockOn && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="h-6 w-6 rounded-full border border-red-500/60" />
            </div>
          )}
          {hit && (
            <div className={`pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-2xl font-bold ${kill ? "text-red-500" : "text-white"}`}>✕</div>
          )}
          {/* objective */}
          <div className="pointer-events-none absolute left-3 top-3 max-w-[55%] sm:max-w-md">
            <div className="rounded-r border-l-4 border-red-600 bg-gradient-to-r from-black/75 to-black/40 px-3 py-2 backdrop-blur-[2px]">
              <div className="flex items-center justify-between"><span className="text-[10px] tracking-[0.3em] text-red-400">OBJECTIVE</span><span className={`rounded px-1.5 text-[8px] font-bold tracking-widest ${ui.squad.length ? "bg-emerald-900/70 text-emerald-200" : "bg-red-900/70 text-red-200"}`}>{ui.squad.length ? "SQUAD" : "SOLO"}</span></div>
              <div className="text-xs font-bold leading-tight sm:text-sm">{ui.objective}</div>
              <div className="mt-1 text-[10px] leading-tight text-white/60 sm:text-xs">{ui.objectiveSub}</div>
              {ui.stage === 1 && <div className="mt-1 text-[10px] text-amber-300">SURVIVED {fmtTime(ui.surviveTime)} · KILLS {ui.kills}</div>}
            </div>
            {ui.keys.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-1">
                {ui.keys.map((k) => <span key={k} className="rounded bg-amber-900/60 px-2 py-0.5 text-[10px] text-amber-200">🔑 {k}</span>)}
              </div>
            )}
          </div>
          {/* top right */}
          <div className="absolute right-3 top-3 z-20 flex items-center gap-2">
            <span className="pointer-events-none text-[10px] text-white/40">{ui.fps} FPS</span>
            <button onClick={() => { setShowMap(true); engine.input.fire = false; if (document.pointerLockElement) document.exitPointerLock(); }} className="rounded border border-amber-500/50 bg-amber-950/60 px-3 py-1.5 text-xs font-bold text-amber-200 backdrop-blur-sm">MAP</button>
            <button onClick={() => { setShowInv(true); if (document.pointerLockElement) document.exitPointerLock(); }} className="rounded border border-sky-500/50 bg-sky-950/60 px-3 py-1.5 text-xs font-bold text-sky-200 backdrop-blur-sm">BAG</button>
            <button onClick={() => engine.pause()} className="rounded border border-white/30 bg-black/50 px-3 py-1.5 text-xs font-bold backdrop-blur-sm">❚❚</button>
          </div>
          {/* waypoint */}
          {ui.waypoint && (
            <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded border border-amber-500/40 bg-black/60 px-3 py-1 text-center">
              <span className="text-[10px] font-bold tracking-widest text-amber-300">◆ {ui.waypoint.label}</span>
              <span className="ml-2 text-[10px] text-white/60">{ui.waypoint.dist}m</span>
            </div>
          )}
          {/* squad */}
          {ui.squad.length > 0 && (
            <div className={`pointer-events-none absolute ${isTouch ? "left-3 top-[42%]" : "bottom-24 left-4"} flex flex-col gap-1`}>
              {ui.squad.map((m) => (
                <div key={m.name} className={`flex items-center gap-2 rounded border px-2 py-0.5 backdrop-blur-[2px] ${m.down ? "border-red-700/60 bg-red-950/60" : "border-white/10 bg-black/50"}`}>
                  <span className={`w-16 text-[9px] font-bold tracking-widest ${m.down ? "text-red-300" : "text-sky-200"}`}>{m.down ? "DOWN" : m.name}</span>
                  <div className="h-1.5 w-14 overflow-hidden rounded bg-white/10"><div className={`h-full ${m.hp > 50 ? "bg-emerald-400" : m.hp > 25 ? "bg-amber-400" : "bg-red-500"}`} style={{ width: `${m.hp}%` }} /></div>
                  <span className="text-[8px] text-white/40">{m.weapon === "rifle" ? "5.56" : m.weapon === "shotgun" ? "SHELLS" : "9MM"}{m.cd > 0 ? ` · ${m.cd}s` : " · AMMO ✓"}</span>
                </div>
              ))}
            </div>
          )}
          {/* speedometer */}
          {ui.speed !== null && (
            <div className="pointer-events-none absolute bottom-24 left-1/2 -translate-x-1/2 rounded border border-white/20 bg-black/60 px-4 py-1.5 text-center">
              <span className="text-2xl font-bold text-emerald-300">{ui.speed}</span>
              <span className="ml-1 text-[10px] tracking-widest text-white/50">KM/H</span>
            </div>
          )}
          {/* toasts */}
          <div className="pointer-events-none absolute left-1/2 top-[18%] flex w-[90%] max-w-xl -translate-x-1/2 flex-col items-center gap-1">
            {ui.toasts.map((t) => <div key={t.id} className="lf-toast rounded border border-white/10 bg-black/75 px-3 py-1.5 text-center text-xs text-white/95 backdrop-blur-[2px] sm:text-sm">{t.text}</div>)}
          </div>
          {/* prompt */}
          {ui.prompt && (
            <div className="pointer-events-none absolute left-1/2 top-[60%] -translate-x-1/2 whitespace-nowrap rounded border border-white/20 bg-black/70 px-3 py-1.5 text-xs sm:text-sm">
              {!isTouch && <span className="mr-2 rounded bg-white px-1.5 font-bold text-black">E</span>}{ui.prompt}
            </div>
          )}
          {/* health */}
          <div className={`absolute ${isTouch ? "left-3 top-[28%]" : "bottom-4 left-4"} w-40 sm:w-56`}>
            <div className="pointer-events-none mb-1 flex justify-between text-[10px] tracking-widest text-white/70"><span>AKHIL</span><span>{ui.health} HP</span></div>
            <div className="pointer-events-none h-2.5 w-full overflow-hidden rounded-sm border border-white/10 bg-black/50">
              <div className={`h-full transition-all ${ui.health > 50 ? "bg-gradient-to-r from-emerald-600 to-emerald-400" : ui.health > 25 ? "bg-gradient-to-r from-amber-600 to-amber-400" : "bg-gradient-to-r from-red-800 to-red-500"}`} style={{ width: `${ui.health}%` }} />
            </div>
            <div className="mt-1 flex items-center gap-2">
              <button onClick={() => engine.useMedkit()}
                className={`z-20 rounded border px-2 py-0.5 text-[10px] font-bold ${ui.medkits > 0 ? "border-emerald-500/60 bg-emerald-950/70 text-emerald-200" : "border-white/15 bg-black/40 text-white/30"}`}>
                ✚ {ui.medkits}{!isTouch && " [H]"}
              </button>
              {ui.hasFlashlight && <span className="pointer-events-none text-[10px] text-white/60">🔦 {ui.flashOn ? "ON" : "OFF"}{!isTouch && " [F]"}</span>}
            </div>
          </div>
          {/* ammo */}
          <div className={`pointer-events-none absolute text-right ${isTouch ? "right-3 top-14" : "bottom-4 right-4"}`}>
            <div className="text-[10px] tracking-widest text-white/70">{ui.weapon}{ui.reloading && <span className="ml-2 animate-pulse text-amber-300">RELOADING</span>}</div>
            {ui.weaponId ? (
              <div className="text-2xl font-bold sm:text-3xl">
                <span className={ui.mag === 0 ? "text-red-500" : ""}>{ui.mag}</span>
                <span className="text-base text-white/50"> / {ui.reserve}</span>
              </div>
            ) : <div className="text-xs text-white/50">{isTouch ? "FIRE to shove" : "Click to shove"}</div>}
            <div className="mt-1 flex justify-end gap-1">
              {(["pistol", "shotgun", "rifle"] as const).map((w, i) => (
                <span key={w} className={`rounded px-1.5 text-[9px] ${ui.weaponId === w ? "bg-red-700 text-white" : ui.owned.includes(w) ? "bg-white/20 text-white/80" : "bg-white/5 text-white/20"}`}>{i + 1}</span>
              ))}
            </div>
          </div>
          {mode === "playing" && !isTouch && !locked && !ui.note && (
            <div className="absolute inset-0 z-20 cursor-pointer" onClick={() => engine.lockPointer()}>
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded border border-white/15 bg-black/60 px-3 py-1 text-center text-[10px] tracking-widest text-white/60 backdrop-blur-sm">
                CLICK TO TAKE CONTROL
              </div>
            </div>
          )}
          {isTouch && mode === "playing" && <TouchControls engine={engine} ui={ui} />}
        </>
      )}

      {/* NPC dialog */}
      {ui?.dialog && engine && (
        <div className="absolute inset-0 z-40 flex items-end justify-center bg-black/40 p-4 pb-10">
          <div className="lf-in w-full max-w-2xl rounded border border-sky-700/50 bg-[#0c1016]/95 p-4 shadow-2xl">
            <div className="mb-2 flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-sky-500/50 bg-sky-900/50 text-base">🗣</div>
              <div className="text-sm font-black tracking-[0.25em] text-sky-300">{ui.dialog.name}</div>
            </div>
            <div className="mb-3 text-sm leading-relaxed text-white/90">{ui.dialog.text}</div>
            <div className="flex flex-col gap-2">
              {ui.dialog.options.map((o, i) => (
                <button key={i} onClick={() => engine.dialogChoose(i)}
                  className="rounded border border-sky-500/50 bg-sky-950/70 px-4 py-2.5 text-left text-sm text-sky-100 hover:bg-sky-800/70 active:scale-[0.98]">
                  <span className="mr-2 font-bold text-sky-400">{i + 1}.</span>{o}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* city map */}
      {showMap && engine && (mode === "playing" || mode === "paused") && <MapView engine={engine} onClose={() => { setShowMap(false); if (!engine.isTouch && engine.mode === "playing") engine.lockPointer(); }} />}

      {/* inventory */}
      {showInv && engine && (mode === "playing" || mode === "paused") && (
        <Inventory engine={engine}
          onClose={() => { setShowInv(false); if (!engine.isTouch && engine.mode === "playing") engine.lockPointer(); }}
          onOpenMap={() => setShowMap(true)} />
      )}

      {/* note */}
      {ui?.note && engine && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/50 p-4" onClick={() => { engine.ui.note = null; force((n) => n + 1); }}>
          <div className="max-w-md rotate-[-1deg] bg-[#e8e2cf] p-6 text-[#2a2218] shadow-2xl">
            <div className="mb-2 border-b border-[#2a2218]/30 pb-1 font-bold">{ui.note.title}</div>
            <div className="text-sm italic leading-relaxed">{ui.note.text}</div>
            <div className="mt-4 text-right text-[10px] text-[#2a2218]/60">TAP / PRESS ANY KEY TO CLOSE</div>
          </div>
        </div>
      )}

      {/* main menu */}
      {mode === "menu" && engine && (
        <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-gradient-to-b from-black/70 via-black/40 to-black/80 p-4">
          <div className={`flex w-full flex-col items-center gap-3 text-center ${showChapters || modePick ? "max-w-3xl" : "max-w-sm"}`}>
            <div className="text-[10px] tracking-[0.6em] text-red-500">A ZOMBIE SURVIVAL SHOOTER</div>
            <h1 className={`font-black tracking-[0.15em] text-white drop-shadow-[0_0_20px_rgba(200,0,0,0.6)] ${showChapters || modePick ? "text-3xl" : "text-6xl sm:text-7xl"}`}>LAST<span className="text-red-600">FOUR</span></h1>
            {!showChapters && !modePick && <div className="mb-3 text-xs tracking-[0.5em] text-white/70">SCHOOL OUTBREAK · DEMO</div>}
            {showSettings ? (
              <>
                <Settings engine={engine} />
                <MenuButton onClick={() => setShowSettings(false)}>BACK</MenuButton>
              </>
            ) : modePick ? (
              <div className="w-full" onClick={() => goFullscreen()}>
                <ModeSelect engine={engine} onPick={() => { const mp = modePick; setModePick(null); setShowChapters(false); if (mp.kind === "new") engine.newGame(); else engine.startChapter(mp.n); }} />
                <div className="mt-3 flex justify-center"><MenuButton onClick={() => setModePick(null)}>◀ BACK</MenuButton></div>
              </div>
            ) : showChapters ? (
              <div className="w-full" onClick={() => goFullscreen()}>
                <ChapterSelect engine={engine} onBack={() => setShowChapters(false)} onPlay={(n) => setModePick({ kind: "chapter", n })} />
              </div>
            ) : showHelp ? (
              <>
                <div className="w-full space-y-1 rounded border border-white/15 bg-black/60 p-3 text-left text-xs leading-relaxed text-white/80">
                  <div className="font-bold text-red-400">PC</div>
                  <div>WASD move · Shift sprint · Mouse look · LMB fire · RMB aim</div>
                  <div>R reload · Space jump · E interact · Q / 1-3 switch · F flashlight · Esc pause</div>
                  <div>H use medkit · I / Tab inventory · M map · Auto-shoot toggle in Settings</div>
                  <div>Walk up to Narendra / Mahesh / Harsha and press E to ask for 100 rounds (60s cooldown each)</div>
                  <div>G (or FOLLOW button) = FOLLOW ME: squad drops distant targets and regroups on you</div>
                  <div className="pt-2 font-bold text-red-400">CITY (CHAPTER 2)</div>
                  <div>E ride/exit vehicles · WASD or joystick to drive · M or MAP button for the city map</div>
                  <div>Talk to Mina and Ravi (E) for missions · shops are lootable · vehicles need Ravi's toolbox</div>
                  <div className="pt-2 font-bold text-red-400">MOBILE</div>
                  <div>Left side: joystick (push far up to sprint) · Right side: drag to look</div>
                  <div>Buttons: FIRE (drag while firing to aim) · AIM · RELOAD · JUMP · USE · SWAP · LIGHT</div>
                </div>
                <MenuButton onClick={() => setShowHelp(false)}>BACK</MenuButton>
              </>
            ) : (
              <>
                {engine.hasSave() && <MenuButton primary onClick={() => { goFullscreen(); engine.continueGame(); }}>CONTINUE</MenuButton>}
                <MenuButton primary={!engine.hasSave()} onClick={() => setModePick({ kind: "new" })}>NEW GAME</MenuButton>
                <div className="-mt-1 text-[10px] tracking-widest text-white/40">LAST PLAYED: {(ui?.squadMode ?? engine.squadMode) ? "SQUAD (4 FRIENDS)" : "SOLO (AKHIL ALONE)"}</div>
                <MenuButton onClick={() => setShowChapters(true)}>CHAPTERS</MenuButton>
                <MenuButton onClick={() => setShowSettings(true)}>SETTINGS</MenuButton>
                <MenuButton onClick={() => setShowHelp(true)}>CONTROLS</MenuButton>
                <div className="mt-2 text-[10px] text-white/40">Headphones recommended · Progress saves automatically</div>
              </>
            )}
          </div>
        </div>
      )}

      {/* pause */}
      {mode === "paused" && engine && (
        <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-black/75 p-4">
          <div className="flex w-full max-w-sm flex-col items-center gap-3">
            <div className="mb-2 text-3xl font-black tracking-[0.3em]">PAUSED</div>
            <MenuButton primary onClick={() => engine.resume()}>RESUME</MenuButton>
            <Settings engine={engine} />
            <MenuButton onClick={() => engine.restartFromSave()}>LOAD LAST SAVE</MenuButton>
            <MenuButton onClick={() => { if (confirm("Start a new game? Current progress will be lost.")) { engine.quitToMenu(); setModePick({ kind: "new" }); } }}>RESTART NEW GAME</MenuButton>
            <MenuButton onClick={() => engine.quitToMenu()}>SAVE & QUIT TO MENU</MenuButton>
          </div>
        </div>
      )}

      {/* chapter complete */}
      {mode === "complete" && engine && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black p-4">
          <div className="flex w-full max-w-md flex-col items-center gap-3 text-center">
            <div className="text-[10px] tracking-[0.6em] text-red-500">LAST FOUR · {(ui?.stage ?? 0) >= 8 ? "ESCAPE THE CITY" : "SCHOOL OUTBREAK"}</div>
            {(ui?.stage ?? 0) >= 8 ? (
              <>
                <div className="text-4xl font-black tracking-[0.2em] text-white sm:text-5xl">CHAPTER TWO<br /><span className="text-red-600">COMPLETE</span></div>
                <div className="mt-1 max-w-sm text-xs leading-relaxed text-white/60">
                  The last boat found them on the pier: Akhil, Narendra, Mahesh, Harsha, Ravi, Mina and little Astra. They fought through the school and crossed a burning city together.
                </div>
              </>
            ) : (
              <>
                <div className="text-4xl font-black tracking-[0.2em] text-white sm:text-5xl">CHAPTER ONE<br /><span className="text-red-600">COMPLETE</span></div>
                <div className="mt-1 max-w-sm text-xs leading-relaxed text-white/60">
                  The helicopter is gone. The school is behind him. Somewhere across the burning city, the harbor evac zone is still broadcasting.
                  Akhil isn't done surviving.
                </div>
              </>
            )}
            <div className="my-3 flex gap-6 text-center">
              <div><div className="text-2xl font-bold text-red-400">{ui?.kills}</div><div className="text-[10px] tracking-widest text-white/50">INFECTED KILLED</div></div>
              <div><div className="text-2xl font-bold text-amber-300">{fmtTime(ui?.surviveTime ?? 0)}</div><div className="text-[10px] tracking-widest text-white/50">TIME SURVIVED</div></div>
            </div>
            <MenuButton primary onClick={() => engine.continueFreeRoam()}>{(ui?.stage ?? 0) >= 8 ? "FREE ROAM — BACK TO THE CITY" : "CHAPTER 2 — INTO THE CITY"}</MenuButton>
            <MenuButton onClick={() => engine.quitToMenu()}>MAIN MENU</MenuButton>
            <div className="mt-1 text-[10px] tracking-[0.4em] text-white/30">{(ui?.stage ?? 0) >= 8 ? "CHAPTER 3 — THE HAVEN — IN DEVELOPMENT" : "THE CITY AWAITS IN CHAPTER 2"}</div>
          </div>
        </div>
      )}

      {/* death */}
      {mode === "dead" && engine && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-red-950/60 p-4">
          <div className="flex w-full max-w-sm flex-col items-center gap-3 text-center">
            <div className="text-5xl font-black tracking-[0.3em] text-red-500">YOU DIED</div>
            <div className="mb-3 text-xs tracking-widest text-white/70">The infected overwhelmed Akhil. Kills: {ui?.kills}</div>
            <MenuButton primary onClick={() => engine.restartFromSave()}>LOAD LAST SAVE</MenuButton>
            <MenuButton onClick={() => { engine.quitToMenu(); setModePick({ kind: "new" }); }}>RESTART NEW GAME</MenuButton>
            <MenuButton onClick={() => engine.quitToMenu()}>MAIN MENU</MenuButton>
          </div>
        </div>
      )}
    </div>
  );
}
