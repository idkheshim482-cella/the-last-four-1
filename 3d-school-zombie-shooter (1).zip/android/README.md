# LAST FOUR — Android build

Offline APK build of LAST FOUR (Chapters 1–2).

## What's inside
- `app/src/main/assets/index.html` — the entire game as ONE self-contained file
  (Three.js + React inlined, all textures and audio generated in code).
  Nothing is downloaded at runtime.
- `app/src/main/java/.../MainActivity.java` — a fullscreen WebView shell that
  loads `file:///android_asset/index.html`.

## Offline guarantees
- The manifest declares **no permissions at all** (no `INTERNET`).
- `usesCleartextTraffic="false"`.
- Every texture, sound and model is generated procedurally in JavaScript —
  there are no image/audio files to download.

## Rebuilding
Requires JDK 17+ and the Android SDK (platform 34, build-tools 34.0.0).

```bash
npm run build
cp dist/index.html android/app/src/main/assets/index.html
cd android
./gradlew assembleRelease
# output: app/build/outputs/apk/release/app-release.apk
```

The release build is signed with `keystore/lastfour.jks`
(alias `lastfour`, store/key password `lastfour`) so it can be side-loaded.

## Installing
```bash
adb install -r LASTFOUR-v1.0.apk
```
Or copy the APK to the phone and open it (allow "install from unknown sources").
