// LAST FOUR — Dialogue database + voice director.
// Every named character's lines live here, grouped by context. Playback: real audio clip if one is
// registered in VOICE_CLIPS (drop files in and map them), otherwise browser speech synthesis with a
// per-character voice profile. Subtitles always show. One line plays at a time; contextual lines
// obey per-context cooldowns so companions don't chatter endlessly.

export type CharId = "akhil" | "narendra" | "mahesh" | "harsha" | "ravi" | "mina" | "astra" | "ana" | "soldier" | "operator" | "scientist";

export type Ctx =
  | "intro" | "follow" | "spot" | "combat" | "horde" | "kill" | "reload" | "help" | "down" | "revive"
  | "ammo_give" | "ammo_cooldown" | "heal" | "check" | "area" | "radio" | "mission_start" | "mission_done"
  | "separated" | "idle_chat" | "story" | "greet" | "found_item" | "door_locked" | "vehicle"
  | "hope" | "fear" | "plan";

export interface VoiceProfile { name: string; pitch: number; rate: number; voiceIndex: number; color: string }

export const VOICES: Record<CharId, VoiceProfile> = {
  akhil: { name: "AKHIL", pitch: 1.05, rate: 1.08, voiceIndex: 0, color: "text-sky-300" },
  narendra: { name: "NARENDRA", pitch: 0.8, rate: 0.98, voiceIndex: 1, color: "text-emerald-300" },
  mahesh: { name: "MAHESH", pitch: 1.15, rate: 1.18, voiceIndex: 2, color: "text-orange-300" },
  harsha: { name: "HARSHA", pitch: 0.95, rate: 0.92, voiceIndex: 3, color: "text-yellow-200" },
  ravi: { name: "RAVI", pitch: 0.7, rate: 1.0, voiceIndex: 1, color: "text-blue-300" },
  mina: { name: "MINA", pitch: 1.25, rate: 1.05, voiceIndex: 4, color: "text-pink-300" },
  astra: { name: "ASTRA", pitch: 1.6, rate: 1.1, voiceIndex: 4, color: "text-fuchsia-200" },
  ana: { name: "DOC ANA", pitch: 1.1, rate: 0.95, voiceIndex: 5, color: "text-teal-200" },
  soldier: { name: "SOLDIER", pitch: 0.6, rate: 1.05, voiceIndex: 0, color: "text-lime-300" },
  operator: { name: "RADIO OPERATOR", pitch: 0.9, rate: 1.05, voiceIndex: 1, color: "text-amber-300" },
  scientist: { name: "SCIENTIST", pitch: 0.75, rate: 0.95, voiceIndex: 2, color: "text-cyan-200" },
};


// Optional real audio. Key format: "<char>:<ctx>:<index>" -> URL. Empty by default (none generated).
export const VOICE_CLIPS: Record<string, string> = {};

type Lines = Partial<Record<Ctx, string[]>>;

export const LINES: Record<CharId, Lines> = {
  // ---------------- AKHIL — ninth grader, scared but stubborn ----------------
  akhil: {
    greet: ["Guys... you're still here. You stayed.", "Okay. Okay. We're alive. That's something."],
    spot: ["There — infected!", "I see one. Don't let it get close.", "Heads up, it's coming our way."],
    combat: ["Come on, come on...", "Stay back! STAY BACK!", "I'm not dying in a school. No way."],
    horde: ["That's too many. That is WAY too many.", "Fall back, fall back!"],
    reload: ["Reloading— cover me!", "Empty, hang on!"],
    help: ["I need a hand here!", "Guys, a little help?!"],
    heal: ["Okay. Breathing. I'm okay.", "That stings. I'll live."],
    ammo_give: ["Thanks. I owe you.", "Got it. Thanks, man."],
    area: ["Never thought I'd miss math class.", "Keep your eyes open. This place isn't empty."],
    radio: ["This is Akhil. I'm trapped inside the school. We need extraction!", "They heard us. They actually heard us."],
    mission_start: ["Let's get this done.", "Alright. Stick together."],
    mission_done: ["We did it. We actually did it.", "One thing at a time. Next."],
    door_locked: ["Locked. There has to be a key somewhere.", "Won't budge. We need the key."],
    found_item: ["This'll help.", "Grabbing this."],
    vehicle: ["Everybody hold on!", "I don't even have a license..."],
    story: ["The whole city is burning... Fine. I survived the school — I'll survive out there too."],
  
    hope: ["We're going to make it. I have to believe that.", "Six of us got off a boat. Six of us can get further."],
    fear: ["I keep hearing them in the walls. Like the school.", "What if the signal is a trap?"],
    plan: ["We go on foot from here. Quiet.", "Ravi leads. The rest of us stay close."],
},
  // ---------------- NARENDRA — calm, tactical, the steady one; rifle ----------------
  narendra: {
    intro: ["Easy, Akhil. You went down hard. We dragged you in here and barricaded the door.", "Take the pistol on the desk. Harsha pulled it off the security guard. It's yours."],
    greet: ["Good to have you back on your feet.", "We move as four. Nobody wanders."],
    follow: ["Right behind you.", "On your six.", "Lead the way, I've got the rear."],
    spot: ["Contact. Twelve o'clock.", "Infected, closing. Hold your fire until it's in range.", "Two of them. Left side."],
    combat: ["Engaging.", "Aim for the head, Mahesh. The HEAD.", "Controlled bursts. Make them count."],
    horde: ["That's a pack. Tight formation, back to back!", "Too many for a corridor fight — pick a doorway and hold it!"],
    kill: ["Down.", "Target neutralized.", "Clear. For now."],
    reload: ["Reloading. Cover.", "Swapping mags."],
    help: ["I could use some fire support here.", "Akhil — on me, now."],
    down: ["I'm hit... keep fighting, don't stop for me—", "Argh— I'm down!"],
    revive: ["I'm up. Shake it off.", "Still breathing. Let's go."],
    ammo_give: ["Take a hundred. I packed extra.", "Here. Don't waste it."],
    ammo_cooldown: ["Give me a minute to dig out another box.", "Not yet. Ration what you've got."],
    heal: ["Patch yourself up when it's quiet, not mid-fight.", "You good? Your arm's bleeding again."],
    check: ["Everyone still with us? Count off.", "Mahesh, you're too far ahead."],
    area: ["Second floor. Office should be this way.", "Library. Lots of cover, lots of blind corners. Careful.", "Outside. Sky's orange. That's the city burning."],
    radio: ["A military radio. If anyone's coordinating a rescue, they're on that frequency.", "Keep it short, Akhil. They need our location, not our life story."],
    mission_start: ["Understood. We do it clean.", "New objective. Eyes up."],
    mission_done: ["Objective complete. Don't relax yet.", "Good work. Reload before we move."],
    separated: ["Akhil, you're too far. Regrouping on your position.", "Lost visual. Moving to you."],
    idle_chat: ["My dad's a reservist. He always said 'panic is a decision.' I'm deciding not to.", "When this is over, I'm never setting an alarm clock again.", "Harsha, stop humming."],
    door_locked: ["Locked. Someone had the key — find out who.", "We don't have the key. Search the rooms."],
    vehicle: ["Drive. We'll catch up on foot — just don't lose us.", "Keep it steady."],
    story: ["We lost people today. We don't lose anyone else. That's the rule."],
  
    hope: ["A signal is a promise someone kept. That's worth something."],
    fear: ["We don't know what's on the other side of that gate. Accept it and stay sharp."],
    plan: ["Two on point, two in the middle. Ravi takes the rear. Move on my call."],
},
  // ---------------- MAHESH — jokes under pressure, loud, big heart; shotgun ----------------
  mahesh: {
    intro: ["HE LIVES! Told you he was too stubborn to die.", "Dude, you were out for hours. I thought I'd have to carry you. I would have, though."],
    greet: ["Welcome back to the worst field trip ever.", "Akhil! My guy!"],
    follow: ["Coming, coming!", "Right here. Shotgun's ready.", "Yep, yep, following."],
    spot: ["ZOMBIE! Big one!", "Uhh, guys? GUYS?", "Over there — ugly one coming!"],
    combat: ["EAT IT!", "Get away from my friends!", "Boom. Boom! BOOM!"],
    horde: ["Okay that's a LOT of zombies. Like a LOT a lot.", "Nope. Nope nope nope. RUN?"],
    kill: ["Got him!", "Did you SEE that?!", "That one's done."],
    reload: ["Loading shells, hang on!", "Pump's empty, one sec!"],
    help: ["Little help?! LITTLE HELP?!", "Akhil, it's chewing on me!"],
    down: ["Ow ow ow— I'm down, I'm down!", "Tell my mom I was brave..."],
    revive: ["I'm fine! I'm fine. Mostly.", "Okay. That hurt. A lot."],
    ammo_give: ["Here, a hundred shells. Don't say I never gave you anything.", "Take 'em! I've got, like, a thousand."],
    ammo_cooldown: ["Dude, I JUST gave you ammo.", "Sixty seconds, man. I'm not a vending machine."],
    heal: ["Medkit time? Medkit time.", "You look terrible. Eat a medkit."],
    check: ["Everybody alive? Say 'aye'.", "Harsha, you're quiet. Too quiet."],
    area: ["Cafeteria! If there's pizza left I'm eating it. Zombie germs or not.", "Science lab. This is where Mr. Thomas failed me. Twice.", "Streets. Fresh air. Smells like... smoke and death. Great."],
    radio: ["Is that an actual army radio? Can we call for pizza?", "Tell them to send a tank. Two tanks."],
    mission_start: ["Mission time! Let's go!", "On it, boss!"],
    mission_done: ["WE ARE AWESOME.", "High five! ...later. When nothing's trying to bite us."],
    separated: ["Wait up! My legs are shorter!", "Akhil?! Where'd you go?!"],
    idle_chat: ["If I survive this, I'm telling the whole school I saved Akhil. Twice.", "You think the zombies feel bad about it? Like, deep down?", "I'm starving. Is that bad? That's probably bad."],
    door_locked: ["Locked. Can I just... shoot it?", "Who locks doors during an apocalypse?!"],
    vehicle: ["SHOTGUN! I call shotgun! Wait, I already have a shotgun.", "Go go go!"],
    story: ["We're gonna be okay. I decided. It's decided."],
  
    hope: ["We made it out of a school, out of a city, and onto a boat. Grey Ward can't be worse."],
    fear: ["Everything's quiet and I don't like it. Quiet means they're waiting."],
    plan: ["Stick together, stay loud about nothing, and if something runs, I run faster."],
},
  // ---------------- HARSHA — quiet, observant, dry humor, the medic-minded one; pistol ----------------
  harsha: {
    intro: ["You were bleeding from the head. I cleaned it. You're welcome.", "There's a medkit in the locker by the door. Take it. You'll need it more than us."],
    greet: ["Hey.", "Glad you're up. We need you."],
    follow: ["Following.", "Mm-hm.", "Behind you."],
    spot: ["Infected. Quiet.", "One. Maybe more behind it.", "Movement, right side."],
    combat: ["Head. Head. Head.", "Firing.", "Stay still, you—"],
    horde: ["Too many. Choke point. Now.", "Count's bad. Back up."],
    kill: ["Done.", "Next.", "That one won't get up."],
    reload: ["Reloading.", "Out. Hold on."],
    help: ["Could use help.", "Akhil. Now."],
    down: ["...down.", "That's bad."],
    revive: ["I'm okay.", "Still here."],
    ammo_give: ["Hundred rounds. Don't miss.", "Take it."],
    ammo_cooldown: ["Wait a minute.", "Not yet."],
    heal: ["Use a medkit. Don't be stubborn.", "Pressure on the wound. Then move."],
    check: ["Mahesh, breathe.", "Everyone okay?"],
    area: ["Staff room. Teachers kept supplies here.", "Principal's office. Never been invited in before.", "Rooftop. Finally, sky."],
    radio: ["Military frequency. Speak clearly.", "They'll want a location. Tell them it's the school."],
    mission_start: ["Okay.", "Let's finish it."],
    mission_done: ["Good.", "That's one."],
    separated: ["Lost you. Coming.", "Where are you?"],
    idle_chat: ["I was going to be a doctor. Guess I'm starting early.", "Mahesh. The humming is me. Sorry.", "My sister's in the city. I keep thinking about that."],
    door_locked: ["Locked.", "Key. Somewhere."],
    vehicle: ["I'll keep up.", "Don't crash."],
    story: ["Akhil... your head wound. It's already closing. That's not normal. We'll talk later."],
  
    hope: ["We're close to something. I can feel it in the signal."],
    fear: ["I don't like that we can't see the whole shore."],
    plan: ["I stay with Astra. If she panics, I panic with her."],
},
  // ---------------- RAVI — mechanic, gruff, warm underneath ----------------
  ravi: {
    greet: ["Mina's runner, huh? Look at you — four kids with guns. Alright."],
    mission_start: ["Bring my toolbox back and every set of wheels out there is yours."],
    mission_done: ["Jump pack's charged. Sedans, my bike, the sports car — all yours. Don't lift off the throttle."],
    vehicle: ["Clutch is sticky on the sedan. Don't ride it."],
    idle_chat: ["Rebuilt that sports car with my own hands. If you scratch it, I'll know."],
    story: ["Harbor broadcast went to final call. Last boat. I'm coming with you — my tools and I."],
  
    hope: ["Fifteen years I told people a city like this was finished. Maybe I was wrong."],
    fear: ["If the gate's shut, we don't knock. We come back to the boat and we wait."],
    plan: ["We go in on foot and light. I know how to read a repeater signal. Give me ten minutes with that tower."],
},
  // ---------------- MINA — tactician, protective big sister ----------------
  mina: {
    greet: ["You came out of the school? Nobody comes out of there."],
    mission_start: ["My little sister Astra is hiding in the pharmacy. The crossing is crawling. Clear it, and the map's yours."],
    mission_done: ["You did it. Astra's safe. Here — my dad's map. Safehouse and the harbor are marked."],
    idle_chat: ["Four of you, plus me and Astra. That's a squad. I can work with a squad."],
    story: ["Boat's holding the pier for minutes, not hours. Astra rides with me. Let's move."],
  
    hope: ["Six of us. We didn't even know each other a week ago."],
    fear: ["I keep thinking about that radio in the school. Something followed us out of the city."],
    plan: ["We find the source of the signal, and we don't turn the radio off. Not yet."],
},
  // ---------------- ASTRA — Mina's little sister, small and brave ----------------
  astra: {
    greet: ["Are you the ones who made it quiet? Mina said someone would come.", "I counted the groans. There were six. Now there's none."],
    idle_chat: ["I'm not scared. ...Okay, a little.", "Mina says I'm the lookout. I'm a really good lookout."],
    story: ["Is the boat big? I've never been on a boat."],
  
    hope: ["Mina says we're going to be okay. I believe her."],
    fear: ["It's too quiet. Can we turn the radio on? Just a little?"],
    plan: ["I'll be the lookout. I'm good at looking out."],
},
  // ---------------- DOC ANA — safehouse medic ----------------
  ana: {
    greet: ["Welcome to the safehouse. Rest on the cot whenever you need patching up."],
    mission_start: ["Infected keep crawling up Dock Street at night. Put down five and I'll keep the stash stocked."],
    mission_done: ["Quiet nights again. Take what you need, always."],
    heal: ["That wound on your head should've needed stitches. It didn't. Curious."],
  },
  soldier: {}, operator: {}, scientist: {},
};

export function countLines() {
  let n = 0;
  for (const c in LINES) for (const k in LINES[c as CharId]) n += LINES[c as CharId][k as Ctx]!.length;
  return n;
}

interface Queued { who: CharId; text: string; dur: number; priority: number; clip?: string }

export class VoiceDirector {
  private queue: Queued[] = [];
  private current: Queued | null = null;
  private t = 0;
  private ctxCooldown = new Map<string, number>();
  private lastIndex = new Map<string, number>();
  private audioEl: HTMLAudioElement | null = null;
  enabled = true;
  subtitle: { who: string; text: string; color: string } | null = null;
  globalGap = 0;

  /** Play a contextual line. Returns false if on cooldown / nothing to say. */
  say(who: CharId, ctx: Ctx, opts: { cooldown?: number; priority?: number; force?: boolean } = {}) {
    const pool = LINES[who][ctx];
    if (!pool || !pool.length) return false;
    const key = who + ":" + ctx;
    const now = performance.now() / 1000;
    const cd = opts.cooldown ?? 12;
    if (!opts.force && (this.ctxCooldown.get(key) ?? -999) + cd > now) return false;
    // avoid repeating the same line twice in a row
    let i = Math.floor(Math.random() * pool.length);
    if (pool.length > 1 && i === this.lastIndex.get(key)) i = (i + 1) % pool.length;
    this.lastIndex.set(key, i);
    this.ctxCooldown.set(key, now);
    const text = pool[i];
    const q: Queued = { who, text, dur: Math.min(7, 1.2 + text.length * 0.055), priority: opts.priority ?? 1, clip: VOICE_CLIPS[key + ":" + i] };
    // low-priority chatter never queues more than one deep
    if (q.priority <= 1 && this.queue.length >= 1) return false;
    if (q.priority >= 3 && this.current && this.current.priority < 3) { this.stopCurrent(); }
    this.queue.push(q);
    this.queue.sort((a, b) => b.priority - a.priority);
    return true;
  }

  /** Scripted line (story/cutscene): always plays, highest priority. */
  sayText(who: CharId, text: string, dur?: number) {
    this.stopCurrent();
    this.queue = [];
    this.queue.push({ who, text, dur: dur ?? Math.min(9, 1.2 + text.length * 0.055), priority: 5 });
  }

  update(dt: number) {
    if (this.current) {
      this.t -= dt;
      if (this.t <= 0) { this.current = null; this.subtitle = null; this.globalGap = 0.35; }
      return;
    }
    if (this.globalGap > 0) { this.globalGap -= dt; return; }
    const next = this.queue.shift();
    if (!next) return;
    this.current = next;
    this.t = next.dur;
    const vp = VOICES[next.who];
    this.subtitle = { who: vp.name, text: next.text, color: vp.color };
    if (!this.enabled) return;
    if (next.clip) {
      try {
        this.audioEl = new window.Audio(next.clip);
        this.audioEl.play().catch(() => this.speak(next));
      } catch { this.speak(next); }
    } else this.speak(next);
  }

  private speak(q: Queued) {
    try {
      const ss = window.speechSynthesis;
      if (!ss) return;
      ss.cancel();
      const u = new SpeechSynthesisUtterance(q.text);
      const vp = VOICES[q.who];
      u.pitch = vp.pitch;
      u.rate = vp.rate;
      const voices = ss.getVoices().filter((v) => v.lang.startsWith("en"));
      if (voices.length) u.voice = voices[vp.voiceIndex % voices.length];
      ss.speak(u);
    } catch { /* ignore */ }
  }

  stopCurrent() {
    this.current = null;
    this.subtitle = null;
    try { window.speechSynthesis?.cancel(); } catch { /* ignore */ }
    if (this.audioEl) { this.audioEl.pause(); this.audioEl = null; }
  }

  clear() { this.queue = []; this.stopCurrent(); }
  get busy() { return !!this.current || this.queue.length > 0; }
}

export const voice = new VoiceDirector();
