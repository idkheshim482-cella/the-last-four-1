import type { Level } from "./level";
import { cityTexture } from "./textures";
import * as THREE from "three";

// ---------- key locations ----------
export const GAS_STATION = { x: 47, z: 31 };
export const PHARMACY = { x: 83, z: 22 };
export const GUNSTORE = { x: 83, z: -20 };
export const MINIMART = { x: 44, z: 39 };
export const GARAGE = { x: 107, z: 64 };
export const HIDEOUT = { x: 125, z: 62 };
export const HARBOR = { x: 314, z: 55 };

/** Shared registry of street nav nodes (filled by buildCity, consumed by buildLazarus). */

export const SCHOOL_EXIT = { x: 33, z: 0 };

export interface VehicleSpawn { id: string; kind: "bicycle" | "moto" | "sedan" | "sports"; x: number; z: number; yaw: number }
export const VEHICLE_SPAWNS: VehicleSpawn[] = [
  { id: "bike1", kind: "bicycle", x: 34.5, z: 7, yaw: -Math.PI / 2 },
  { id: "bike2", kind: "bicycle", x: 34.5, z: 9, yaw: -Math.PI / 2 },
  { id: "bike3", kind: "bicycle", x: 53, z: 28, yaw: 0 },
  { id: "moto1", kind: "moto", x: 101, z: 53.5, yaw: -Math.PI / 2 },
  { id: "sedan1", kind: "sedan", x: 66, z: 16, yaw: Math.PI },
  { id: "sedan2", kind: "sedan", x: 92, z: 48.5, yaw: -Math.PI / 2 },
  { id: "sports1", kind: "sports", x: 107, z: 63, yaw: Math.PI },
];

export interface NPCDef { id: "mina" | "ravi" | "astra"; name: string; x: number; z: number; yaw: number; look: { shirt: number; pants: number; skin: number; hair: number; scale: number } }
export const NPCS: NPCDef[] = [
  { id: "mina", name: "MINA", x: 47.5, z: 29.5, yaw: Math.PI, look: { shirt: 0xb05a2a, pants: 0x2a3444, skin: 0xc8956a, hair: 0x14100c, scale: 0.93 } },
  { id: "ravi", name: "RAVI", x: 104, z: 55.5, yaw: Math.PI, look: { shirt: 0x3a5a8a, pants: 0x30343a, skin: 0x9a6a42, hair: 0x202020, scale: 1.04 } },
  { id: "astra", name: "ASTRA", x: 82.5, z: 25.5, yaw: -Math.PI / 2, look: { shirt: 0xd070a0, pants: 0x3a3a5a, skin: 0xc8956a, hair: 0x14100c, scale: 0.72 } },
];

// fixed city zombies (ids persist in deadIds)
export const CITY_SPAWNS: [number, number, number, boolean?][] = [
  [68, 24, 0], [67, -4, 1], [70, -40, 2], [66, -70, 3, true], [58, 51, 4], [84, 50, 0], [120, 49, 1], [150, 30, 2],
  [150, -10, 3], [148, -45, 4, true], [100, -60, 0], [170, -60, 1], [200, 52, 2], [228, 50, 3], [68, 70, 4], [40, 51, 0, true],
];
// harbor roadblock pack
export const ROADBLOCK_SPAWNS: [number, number, number, boolean?][] = [
  [243, 52, 0], [246, 56, 1], [250, 50, 2, true], [254, 58, 3], [258, 53, 4], [262, 57, 0],
];
// mission 1: pharmacy crossing pack
export const M1_SPAWNS: [number, number, number, boolean?][] = [
  [76, 22, 0], [79, 28, 1], [80, 15, 2], [74, 30, 3, true], [86, 30, 4], [73, 13, 1],
];

// ---------- map overlay data ----------
export const MAP_ROADS = [
  { x0: 61.5, z0: -140, x1: 74.5, z1: 90 },
  { x0: -80, z0: 45.5, x1: 310, z1: 56.5 },
  { x0: 40, z0: -65.5, x1: 245, z1: -54.5 },
  { x0: 144, z0: -140, x1: 156, z1: 51 },
];
export const MAP_BLOCKS = [
  { x0: -30, z0: -12, x1: 30, z1: 12, label: "SCHOOL" },
  { x0: 90, z0: 8, x1: 124, z1: 36 }, { x0: 90, z0: -34, x1: 122, z1: -10 }, { x0: 140, z0: 60, x1: 172, z1: 88 },
  { x0: 182, z0: 58, x1: 228, z1: 86 }, { x0: 62, z0: -96, x1: 100, z1: -72 }, { x0: 112, z0: -100, x1: 140, z1: -74 },
  { x0: 170, z0: -96, x1: 206, z1: -70 }, { x0: 166, z0: -40, x1: 200, z1: 0 }, { x0: 168, z0: 8, x1: 204, z1: 38 },
  { x0: 40, z0: -46, x1: 58, z1: -20 }, { x0: 240, z0: 20, x1: 300, z1: 90, label: "HARBOR" },
];

function shelfRow(lv: Level, x: number, z: number, w: number, ry: number) {
  lv.box("metal", x, 0, z, w, 1.7, 0.5, { collide: true, ry });
  const dx = Math.cos(ry), dz = -Math.sin(ry);
  for (let i = 0; i < Math.floor(w / 0.5); i++) {
    const t = (i - w / 1.0) * 0.5 + 0.4;
    const gx = x + dx * t, gz = z + dz * t;
    const c = ["red", "green", "bottle", "white", "yellow"][i % 5];
    if (lv.r() < 0.6) lv.box(c, gx, 0.9 + (i % 2) * 0.45, gz, 0.3, 0.3, 0.3, { ry });
  }
}

function shop(lv: Level, x0: number, x1: number, z0: number, z1: number, face: "W" | "S" | "E" | "N", doorC: number, name: string, bg: string) {
  const h = 3.4, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
  lv.box("floor", cx, -0.015, cz, x1 - x0, 0.05, z1 - z0);
  lv.box("concrete", cx, h, cz, x1 - x0 + 0.5, 0.3, z1 - z0 + 0.5);
  const op = { c: doorC, w: 2.8, h: 2.7 };
  lv.wallZ(x0, z0, z1, 0, h, face === "W" ? [op] : [], "brick");
  lv.wallZ(x1, z0, z1, 0, h, face === "E" ? [op] : [], "brick");
  lv.wallX(z0, x0, x1, 0, h, face === "S" ? [op] : [], "brick");
  lv.wallX(z1, x0, x1, 0, h, face === "N" ? [op] : [], "brick");
  // sign + broken storefront glass
  const sy = h + 0.8;
  if (face === "W") { lv.sign(name, x0 - 0.16, sy, doorC, -Math.PI / 2, bg, 5); lv.box("glass", x0 + 0.05, 0.9, doorC + 2.6, 0.04, 1.6, 1.6); }
  if (face === "E") { lv.sign(name, x1 + 0.16, sy, doorC, Math.PI / 2, bg, 5); lv.box("glass", x1 - 0.05, 0.9, doorC + 2.6, 0.04, 1.6, 1.6); }
  if (face === "S") { lv.sign(name, doorC, sy, z0 - 0.16, 0, bg, 5); lv.box("glass", doorC + 2.6, 0.9, z0 + 0.05, 1.6, 1.6, 0.04); }
  if (face === "N") { lv.sign(name, doorC, sy, z1 + 0.16, Math.PI, bg, 5); lv.box("glass", doorC - 2.6, 0.9, z1 - 0.05, 1.6, 1.6, 0.04); }
  // glass shards near opening
  for (let k = 0; k < 5; k++) lv.box("glass", doorC + (lv.r() - 0.5) * 3 * (face === "W" || face === "E" ? 0 : 1) + (face === "W" ? x0 + 1 : face === "E" ? x1 - 1 : 0) * 0, 0.01, 0, 0, 0, 0);
  lv.ceilingLamp(cx, h - 0.15, cz, lv.r() < 0.5);
  lv.papers(x0 + 1, x1 - 1, z0 + 1, z1 - 1, 0, 6);
}

export function buildCity(lv: Level) {
  // city facade materials (windows glow)
  for (let i = 0; i < 3; i++) {
    const t = cityTexture(i);
    lv.mats["citywall" + i] = new THREE.MeshLambertMaterial({ map: t, emissive: 0xbba77a, emissiveMap: t, emissiveIntensity: 0.55 });
  }
  lv.mats["water"] = new THREE.MeshLambertMaterial({ color: 0x0a1626, emissive: 0x08141f, emissiveIntensity: 0.8 });

  // ---------- roads ----------
  for (const rd of MAP_ROADS) lv.box("asphalt", (rd.x0 + rd.x1) / 2, -0.019 - Math.random() * 0.002, (rd.z0 + rd.z1) / 2, rd.x1 - rd.x0, 0.02, rd.z1 - rd.z0);
  for (let z = -136; z < 88; z += 7) lv.box("paintY", 68, 0.002, z, 0.35, 0.008, 3);
  for (let x = -76; x < 308; x += 7) lv.box("paintY", x, 0.003, 51, 3, 0.008, 0.35);
  for (let x = 44; x < 242; x += 7) lv.box("paintY", x, 0.002, -60, 3, 0.008, 0.35);
  for (let z = -136; z < 48; z += 7) lv.box("paintY", 150, 0.0025, z, 0.35, 0.008, 3);
  // sidewalks on avenue A
  lv.box("concrete", 59.5, 0, -25, 3, 0.1, 230, { slab: true });
  lv.box("concrete", 76.5, 0, -25, 3, 0.1, 230, { slab: true });
  // wrecks along roads
  lv.car(67, -55, 0.3, "white", true);
  lv.car(70, -95, 2.6, "red", true);
  lv.car(130, 49, 1.8, "green", false);
  lv.car(160, 53, 1.3, "darkmetal", true);
  lv.car(150, -20, 0.1, "fabric", false);
  lv.car(200, 49, 1.7, "white", true);
  lv.car(100, -58, 1.5, "red", false);

  // ---------- solid blocks ----------
  const B = [
    { x0: 90, z0: 8, x1: 124, z1: 36, h: 20 }, { x0: 90, z0: -34, x1: 122, z1: -10, h: 16 },
    { x0: 140, z0: 60, x1: 172, z1: 88, h: 18 }, { x0: 182, z0: 58, x1: 228, z1: 86, h: 14 },
    { x0: 62, z0: -96, x1: 100, z1: -72, h: 22 }, { x0: 112, z0: -100, x1: 140, z1: -74, h: 26 },
    { x0: 170, z0: -96, x1: 206, z1: -70, h: 18 }, { x0: 166, z0: -40, x1: 200, z1: 0, h: 24 },
    { x0: 168, z0: 8, x1: 204, z1: 38, h: 15 }, { x0: 40, z0: -46, x1: 58, z1: -20, h: 9 },
  ];
  B.forEach((b, i) => {
    const cx = (b.x0 + b.x1) / 2, cz = (b.z0 + b.z1) / 2;
    lv.box("citywall" + (i % 3), cx, 0, cz, b.x1 - b.x0, b.h, b.z1 - b.z0, { collide: true });
    lv.box("concrete", cx, b.h, cz, b.x1 - b.x0 + 0.6, 0.5, b.z1 - b.z0 + 0.6);
    lv.box("concrete", cx, 0, cz, b.x1 - b.x0 + 1.2, 0.65, b.z1 - b.z0 + 1.2);
  });


  // ---------- gas station + minimart ----------
  lv.box("concrete", 46, -0.01, 27, 18, 0.04, 12);
  for (const [px, pz] of [[42, 26], [50, 26]]) {
    lv.box("darkmetal", px, 0, pz, 0.4, 3.8, 0.4);
    lv.box("red", px, 0.1, pz + 1.6, 1.0, 1.5, 0.7, { collide: true });
    lv.box("red", px, 0.1, pz - 1.6, 1.0, 1.5, 0.7, { collide: true });
  }
  lv.box("white", 46, 3.8, 27, 16, 0.4, 9);
  lv.box("red", 46, 4.2, 27, 16.2, 0.25, 9.2);
  lv.box("lamp", 42, 3.7, 27, 1.4, 0.08, 0.5);
  lv.box("lamp", 50, 3.7, 27, 1.4, 0.08, 0.5);
  lv.sign("FUEL-N-GO", 46, 3.5, 22.4, 0, "#8a2020", 4);
  lv.light(46, 3.4, 27, 0xfff0d0, 1.8, 16);
  lv.car(46, 30, 0.2, "fabric", true);
  shop(lv, 38, 50, 34, 44, "S", 44, "MINIMART 24/7", "#1a5a3a");
  shelfRow(lv, 42, 38.5, 5, 0);
  shelfRow(lv, 46, 40.5, 5, 0);
  lv.box("metal", 39.2, 0, 41, 2, 1.0, 2.4, { collide: true }); // counter
  lv.wallZ(48, 36, 44, 0, 3.4, [{ c: 41.5, w: 1.3, h: 2.4 }], "plaster"); // storeroom partition
  lv.box("military", 49.2, 0, 37, 1.1, 0.8, 1.1, { collide: true });

  // ---------- pharmacy ----------
  shop(lv, 78, 88, 17, 27, "W", 22, "+ CITY PHARMACY", "#1a5a3a");
  shelfRow(lv, 83, 20, 6, 0);
  shelfRow(lv, 83, 24, 6, 0);
  lv.box("white", 86.8, 0, 22, 1.6, 1.0, 4, { collide: true });
  lv.bloodPool(81, 0, 22, 1.4);
  lv.light(83, 3.0, 22, 0x66ff99, 1.0, 9, true);

  // ---------- gun store ----------
  shop(lv, 78, 88, -25, -15, "W", -20, "IRONSIGHT GUNS & AMMO", "#5a3a1a");
  lv.box("darkwood", 84, 0, -20, 1.2, 1.1, 6, { collide: true }); // counter
  lv.box("darkmetal", 87.4, 0, -20, 0.8, 2.2, 7, { collide: true }); // rack
  for (let i = 0; i < 4; i++) lv.box("black", 87.0, 0.6 + i * 0.4, -23 + i * 2, 0.1, 0.12, 0.9);
  lv.box("yellow", 80, 0.01, -18, 0.8, 0.02, 0.6); // police tape

  // ---------- Ravi's garage ----------
  const gx0 = 100, gx1 = 114, gz0 = 57, gz1 = 71;
  lv.box("floor", 107, -0.015, 64, 14, 0.05, 14);
  lv.box("concrete", 107, 4.2, 64, 14.5, 0.35, 14.5);
  lv.wallZ(gx0, gz0, gz1, 0, 4.2, [], "brick");
  lv.wallZ(gx1, gz0, gz1, 0, 4.2, [], "brick");
  lv.wallX(gz1, gx0, gx1, 0, 4.2, [], "brick");
  lv.wallX(gz0, gx0, gx1, 0, 4.2, [{ c: 107, w: 6, h: 3.4 }], "brick");
  lv.sign("RAVI'S AUTO GARAGE", 107, 5.0, 56.8, 0, "#1a3a5a", 6);
  lv.box("metal", 102, 0, 68.5, 3.4, 1.0, 1.6, { collide: true }); // workbench
  lv.box("darkmetal", 112.5, 0, 68, 1.6, 1.8, 1.0, { collide: true }); // tool cabinet
  lv.box("black", 104, 0.0, 60, 1.1, 0.9, 1.1, { collide: true }); // tires
  lv.box("black", 104, 0.9, 60, 0.95, 0.8, 0.95);
  lv.ceilingLamp(107, 4.0, 64, true);
  lv.light(107, 3.6, 64, 0xffe6c0, 1.2, 11);

  // ---------- abandoned hideout ----------
  const hx0 = 120, hx1 = 130, hz0 = 57, hz1 = 67;
  lv.box("floor", 125, -0.015, 62, 10, 0.05, 10);
  lv.box("concrete", 125, 3.3, 62, 10.5, 0.3, 10.5);
  lv.wallZ(hx0, hz0, hz1, 0, 3.3, [], "brick");
  lv.wallZ(hx1, hz0, hz1, 0, 3.3, [], "brick");
  lv.wallX(hz1, hx0, hx1, 0, 3.3, [], "brick");
  lv.wallX(hz0, hx0, hx1, 0, 3.3, [{ c: 125, w: 1.4, h: 2.4 }], "brick");
  lv.addDoor("hideout", "HIDEOUT", 125, 0, hz0, -1);
  lv.sign("⌂ HIDEOUT", 125, 3.0, hz0 - 0.16, 0, "#1a5a3a", 3);
  // boarded windows look
  lv.box("wood", hx1 - 0.05, 1.4, 62, 0.12, 1.4, 2.2);
  lv.box("wood", 125, 1.5, hz1 - 0.05, 2.2, 1.2, 0.12);
  // abandoned cot + bedroll
  lv.box("darkmetal", 127.8, 0, 64.8, 2.4, 0.4, 1.6, { collide: true });
  lv.box("fabric", 127.8, 0.4, 64.8, 2.3, 0.25, 1.5);
  lv.box("red", 128.7, 0.65, 64.8, 0.5, 0.12, 1.3);
  // stash crates
  lv.box("military", 121.2, 0, 65.5, 1.2, 0.8, 1.2, { collide: true });
  lv.box("military", 121.3, 0.8, 65.3, 0.9, 0.6, 0.9);
  lv.box("wood", 124, 0, 60, 1.6, 0.8, 1.0, { collide: true }); // table
  lv.box("lamp", 124, 0.85, 60.2, 0.25, 0.3, 0.25);
  lv.light(125, 2.8, 62, 0xffd9a0, 1.4, 9);
  lv.restPoint = null;

  // ---------- harbor ----------
  lv.box("concrete", 270, -0.005, 55, 60, 0.06, 70); // deck
  // perimeter fence with gate at z 50..60
  lv.wallX(20, 240, 300, 0, 2.6, [], "darkmetal", 0.15);
  lv.wallX(90, 240, 300, 0, 2.6, [], "darkmetal", 0.15);
  lv.wallZ(240, 20, 48, 0, 2.6, [], "darkmetal", 0.15);
  lv.wallZ(240, 62, 90, 0, 2.6, [], "darkmetal", 0.15);
  lv.sign("HARBOR EVAC ZONE", 240, 3.2, 55, -Math.PI / 2, "#1a3a5a", 7);
  // containers
  const cc = ["red", "green", "military", "fabric"];
  for (let i = 0; i < 7; i++) {
    const cx = 250 + (i % 3) * 16, cz = 26 + Math.floor(i / 3) * 9;
    lv.box(cc[i % 4], cx, 0, cz, 12, 2.6, 2.6, { collide: true });
    if (i % 3 === 0) lv.box(cc[(i + 1) % 4], cx - 2, 2.6, cz, 12, 2.6, 2.6);
  }
  for (let i = 0; i < 3; i++) lv.box(cc[(i + 2) % 4], 252 + i * 14, 0, 78, 12, 2.6, 2.6, { collide: true });
  // crane
  lv.box("yellow", 290, 0, 75, 2, 16, 2, { collide: true });
  lv.box("yellow", 284, 15, 70, 1.2, 1.2, 18);
  lv.box("darkmetal", 284, 8, 63, 0.15, 7, 0.15);
  // pier
  lv.box("wood", 309, 0, 55, 22, 0.3, 8, { slab: true });
  for (let px = 300; px <= 318; px += 6) for (const pz of [51.8, 58.2]) lv.box("darkwood", px, -1.4, pz, 0.5, 1.8, 0.5);
  // pier railings
  lv.box("darkmetal", 309, 0.3, 51.4, 22, 0.9, 0.12, { collide: true });
  lv.box("darkmetal", 309, 0.3, 58.6, 22, 0.9, 0.12, { collide: true });
  lv.box("red", 319.6, 0.3, 55, 0.3, 0.5, 7.4, { collide: true }); // end bumper
  lv.light(300, 4.5, 55, 0xaaccff, 1.4, 16);
  lv.box("darkmetal", 300, 0.3, 51.8, 0.2, 4.5, 0.2);
  // deck edge barriers (keep player out of water except pier)
  lv.colliders.push({ minx: 299.8, maxx: 300.2, miny: 0, maxy: 2, minz: 20, maxz: 51.5 });
  lv.colliders.push({ minx: 299.8, maxx: 300.2, miny: 0, maxy: 2, minz: 58.5, maxz: 90 });
  // water
  lv.box("water", 440, -0.45, 55, 280, 0.2, 500);
  lv.box("water", 320, -0.45, 230, 520, 0.2, 280);
  lv.box("water", 320, -0.45, -160, 520, 0.2, 150);
  // roadblock before gate
  lv.car(232, 53, 1.2, "white", true);
  lv.car(236, 48, 2.8, "darkmetal", true);
  for (let i = 0; i < 4; i++) lv.box("military", 228 + i * 3, 0, 58 - i * 2, 1.4, 1.1, 0.5, { collide: true, ry: 0.3 * i });
  lv.box("emergency", 233, 1.2, 50, 0.3, 0.2, 0.3);
  lv.light(233, 2.5, 50, 0xff3010, 1.2, 12, true);

  // bus stop near school exit
  lv.box("darkmetal", 40, 0, -8, 0.2, 2.6, 0.2);
  lv.box("darkmetal", 40, 0, -14, 0.2, 2.6, 0.2);
  lv.box("glass", 40.5, 0.4, -11, 0.15, 1.8, 5.6);
  lv.box("white", 40, 2.6, -11, 1.6, 0.15, 6.4);
  lv.box("wood", 39.6, 0.5, -11, 0.5, 0.08, 5);
  // school bike rack
  lv.box("metal", 34.5, 0, 8, 0.15, 0.9, 5);

  // ---------- city pickups ----------
  const P = (id: string, kind: import("./level").PickupKind, x: number, y: number, z: number, where: string) => lv.pickups.push({ id, kind, x, y, z, where });
  P("hp_ph1", "health", 81.5, 0.95, 20, "pharmacy shelf");
  P("hp_ph2", "health", 84.5, 0.95, 24, "pharmacy shelf");
  P("hp_ph3", "health", 86.6, 1.05, 23.5, "pharmacy counter");
  P("ar_gs1", "ammo_rifle", 84, 1.15, -18.5, "gun counter");
  P("ar_gs2", "ammo_rifle", 87.2, 1.3, -21, "gun rack");
  P("as_gs1", "ammo_shotgun", 84, 1.15, -21.5, "gun counter");
  P("as_gs2", "ammo_shotgun", 87.2, 0.6, -18, "gun rack");
  P("ap_gs1", "ammo_pistol", 87.2, 1.0, -24, "gun rack");
  P("rifle2", "rifle", 84, 1.2, -20, "display case");
  P("ap_mm1", "ammo_pistol", 42, 1.4, 38.3, "minimart shelf");
  P("hp_mm1", "health", 46, 0.95, 40.3, "minimart shelf");
  P("toolbox1", "toolbox", 49.2, 0.85, 37, "storeroom crate");
  P("ap_sh", "ammo_pistol", 121.3, 1.45, 65.3, "hideout stash");
  P("as_sh", "ammo_shotgun", 121.0, 0.85, 65.8, "hideout stash");
  P("ar_sh", "ammo_rifle", 121.6, 0.85, 65.0, "hideout stash");
  P("hp_sh", "health", 124, 0.85, 60, "safehouse table");
  P("hp_hb", "health", 250, 2.65, 26, "container top");
  P("ar_hb", "ammo_rifle", 253, 0.1, 35, "harbor deck");
  P("ap_bus", "ammo_pistol", 39.6, 0.6, -12, "bus stop bench");

  // ---------- city notes ----------
  lv.notes.push({ id: "c1", x: 39.6, y: 0.62, z: -10, title: "Soaked flyer", text: "EVACUATION NOTICE: All civilians report to the HARBOR EVAC ZONE. Boats depart while the carrier remains offshore. Do not attempt the highway." });
  lv.notes.push({ id: "c2", x: 86.6, y: 1.07, z: 20.5, title: "Pharmacist's note", text: "Gave the last antibiotics to the girl from the gas station — Mina. Brave kid. Her little sister Astra hides here when the streets get loud." });
  lv.notes.push({ id: "c3", x: 124, y: 0.87, z: 59.6, title: "Hideout logbook", text: "Day 9. Whoever stayed here last kept this place stocked, then stopped writing. The harbor broadcast is still looping on a tape deck — the last boat waits for no one. Ravi swears his sports car can outrun anything on the avenue." });

  // ---------- city nav ----------
  const nav = lv.nav;
  const add = (x: number, z: number) => { const n = { id: nav.length, x, y: 0, z, edges: [] as { to: number; door?: string }[] }; nav.push(n); return n; };
  const link = (a: ReturnType<typeof add>, b: ReturnType<typeof add>) => { a.edges.push({ to: b.id }); b.edges.push({ to: a.id }); };
  const chain = (pts: [number, number][]) => {
    const ns = pts.map((p) => add(p[0], p[1]));
    for (let i = 1; i < ns.length; i++) link(ns[i - 1], ns[i]);
    return ns;
  };
  const aveA = chain(Array.from({ length: 15 }, (_, i) => [68, -130 + i * 15] as [number, number]));
  const stB = chain(Array.from({ length: 24 }, (_, i) => [-60 + i * 15, 51] as [number, number]));
  const stC = chain(Array.from({ length: 13 }, (_, i) => [48 + i * 15, -60] as [number, number]));
  const aveD = chain(Array.from({ length: 12 }, (_, i) => [150, -125 + i * 15] as [number, number]));
  const near = (list: ReturnType<typeof add>[], x: number, z: number) => list.reduce((a, b) => ((b.x - x) ** 2 + (b.z - z) ** 2 < (a.x - x) ** 2 + (a.z - z) ** 2 ? b : a));
  // --- street crossings (these MUST link the chains or the graph splits into islands) ---
  link(near(aveA, 68, 51), near(stB, 68, 51));      // avenue A x street B
  link(near(aveA, 68, -60), near(stC, 68, -60));    // avenue A x street C
  link(near(aveD, 150, 51), near(stB, 150, 51));     // avenue D x street B
  link(near(aveD, 150, -60), near(stC, 150, -60));   // avenue D x street C
  // street B runs east-west; street C runs east-west too, so connect them directly (both span x 48..240)
  link(near(stC, 120, -60), near(stB, 120, 51));
  link(near(stB, 40, 51), near(aveA, 68, 51));
  // --- school front -> avenue A ---
  const f1 = add(36, 0), f2 = add(50, 0);
  link(f1, f2);
  link(f2, near(aveA, 68, 0));
  // school-side node must reach the school interior nav (node 0 area) — connect via the lobby
  const schoolLink = lv.nav[0];
  link(f1, schoolLink);
  // gas station / shops / garage spurs
  const g1 = add(46, 30);
  link(g1, near(stB, 46, 51));
  link(g1, f1);
  const ph = add(80, 22); link(ph, near(aveA, 68, 22));
  const gs = add(80, -20); link(gs, near(aveA, 68, -20));
  const gr = add(107, 54); link(gr, near(stB, 107, 51));
  const hb1 = add(250, 55), hb2 = add(280, 55), hb3 = add(305, 55);
  link(near(stB, 240, 51), hb1); link(hb1, hb2); link(hb2, hb3);
  // pier reaches the boat
  const pier = add(312, 55); link(hb3, pier);
  buildLazarus(lv);
}

export function buildLazarus(lv: Level) {
  // ---------- CHAPTER 2 EXTENDED: Lazarus locations ----------
  // Broadcast van at Street C junction (68,-60)
  lv.box("white", 70, 0.3, -58, 2.4, 2.4, 5.6, { collide: true, ry: 0.35 });
  lv.box("darkmetal", 70, 2.7, -58, 0.2, 1.8, 0.2);
  lv.box("darkmetal", 70, 4.5, -58, 1.6, 0.06, 0.06);
  lv.box("glass", 70, 1.0, -60.9, 2.2, 1.0, 0.1, { ry: 0.35 });
  lv.sign("RIVERSIDE 7 NEWS", 71.25, 1.6, -58, Math.PI / 2 + 0.35, "#1a3a7a", 3);
  lv.box("emergency", 70, 2.1, -55.2, 0.3, 0.15, 0.3);
  lv.light(70, 2.6, -56, 0xff2020, 1.2, 10, true);
  lv.box("black", 72, 0, -57, 0.6, 0.9, 0.9, { collide: true }); // generator
  lv.car(64, -56, 2.3, "red", true);

  // Riverside General hospital — small enterable wing on the block at (90..122, -34..-10)
  // carve a courtyard + front wing into the solid block: we build the wing in front (z -10..-2 is road? street? block ends at -10). Use z -46..-34 strip south of the block.
  const hx0 = 94, hx1 = 118, hz0 = -46, hz1 = -36;
  lv.box("floor", 106, -0.015, -41, hx1 - hx0, 0.05, hz1 - hz0);
  lv.box("concrete", 106, 4.0, -41, hx1 - hx0 + 0.5, 0.35, hz1 - hz0 + 0.5);
  lv.wallZ(hx0, hz0, hz1, 0, 4.0, [], "plaster");
  lv.wallZ(hx1, hz0, hz1, 0, 4.0, [], "plaster");
  lv.wallX(hz0, hx0, hx1, 0, 4.0, [{ c: 106, w: 3.2, h: 2.8 }], "plaster"); // entrance faces Street C (south)
  lv.wallX(hz1, hx0, hx1, 0, 4.0, [], "plaster");
  lv.sign("RIVERSIDE GENERAL — EMERGENCY", 106, 4.6, hz0 - 0.16, 0, "#8a1a1a", 7);
  lv.box("exit", 106, 3.0, hz0 - 0.1, 0.6, 0.2, 0.05);
  // ward partitions: rooms 4A, 4B, 4C along the north wall
  for (let i = 0; i < 3; i++) {
    const rx = 97 + i * 7;
    lv.wallZ(rx + 6, -42, hz1, 0, 4.0, [], "plaster");
    lv.wallX(-42, rx, rx + 6, 0, 4.0, [{ c: rx + 3, w: 1.4, h: 2.4 }], "plaster");
    lv.sign("ROOM 4" + "ABC"[i], rx + 3, 2.9, -42.12, 0, i === 1 ? "#5a1a1a" : "#1b3a4d", 1.4);
    // bed
    lv.box("metal", rx + 3, 0, -39, 1.0, 0.6, 2.0, { collide: true });
    lv.box("white", rx + 3, 0.6, -39, 0.95, 0.15, 1.9);
    if (i === 1) { lv.bloodPool(rx + 3, 0, -40, 1.2); lv.box("red", rx + 3.2, 0.75, -38.6, 0.5, 0.05, 0.5); }
  }
  lv.wallZ(97, -42, hz1, 0, 4.0, [], "plaster");
  lv.papers(hx0 + 1, hx1 - 1, hz0 + 1, hz1 - 1, 0, 30);
  lv.bloodPool(106, 0, -44, 1.8);
  lv.box("white", 112, 0, -44.5, 3, 1.0, 0.8, { collide: true }); // reception
  for (let k = 0; k < 4; k++) lv.box("metal", 98 + k * 1.2, 0, -44.8, 0.9, 0.5, 0.6, { collide: true }); // waiting chairs
  lv.light(106, 3.4, -41, 0xaad0ff, 1.4, 14);
  lv.light(104, 3.4, -39, 0xff2020, 1.0, 9, true);
  lv.box("darkmetal", 106, 0, -34.5, 1.2, 1.9, 0.6, { collide: true }); // gurney against inner wall
  // courtyard (kill-zone for M9) just outside: ambulance wrecks
  lv.car(100, -50, 0.4, "white", true);
  lv.car(112, -49, 2.9, "white", false);
  lv.box("red", 100, 0.9, -50, 0.3, 0.3, 1.0);

  // Memorial Chapel on Avenue D (150, -100)
  const cx0 = 158, cx1 = 170, cz0 = -106, cz1 = -94;
  lv.box("floor", 164, -0.015, -100, 12, 0.05, 12);
  lv.box("darkwood", 164, 5.2, -100, 12.6, 0.4, 12.6);
  lv.box("darkwood", 164, 5.6, -100, 1.0, 2.2, 1.0); // steeple
  lv.wallZ(cx0, cz0, cz1, 0, 5.2, [{ c: -100, w: 2.4, h: 3.2 }], "brick"); // door faces Avenue D (west)
  lv.wallZ(cx1, cz0, cz1, 0, 5.2, [], "brick");
  lv.wallX(cz0, cx0, cx1, 0, 5.2, [], "brick");
  lv.wallX(cz1, cx0, cx1, 0, 5.2, [], "brick");
  lv.sign("MEMORIAL CHAPEL", cx0 - 0.16, 4.2, -100, -Math.PI / 2, "#3a2a1a", 4);
  for (let r = 0; r < 4; r++) { lv.box("darkwood", 162, 0, -103 + r * 2, 3.0, 0.5, 0.5, { collide: true }); lv.box("darkwood", 166.5, 0, -103 + r * 2, 3.0, 0.5, 0.5, { collide: true }); }
  lv.box("darkwood", 168.5, 0, -100, 1.2, 1.1, 2.4, { collide: true }); // altar
  lv.box("lamp", 168.5, 1.1, -100.6, 0.1, 0.25, 0.1); lv.box("lamp", 168.5, 1.1, -99.4, 0.1, 0.25, 0.1);
  lv.sign("MAYA VARMA — 'She gave herself so others would heal'", 169.84, 2.4, -100, -Math.PI / 2, "#2a2a2a", 3.6);
  lv.box("glass", 169.9, 3.4, -100, 0.1, 1.6, 2.4); // stained window
  lv.light(168, 3.0, -100, 0xffc070, 1.4, 10);
  // the service hatch behind the altar
  lv.box("darkmetal", 168.5, 0.01, -97.2, 1.4, 0.08, 1.4);
  lv.box("yellow", 168.5, 0.09, -97.2, 0.4, 0.04, 0.4);
  lv.box("black", 169.5, 0.6, -97.2, 0.15, 0.3, 0.2); // keypad
  lv.box("emergency", 169.5, 0.95, -97.2, 0.05, 0.05, 0.05);
  lv.light(168.5, 1.0, -97.2, 0x22ff55, 0.8, 4);

  // Helix sedan wreck on Street B east of Avenue D (180, 51)
  lv.box("black", 180, 0.2, 49.5, 4.2, 0.7, 1.8, { ry: 0.6 });
  lv.box("black", 179.7, 0.9, 49.5, 2.2, 0.6, 1.6, { ry: 0.6 });
  lv.box("glass", 179.7, 0.95, 49.5, 2.25, 0.45, 1.65, { ry: 0.6 });
  lv.box("darkmetal", 181.6, 0.9, 50.2, 1.2, 0.5, 1.4, { ry: 1.0 }); // crumpled hood
  lv.sign("HELIX BIOLABS", 180, 1.0, 50.7, 0.6, "#0a3a3a", 1.6);
  lv.box("yellow", 178, 0.01, 52, 0.8, 0.02, 0.6);
  lv.bloodPool(182, 0, 52, 1.4);

  // Lazarus pickups
  const PK = (id: string, kind: import("./level").PickupKind, x: number, y: number, z: number, where: string) => lv.pickups.push({ id, kind, x, y, z, where });
  PK("file_4b", "file_4b", 107.2, 0.78, -38.6, "Room 4B bedside");
  PK("helix_keycard", "helix_keycard", 180.4, 0.62, 49.6, "Helix sedan");
  PK("ar_van", "ammo_rifle", 72, 0.95, -57, "news van generator");
  PK("hp_hosp1", "health", 112, 1.05, -44.5, "hospital reception");
  PK("hp_hosp2", "health", 100, 0.78, -38.6, "Room 4A");
  PK("ap_hosp", "ammo_pistol", 114, 0.78, -38.6, "Room 4C");
  PK("as_chapel", "ammo_shotgun", 161, 0.55, -103, "chapel pew");
  PK("ar_chapel", "ammo_rifle", 166.5, 0.55, -97, "chapel pew");
  PK("ar_sedan", "ammo_rifle", 182.5, 0.1, 51.5, "sedan trunk");

  // Lazarus notes (extra environmental lore)
  lv.notes.push({ id: "lz1", x: 70, y: 1.2, z: -55.4, title: "News van teleprompter", text: "...Helix BioLabs CEO denies rumors that a terminated researcher removed biological material from the company. 'Dr. Varma was grieving. We wish him peace.' — recorded 3 weeks before the outbreak." });
  lv.notes.push({ id: "lz2", x: 100, y: 0.78, z: -38.6, title: "Nurse's chart, Room 4A", text: "Room 4B keeps calling for Elias. He hasn't left her chair in 3 days. Dr. Pell says there's nothing more — the serum is rebuilding her faster than her body can bear it. She keeps apologizing to him." });
  lv.notes.push({ id: "lz3", x: 162, y: 0.55, z: -101, title: "Chapel guest book", text: "'For Maya. You were right about everything except the dose.' — E.  ·  'For Maya. 11 months. I have Donor 07's school. Soon.' — E.  ·  'For Maya. Thursday.' — E." });
  lv.notes.push({ id: "lz4", x: 112, y: 1.07, z: -44.5, title: "Hospital security memo", text: "Night shift: Dr. Varma (ex-Helix) was found in the morgue cold storage again. He claims he has 'signed release forms' for two John Does. Security escorted him out. He said: 'You'll thank me when nobody has to die.'" });

  // nav: hospital wing, chapel, sedan wreck
  const nn = (x: number, z: number) => { const n = { id: lv.nav.length, x, y: 0, z, edges: [] as { to: number; door?: string }[] }; lv.nav.push(n); return n; };
  const ln = (a: { id: number; edges: { to: number; door?: string }[] }, b: { id: number; edges: { to: number; door?: string }[] }) => { a.edges.push({ to: b.id }); b.edges.push({ to: a.id }); };
  // attach spurs to the real street chains (never to freshly-created nodes)
  const nearest = (x: number, z: number) => lv.nav.reduce((a, b) => (Math.abs(b.y) < 1 && (b.x - x) ** 2 + (b.z - z) ** 2 < (a.x - x) ** 2 + (a.z - z) ** 2 ? b : a));
  const hOut = nn(106, -50), hIn = nn(106, -44), hMid = nn(106, -40), h4a = nn(100, -40), h4b = nn(107, -40), h4c = nn(114, -40);
  ln(nearest(106, -60), hOut); ln(hOut, hIn); ln(hIn, hMid); ln(hMid, h4a); ln(hMid, h4b); ln(hMid, h4c);
  const chOut = nn(154, -100), chIn = nn(160, -100), chAlt = nn(167, -100);
  ln(nearest(150, -100), chOut); ln(chOut, chIn); ln(chIn, chAlt);
  // the chapel door is on the west wall (x=158): add a node right inside it
  const sd = nn(180, 53); ln(nearest(180, 51), sd);
  const van = nn(70, -62); ln(nearest(68, -60), van);
}

// mission zombie packs (persistent ids via prefix)
export const M3_SPAWNS: [number, number, number, boolean?][] = [[64, -62, 0], [72, -64, 1], [66, -54, 2, true], [74, -56, 3], [60, -60, 4], [68, -68, 0], [76, -62, 1, true]];
// the horde blocking the road to the pier (street B, just before the harbor gate)
export const M4_SPAWNS: [number, number, number, boolean?][] = [
  [228, 50, 0], [232, 56, 1], [236, 48, 2, true], [240, 54, 3], [244, 50, 4], [248, 57, 0],
  [230, 44, 1], [238, 42, 2], [246, 46, 3, true], [252, 52, 4], [234, 60, 0], [242, 60, 1, true],
];



