import * as THREE from "three";

function canvas(size: number, draw: (g: CanvasRenderingContext2D, s: number) => void, repeat = 1) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  draw(g, size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 2;
  return t;
}

function grime(g: CanvasRenderingContext2D, s: number, n: number, alpha: number) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = `rgba(0,0,0,${Math.random() * alpha})`;
    const r = Math.random() * s * 0.08 + 2;
    g.beginPath();
    g.arc(Math.random() * s, Math.random() * s, r, 0, Math.PI * 2);
    g.fill();
  }
}

export function makeTextures() {
  const floorTile = canvas(256, (g, s) => {
    const n = 4;
    const w = s / n;
    for (let y = 0; y < n; y++)
      for (let x = 0; x < n; x++) {
        const v = (x + y) % 2 ? 180 : 150;
        const j = Math.random() * 15;
        g.fillStyle = `rgb(${v + j},${v + j - 5},${v + j - 15})`;
        g.fillRect(x * w, y * w, w, w);
      }
    g.strokeStyle = "rgba(40,40,40,0.5)";
    g.lineWidth = 2;
    for (let i = 0; i <= n; i++) {
      g.beginPath(); g.moveTo(i * w, 0); g.lineTo(i * w, s); g.stroke();
      g.beginPath(); g.moveTo(0, i * w); g.lineTo(s, i * w); g.stroke();
    }
    grime(g, s, 50, 0.12);
  });

  const wall = canvas(256, (g, s) => {
    g.fillStyle = "#b9b4a2";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 3000; i++) {
      g.fillStyle = `rgba(${Math.random() > 0.5 ? 255 : 0},${Math.random() > 0.5 ? 255 : 0},0,0.03)`;
      g.fillRect(Math.random() * s, Math.random() * s, 2, 2);
    }
    // lower panel
    g.fillStyle = "#5b6e5a";
    g.fillRect(0, s * 0.7, s, s * 0.3);
    g.fillStyle = "#3e4c3e";
    g.fillRect(0, s * 0.7, s, 4);
    grime(g, s, 30, 0.1);
    // faint grime streaks (kept subtle — big red smears read as blobs)
    for (let i = 0; i < 3; i++) {
      g.fillStyle = "rgba(70,58,44,0.10)";
      const x = Math.random() * s;
      g.fillRect(x, s * 0.4 + Math.random() * 40, 3 + Math.random() * 5, 50 + Math.random() * 40);
    }
  });

  const plaster = canvas(128, (g, s) => {
    g.fillStyle = "#a8a39a";
    g.fillRect(0, 0, s, s);
    grime(g, s, 30, 0.08);
  });

  const ceiling = canvas(128, (g, s) => {
    g.fillStyle = "#cfcabd";
    g.fillRect(0, 0, s, s);
    g.strokeStyle = "#8f8a7e";
    g.lineWidth = 2;
    g.strokeRect(1, 1, s - 2, s - 2);
    for (let i = 0; i < 400; i++) {
      g.fillStyle = "rgba(0,0,0,0.08)";
      g.fillRect(Math.random() * s, Math.random() * s, 1, 1);
    }
    grime(g, s, 6, 0.15);
  });

  const wood = canvas(128, (g, s) => {
    g.fillStyle = "#7a5230";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 40; i++) {
      g.strokeStyle = `rgba(40,20,5,${Math.random() * 0.4})`;
      g.beginPath();
      const y = Math.random() * s;
      g.moveTo(0, y);
      g.bezierCurveTo(s / 3, y + 5, (2 * s) / 3, y - 5, s, y);
      g.stroke();
    }
  });

  const blackboard = canvas(256, (g, s) => {
    g.fillStyle = "#1f3a2a";
    g.fillRect(0, 0, s, s);
    g.strokeStyle = "rgba(255,255,255,0.7)";
    g.fillStyle = "rgba(255,255,255,0.8)";
    g.font = "22px monospace";
    g.fillText("CHEMISTRY  p.42", 20, 40);
    g.fillText("H2O + CO2 ->", 20, 80);
    g.font = "bold 30px monospace";
    g.fillStyle = "rgba(220,40,40,0.85)";
    g.fillText("THEY'RE INSIDE", 20, 150);
    g.fillText("RUN", 90, 200);
    g.strokeStyle = "rgba(255,255,255,0.3)";
    for (let i = 0; i < 8; i++) {
      g.beginPath();
      g.moveTo(Math.random() * s, Math.random() * s);
      g.lineTo(Math.random() * s, Math.random() * s);
      g.stroke();
    }
  });

  const locker = canvas(128, (g, s) => {
    g.fillStyle = "#3d5a78";
    g.fillRect(0, 0, s, s);
    g.fillStyle = "#2a3f56";
    g.fillRect(0, 0, 4, s);
    for (let i = 0; i < 5; i++) g.fillRect(s * 0.3, 15 + i * 6, s * 0.4, 2);
    g.fillStyle = "#aaa";
    g.fillRect(s * 0.8, s * 0.5, 6, 14);
    grime(g, s, 10, 0.15);
  });

  const books = canvas(128, (g, s) => {
    g.fillStyle = "#3a2410";
    g.fillRect(0, 0, s, s);
    for (let row = 0; row < 4; row++) {
      let x = 0;
      while (x < s) {
        const w = 4 + Math.random() * 8;
        const h = 20 + Math.random() * 8;
        g.fillStyle = `hsl(${Math.random() * 360},${30 + Math.random() * 30}%,${20 + Math.random() * 25}%)`;
        if (Math.random() > 0.1) g.fillRect(x, row * 32 + 30 - h, w - 1, h);
        x += w;
      }
      g.fillStyle = "#2a1808";
      g.fillRect(0, row * 32 + 29, s, 3);
    }
  }, 1);

  const ground = canvas(128, (g, s) => {
    g.fillStyle = "#3b3d36";
    g.fillRect(0, 0, s, s);
    for (let i = 0; i < 2000; i++) {
      const v = Math.random() * 40;
      g.fillStyle = `rgba(${v},${v},${v},0.3)`;
      g.fillRect(Math.random() * s, Math.random() * s, 2, 2);
    }
  });

  const brick = canvas(128, (g, s) => {
    g.fillStyle = "#5a5148";
    g.fillRect(0, 0, s, s);
    const bh = 16, bw = 32;
    for (let y = 0; y < s / bh; y++)
      for (let x = -1; x < s / bw + 1; x++) {
        const v = 110 + Math.random() * 30;
        g.fillStyle = `rgb(${v},${v * 0.55},${v * 0.42})`;
        g.fillRect(x * bw + (y % 2) * 16 + 1, y * bh + 1, bw - 2, bh - 2);
      }
  });

  const paper = canvas(64, (g, s) => {
    g.fillStyle = "#e8e4d8";
    g.fillRect(0, 0, s, s);
    g.fillStyle = "rgba(0,0,0,0.35)";
    for (let i = 0; i < 8; i++) g.fillRect(6, 8 + i * 6, 30 + Math.random() * 20, 2);
  });

  return { floorTile, wall, plaster, ceiling, wood, blackboard, locker, books, ground, brick, paper };
}

export function cityTexture(seed: number) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 256;
  const g = c.getContext("2d")!;
  const base = ["#14161d", "#191b22", "#101318"][seed % 3];
  g.fillStyle = base;
  g.fillRect(0, 0, 128, 256);
  const cols = 6, rows = 16;
  for (let y = 0; y < rows; y++)
    for (let x = 0; x < cols; x++) {
      const r = Math.random();
      if (r < 0.14) g.fillStyle = `rgba(255,${190 + Math.random() * 40},${110 + Math.random() * 60},${0.75 + Math.random() * 0.25})`;
      else if (r < 0.2) g.fillStyle = "rgba(150,190,230,0.5)";
      else if (r < 0.27) g.fillStyle = "rgba(255,120,40,0.55)"; // fire glow window
      else g.fillStyle = "rgba(5,6,10,0.9)";
      g.fillRect(x * 21 + 5, y * 16 + 4, 12, 8);
    }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function smokeTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  for (let i = 0; i < 40; i++) {
    const x = 64 + (Math.random() - 0.5) * 50, y = 64 + (Math.random() - 0.5) * 80;
    const r = 15 + Math.random() * 25;
    const grd = g.createRadialGradient(x, y, 0, x, y, r);
    grd.addColorStop(0, "rgba(30,30,36,0.25)");
    grd.addColorStop(1, "rgba(30,30,36,0)");
    g.fillStyle = grd;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  return t;
}

export function skyTexture() {
  const c = document.createElement("canvas");
  c.width = 1024;
  c.height = 512;
  const g = c.getContext("2d")!;
  const grd = g.createLinearGradient(0, 0, 0, 512);
  grd.addColorStop(0, "#05070f");
  grd.addColorStop(0.45, "#0a0e1c");
  grd.addColorStop(0.72, "#141627");
  grd.addColorStop(0.82, "#2a1c1a");
  grd.addColorStop(0.88, "#44231a");
  grd.addColorStop(1, "#1a0e0a");
  g.fillStyle = grd;
  g.fillRect(0, 0, 1024, 512);
  // stars
  for (let i = 0; i < 420; i++) {
    const y = Math.random() * 330;
    const a = Math.random() * 0.8 * (1 - y / 380);
    g.fillStyle = `rgba(255,255,255,${a})`;
    g.fillRect(Math.random() * 1024, y, Math.random() < 0.08 ? 2 : 1, 1);
  }
  // fire glows on horizon
  for (let i = 0; i < 9; i++) {
    const x = Math.random() * 1024, w = 40 + Math.random() * 120;
    const fg = g.createRadialGradient(x, 440, 0, x, 440, w);
    fg.addColorStop(0, "rgba(255,110,30,0.35)");
    fg.addColorStop(1, "rgba(255,110,30,0)");
    g.fillStyle = fg;
    g.fillRect(x - w, 440 - w, w * 2, w * 2);
  }
  // moon
  const mx = 260, my = 110;
  const mg = g.createRadialGradient(mx, my, 0, mx, my, 60);
  mg.addColorStop(0, "rgba(220,228,255,0.9)");
  mg.addColorStop(0.3, "rgba(200,210,250,0.5)");
  mg.addColorStop(1, "rgba(200,210,250,0)");
  g.fillStyle = mg;
  g.beginPath();
  g.arc(mx, my, 60, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "#e8ecff";
  g.beginPath();
  g.arc(mx, my, 22, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "rgba(160,170,200,0.5)";
  g.beginPath();
  g.arc(mx - 7, my + 5, 6, 0, Math.PI * 2);
  g.arc(mx + 8, my - 6, 4, 0, Math.PI * 2);
  g.fill();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function signTexture(text: string, bg = "#1b4d2e", fg = "#ffffff", w = 256, h = 64) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  g.fillStyle = bg;
  g.fillRect(0, 0, w, h);
  g.fillStyle = fg;
  g.font = `bold ${Math.floor(h * 0.45)}px Arial, sans-serif`;
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, w / 2, h / 2);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
