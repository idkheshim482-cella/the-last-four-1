import { WEAPONS, type WeaponId } from "../game/weapons";
import type { Engine } from "../game/engine";

const WICONS: Record<WeaponId, string> = { pistol: "▄▖", shotgun: "▄▄▄", rifle: "▄▄▛" };
const AMMO_META: { w: WeaponId; name: string; icon: string; color: string }[] = [
  { w: "pistol", name: "9MM ROUNDS", icon: "●", color: "text-amber-300" },
  { w: "shotgun", name: "SHELLS", icon: "◆", color: "text-red-300" },
  { w: "rifle", name: "5.56 ROUNDS", icon: "▲", color: "text-lime-300" },
];
const KEY_LABEL: Record<string, string> = { key_janitor: "Janitor's Key", key_principal: "Principal's Key", key_office: "Office Key", toolbox: "Ravi's Toolbox", file_4b: "Medical File — Room 4B", helix_keycard: "Helix Keycard (Dr. Varma)" };

export default function Inventory({ engine, onClose, onOpenMap }: { engine: Engine; onClose: () => void; onOpenMap: () => void }) {
  const gear: { icon: string; name: string; sub: string; act?: () => void; actLabel?: string }[] = [];
  if (engine.hasFlashlight)
    gear.push({ icon: "🔦", name: "FLASHLIGHT", sub: engine.flashOn ? "ON — infected see you further" : "OFF", act: () => { engine.flashOn = !engine.flashOn; }, actLabel: engine.flashOn ? "TURN OFF" : "TURN ON" });
  if (engine.keys.includes("city_map"))
    gear.push({ icon: "🗺", name: "CITY MAP", sub: "Mina's father's map of Riverside", act: () => { onClose(); onOpenMap(); }, actLabel: "OPEN" });
  for (const k of engine.keys) if (KEY_LABEL[k]) gear.push({ icon: "🔑", name: KEY_LABEL[k].toUpperCase(), sub: "Quest item" });

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-3 backdrop-blur-[2px]" onClick={onClose}>
      <div className="lf-in max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-md border border-white/15 bg-gradient-to-b from-[#12151c]/95 to-[#0a0c10]/95 p-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between border-b border-white/10 pb-2">
          <div>
            <div className="text-sm font-black tracking-[0.35em] text-white">INVENTORY</div>
            <div className="text-[10px] tracking-widest text-white/40">AKHIL — {Math.ceil(engine.health)} HP</div>
          </div>
          <button onClick={onClose} className="rounded border border-white/25 bg-white/5 px-4 py-1.5 text-xs font-bold tracking-widest hover:bg-white/15">CLOSE [I]</button>
        </div>

        {/* weapons */}
        <div className="mb-1 text-[10px] font-bold tracking-[0.35em] text-red-400">WEAPONS</div>
        <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
          {(["pistol", "shotgun", "rifle"] as WeaponId[]).map((w) => {
            const owned = engine.owned.includes(w);
            const eq = engine.current === w;
            const a = engine.ammo[w];
            return (
              <div key={w} className={`rounded border p-2.5 ${eq ? "border-red-500/70 bg-red-950/40" : owned ? "border-white/15 bg-white/5" : "border-white/5 bg-black/30 opacity-45"}`}>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-lg text-white/80">{WICONS[w]}</span>
                  {eq && <span className="rounded bg-red-700 px-1.5 py-0.5 text-[9px] font-bold tracking-widest">EQUIPPED</span>}
                </div>
                <div className="mt-1 text-[11px] font-bold tracking-wider">{WEAPONS[w].name}</div>
                {owned ? (
                  <>
                    <div className="mb-1.5 text-[10px] text-white/55">{a.mag}/{WEAPONS[w].mag} mag · {a.reserve} reserve</div>
                    <div className="mb-1.5 h-1 w-full overflow-hidden rounded bg-white/10">
                      <div className="h-full bg-amber-400/80" style={{ width: `${(a.mag / WEAPONS[w].mag) * 100}%` }} />
                    </div>
                    {!eq && (
                      <button onClick={() => { engine.equip(w); onClose(); }} className="w-full rounded border border-amber-500/50 bg-amber-900/40 py-1 text-[10px] font-bold tracking-widest text-amber-200 hover:bg-amber-800/50 active:scale-95">EQUIP</button>
                    )}
                  </>
                ) : (
                  <div className="text-[10px] italic text-white/35">Not found yet</div>
                )}
              </div>
            );
          })}
        </div>

        {/* ammo + medkits */}
        <div className="mb-1 text-[10px] font-bold tracking-[0.35em] text-amber-400">SUPPLIES</div>
        <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {AMMO_META.map((am) => (
            <div key={am.w} className="rounded border border-white/10 bg-white/5 p-2 text-center">
              <div className={`text-base ${am.color}`}>{am.icon}</div>
              <div className="text-[9px] tracking-widest text-white/50">{am.name}</div>
              <div className="text-sm font-bold">{engine.ammo[am.w].reserve + engine.ammo[am.w].mag}</div>
            </div>
          ))}
          <div className={`rounded border p-2 text-center ${engine.medkits > 0 ? "border-emerald-500/40 bg-emerald-950/40" : "border-white/10 bg-white/5 opacity-50"}`}>
            <div className="text-base text-emerald-300">✚</div>
            <div className="text-[9px] tracking-widest text-white/50">MEDKITS</div>
            <div className="text-sm font-bold">{engine.medkits}</div>
            <button onClick={() => engine.useMedkit()} disabled={engine.medkits <= 0 || engine.health >= 100}
              className="mt-1 w-full rounded border border-emerald-500/50 bg-emerald-900/50 py-0.5 text-[9px] font-bold tracking-widest text-emerald-200 hover:bg-emerald-800/60 active:scale-95 disabled:opacity-40">
              USE (+45)
            </button>
          </div>
        </div>

        {/* gear */}
        <div className="mb-1 text-[10px] font-bold tracking-[0.35em] text-sky-400">GEAR & QUEST ITEMS</div>
        {gear.length === 0 ? (
          <div className="rounded border border-white/10 bg-white/5 p-3 text-center text-[11px] italic text-white/40">Nothing yet — search desks, cupboards and shops.</div>
        ) : (
          <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
            {gear.map((g, i) => (
              <div key={i} className="flex items-center gap-2.5 rounded border border-white/10 bg-white/5 p-2">
                <div className="text-lg">{g.icon}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-bold tracking-wider">{g.name}</div>
                  <div className="truncate text-[9px] text-white/45">{g.sub}</div>
                </div>
                {g.act && <button onClick={g.act} className="rounded border border-sky-500/50 bg-sky-900/50 px-2.5 py-1 text-[9px] font-bold tracking-widest text-sky-200 hover:bg-sky-800/60 active:scale-95">{g.actLabel}</button>}
              </div>
            ))}
          </div>
        )}
        {engine.stage >= 3 && (
          <>
            <div className="mb-1 mt-3 text-[10px] font-bold tracking-[0.35em] text-amber-400">MISSIONS — THE ESCAPE</div>
            <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
              {engine.ui.missions.map((m) => (
                <div key={m.id} className={`flex items-center gap-2 rounded border px-2 py-1 ${m.status === 3 ? "border-emerald-700/50 bg-emerald-950/30" : m.status >= 1 ? "border-amber-500/50 bg-amber-950/30" : "border-white/10 bg-white/5 opacity-60"}`}>
                  <span className={`w-4 text-center text-[10px] font-bold ${m.status === 3 ? "text-emerald-300" : m.status >= 1 ? "text-amber-300" : "text-white/40"}`}>{m.status === 3 ? "✓" : m.status >= 1 ? "▶" : m.id}</span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10px] font-bold tracking-wider">{m.title}</div>
                    <div className="text-[9px] text-white/45">{m.giver}{m.status === 1 ? " · " + m.prog : m.status === 2 ? " · turn in" : ""}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
        <div className="mt-3 text-center text-[9px] tracking-widest text-white/30">THE WORLD KEEPS MOVING WHILE YOU DIG THROUGH YOUR BAG</div>
      </div>
    </div>
  );
}
