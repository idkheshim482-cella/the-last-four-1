import * as THREE from "three";
import type { Level, NavNode } from "./level";
import { skinSet, fabricSet } from "../gfx/pbr";

const geo = {
  head: new THREE.BoxGeometry(0.24, 0.27, 0.25),
  torso: new THREE.BoxGeometry(0.44, 0.58, 0.24),
  arm: new THREE.BoxGeometry(0.12, 0.6, 0.12),
  leg: new THREE.BoxGeometry(0.16, 0.78, 0.16),
  eye: new THREE.BoxGeometry(0.05, 0.03, 0.01),
  hair: new THREE.BoxGeometry(0.26, 0.08, 0.27),
};
// PBR character materials: skin gets a real pore map, cloth gets weave + high roughness.
const matCache = new Map<string, THREE.MeshStandardMaterial>();
const mat = (c: number, kind: "skin" | "cloth" | "plain" = "plain") => {
  const key = kind + c;
  if (!matCache.has(key)) {
    if (kind === "skin") {
      const set = skinSet("#" + c.toString(16).padStart(6, "0"));
      matCache.set(key, new THREE.MeshStandardMaterial({
        map: set.map, normalMap: set.normalMap, roughnessMap: set.roughnessMap,
        color: c, roughness: 0.78, metalness: 0,
      }));
    } else if (kind === "cloth") {
      const set = fabricSet("#" + c.toString(16).padStart(6, "0"), 2);
      matCache.set(key, new THREE.MeshStandardMaterial({
        map: set.map, normalMap: set.normalMap, roughnessMap: set.roughnessMap,
        color: c, roughness: 0.96, metalness: 0,
      }));
    } else {
      matCache.set(key, new THREE.MeshStandardMaterial({ color: c, roughness: 0.82, metalness: 0.02 }));
    }
  }
  return matCache.get(key)!;
};
const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffdd55 });
const eyeMatHuman = new THREE.MeshStandardMaterial({ color: 0x0d0f12, roughness: 0.12, metalness: 0 });

// soft blob shadow shared by all humanoids (cheap fake shadow for mobile)
let shadowMat: THREE.MeshBasicMaterial | null = null;
const shadowGeo = new THREE.PlaneGeometry(1.15, 1.15);
function getShadowMat() {
  if (shadowMat) return shadowMat;
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const gr = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  gr.addColorStop(0, "rgba(0,0,0,0.55)");
  gr.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 64);
  shadowMat = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false });
  return shadowMat;
}

export interface Look { shirt: number; pants: number; skin: number; hair: number; scale: number }

export const ZOMBIE_LOOKS: Look[] = [
  { shirt: 0xb8b8a8, pants: 0x1e2a44, skin: 0x7d8a6a, hair: 0x1a1410, scale: 1 }, // student uniform
  { shirt: 0x6a4a30, pants: 0x3a3a3a, skin: 0x8a8f72, hair: 0x555555, scale: 1.05 }, // teacher
  { shirt: 0xb85a1a, pants: 0x2a2a20, skin: 0x6f7a5c, hair: 0x2a1a10, scale: 1.08 }, // janitor
  { shirt: 0x8a1a1a, pants: 0x202020, skin: 0x7a876a, hair: 0x3a2410, scale: 0.97 }, // athlete
  { shirt: 0x2a4a6a, pants: 0x4a4a5a, skin: 0x858c70, hair: 0x9a7a40, scale: 0.94 }, // student 2
];

export class Humanoid {
  root = new THREE.Group();
  body = new THREE.Group();
  head: THREE.Mesh;
  armL = new THREE.Group();
  armR = new THREE.Group();
  legL = new THREE.Group();
  legR = new THREE.Group();
  torso: THREE.Mesh;
  walkT = Math.random() * 10;
  scale: number;

  constructor(look: Look, zombie: boolean) {
    this.scale = look.scale;
    const m = (c: number, kind: "skin" | "cloth" | "plain" = "plain") => mat(c, kind);
    this.root.add(this.body);
    this.body.scale.setScalar(look.scale);
    this.root.traverse((o) => { const mm = o as THREE.Mesh; if (mm.isMesh) { mm.castShadow = true; mm.receiveShadow = true; } });
    this.torso = new THREE.Mesh(geo.torso, m(look.shirt, "cloth"));
    this.torso.position.y = 1.15;
    this.body.add(this.torso);
    this.head = new THREE.Mesh(geo.head, m(look.skin, "skin"));
    this.head.position.y = 1.6;
    this.body.add(this.head);
    const hair = new THREE.Mesh(geo.hair, m(look.hair, "cloth"));
    hair.position.y = 0.13;
    this.head.add(hair);
    for (const s of [-1, 1]) {
      const e = new THREE.Mesh(geo.eye, zombie ? eyeMat : eyeMatHuman);
      e.position.set(s * 0.06, 0.02, 0.126);
      this.head.add(e);
    }
    const mkLimb = (g: THREE.Group, x: number, y: number, gm: THREE.BufferGeometry, c: number, len: number) => {
      g.position.set(x, y, 0);
      const mesh = new THREE.Mesh(gm, m(c, "cloth"));
      mesh.position.y = -len / 2;
      g.add(mesh);
      this.body.add(g);
      return mesh;
    };
    const armMesh = mkLimb(this.armL, -0.29, 1.42, geo.arm, look.shirt, 0.6);
    mkLimb(this.armR, 0.29, 1.42, geo.arm, look.shirt, 0.6);
    mkLimb(this.legL, -0.11, 0.8, geo.leg, look.pants, 0.78);
    mkLimb(this.legR, 0.11, 0.8, geo.leg, look.pants, 0.78);
    // hands
    for (const a of [this.armL, this.armR]) {
      const h = new THREE.Mesh(geo.eye, m(look.skin, "skin"));
      h.scale.set(2.4, 3.5, 10);
      h.position.y = -0.62;
      a.add(h);
    }
    void armMesh;
    // blood stains on infected torsos
    if (zombie) {
      const bm = m(0x3a0505);
      const b1 = new THREE.Mesh(geo.eye, bm);
      b1.scale.set(3.2, 6, 1.3);
      b1.position.set(0.07, -0.1, 0.125);
      this.torso.add(b1);
      const b2 = new THREE.Mesh(geo.eye, bm);
      b2.scale.set(2.2, 3, 1.3);
      b2.position.set(-0.1, 0.12, 0.125);
      this.torso.add(b2);
      const b3 = new THREE.Mesh(geo.eye, bm);
      b3.scale.set(2, 2.4, 1.3);
      b3.position.set(0.02, -0.08, 0.126);
      this.head.add(b3);
    }
    // blob shadow
    const sh = new THREE.Mesh(shadowGeo, getShadowMat());
    sh.rotation.x = -Math.PI / 2;
    sh.position.y = 0.025;
    sh.renderOrder = 1;
    this.root.add(sh);
  }

  animWalk(dt: number, speed: number, zombie: boolean) {
    this.walkT += dt * speed * (zombie ? 3.2 : 4.5);
    const s = Math.sin(this.walkT);
    const amp = Math.min(1, speed / 1.5) * (zombie ? 0.5 : 0.7);
    this.legL.rotation.x = s * amp;
    this.legR.rotation.x = -s * amp;
    if (zombie) {
      this.armL.rotation.x = -1.35 + Math.sin(this.walkT * 0.5) * 0.15;
      this.armR.rotation.x = -1.25 + Math.cos(this.walkT * 0.5) * 0.15;
      this.armL.rotation.z = 0.1;
      this.armR.rotation.z = -0.1;
      this.body.rotation.z = Math.sin(this.walkT * 0.5) * 0.08;
      this.body.rotation.x = 0.12;
      this.head.rotation.z = 0.25 + Math.sin(this.walkT * 0.3) * 0.1;
    } else {
      this.armL.rotation.x = -s * amp * 0.9;
      this.armR.rotation.x = s * amp * 0.9;
      this.body.rotation.x = speed > 3 ? 0.18 : 0;
    }
    this.body.position.y = Math.abs(Math.cos(this.walkT)) * 0.04 * amp;
  }
}

export interface ZWorld {
  level: Level;
  playerPos: THREE.Vector3;
  playerAlive: boolean;
  flashlightOn: boolean;
  los(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean;
  move(p: THREE.Vector3, dx: number, dz: number, r: number, h: number): void;
  damagePlayer(n: number, from: THREE.Vector3): void;
  groan(p: THREE.Vector3, pitch: number, aggressive: boolean): void;
  bang(p: THREE.Vector3): void;
  doorOpen(id: string): void;
  /** Living companions zombies may target (pos + damage callback). */
  victims?: { pos: THREE.Vector3; alive: boolean; hurt(n: number): void }[];
}

type State = "wander" | "chase" | "investigate" | "attack" | "dead" | "idle";

export class Zombie extends Humanoid {
  id: string;
  pos: THREE.Vector3;
  vy = 0;
  yaw = 0;
  hp: number;
  maxHp: number;
  state: State = "wander";
  speed: number;
  target = new THREE.Vector3();
  lastKnown = new THREE.Vector3();
  path: number[] = [];
  pathT = 0;
  senseT = Math.random() * 0.3;
  lostT = 0;
  attackT = 0;
  attackHit = false;
  groanT = 2 + Math.random() * 6;
  hitFlash = 0;
  deadT = 0;
  stuckT = 0;
  lastPos = new THREE.Vector3();
  pitch: number;
  wanderNode = -1;
  hasLos = false;
  victim: { pos: THREE.Vector3; alive: boolean; hurt(n: number): void } | null = null;

  constructor(id: string, look: Look, pos: THREE.Vector3, runner = false, human = false) {
    super(look, !human);
    this.id = id;
    this.pos = pos.clone();
    this.maxHp = this.hp = 100 * look.scale;
    this.speed = runner ? 3.6 : 2.2 + Math.random() * 0.6;
    this.pitch = 0.85 + Math.random() * 0.35;
    this.yaw = Math.random() * Math.PI * 2;
    this.root.position.copy(this.pos);
  }

  get alive() { return this.state !== "dead"; }

  knock(dir: THREE.Vector3, w: ZWorld, amt = 0.5) {
    w.move(this.pos, dir.x * amt, dir.z * amt, 0.3, 1.8);
  }

  hitSpheres(): { x: number; y: number; z: number; r: number; head: boolean }[] {
    const s = this.scale, p = this.pos;
    const fx = Math.sin(this.yaw) * 0.12, fz = Math.cos(this.yaw) * 0.12;
    return [
      { x: p.x + fx, y: p.y + 1.6 * s, z: p.z + fz, r: 0.18 * s, head: true },
      { x: p.x, y: p.y + 1.2 * s, z: p.z, r: 0.3 * s, head: false },
      { x: p.x, y: p.y + 0.8 * s, z: p.z, r: 0.28 * s, head: false },
      { x: p.x, y: p.y + 0.35 * s, z: p.z, r: 0.25 * s, head: false },
    ];
  }

  damage(n: number, w: ZWorld) {
    if (!this.alive) return false;
    this.hp -= n;
    this.hitFlash = 0.15;
    this.head.rotation.x = -0.5;
    if (this.state !== "chase" && this.state !== "attack") {
      this.state = "chase";
      this.lastKnown.copy(w.playerPos);
      w.groan(this.pos, this.pitch, true);
    }
    if (this.hp <= 0) {
      this.state = "dead";
      this.deadT = 0;
      return true;
    }
    return false;
  }

  hear(p: THREE.Vector3, w: ZWorld) {
    if (!this.alive) return;
    this.lastKnown.copy(p);
    if (this.state === "wander" || this.state === "idle" || this.state === "investigate") {
      this.state = "investigate";
      this.path = [];
      this.pathT = 0;
      if (Math.random() < 0.5) w.groan(this.pos, this.pitch, true);
    }
  }

  nearestNode(nav: NavNode[], p: THREE.Vector3, w: ZWorld) {
    const cands = nav.filter((n) => Math.abs(n.y - p.y) < 1.6).map((n) => ({ n, d: (n.x - p.x) ** 2 + (n.z - p.z) ** 2 })).sort((a, b) => a.d - b.d);
    for (let i = 0; i < Math.min(5, cands.length); i++) {
      const n = cands[i].n;
      if (w.los(p.x, p.y + 1, p.z, n.x, n.y + 1, n.z)) return n.id;
    }
    return cands.length ? cands[0].n.id : 0;
  }

  findPath(w: ZWorld, goal: THREE.Vector3) {
    const nav = w.level.nav;
    const a = this.nearestNode(nav, this.pos, w), b = this.nearestNode(nav, goal, w);
    const dist = new Map<number, number>([[a, 0]]);
    const prev = new Map<number, number>();
    const open = [a];
    const doors = w.level.doors;
    while (open.length) {
      open.sort((x, y) => dist.get(x)! - dist.get(y)!);
      const cur = open.shift()!;
      if (cur === b) break;
      const cn = nav[cur];
      for (const e of cn.edges) {
        if (e.door) { const d = doors.find((dd) => dd.id === e.door); if (d && d.locked) continue; }
        const nn = nav[e.to];
        const nd = dist.get(cur)! + Math.hypot(nn.x - cn.x, nn.y - cn.y, nn.z - cn.z);
        if (nd < (dist.get(e.to) ?? Infinity)) { dist.set(e.to, nd); prev.set(e.to, cur); open.push(e.to); }
      }
    }
    const path: number[] = [];
    if (!dist.has(b)) return path;
    let c: number | undefined = b;
    while (c !== undefined) { path.unshift(c); c = prev.get(c); }
    // same nearest node for start and goal but no straight line: route through that node explicitly
    if (path.length === 1 && !w.los(this.pos.x, this.pos.y + 0.5, this.pos.z, goal.x, goal.y + 0.5, goal.z)) return path;
    // drop nodes we've already passed
    while (path.length > 1) {
      const n0 = nav[path[0]], n1 = nav[path[1]];
      const dSelf = Math.hypot(n1.x - this.pos.x, n1.y - this.pos.y, n1.z - this.pos.z);
      const dNode = Math.hypot(n1.x - n0.x, n1.y - n0.y, n1.z - n0.z);
      if (dSelf < dNode) path.shift(); else break;
    }
    return path;
  }

  update(dt: number, w: ZWorld) {
    const lv = w.level;
    if (this.state === "dead") {
      this.deadT += dt;
      const k = Math.min(1, this.deadT / 0.6);
      this.body.rotation.x = -k * Math.PI / 2;
      this.body.position.y = 0.15 * k;
      this.armL.rotation.x = this.armR.rotation.x = -2.6 * k;
      this.legL.rotation.x = this.legR.rotation.x = 0;
      // sink into the ground before despawning (body fades away at 25s)
      if (this.deadT > 20) this.root.position.y = this.pos.y - (this.deadT - 20) * 0.25;
      return;
    }
    if (this.hitFlash > 0) this.hitFlash -= dt;
    this.head.rotation.x += (0 - this.head.rotation.x) * Math.min(1, dt * 5);

    const pp = w.playerPos;
    const dx = pp.x - this.pos.x, dz = pp.z - this.pos.z, dy = pp.y - this.pos.y;
    const distP = Math.hypot(dx, dz);

    // perception
    this.senseT -= dt;
    if (this.senseT <= 0 && w.playerAlive) {
      this.senseT = 0.25;
      this.hasLos = false;
      if (distP < 22 && Math.abs(dy) < 2.2) {
        const fwd = Math.sin(this.yaw) * dx + Math.cos(this.yaw) * dz;
        const range = w.flashlightOn ? 20 : 13;
        const canSee = (distP < 4.5) || (fwd / Math.max(distP, 0.01) > 0.2 && distP < range);
        if (canSee && w.los(this.pos.x, this.pos.y + 1.5, this.pos.z, pp.x, pp.y + 1.5, pp.z)) {
          this.hasLos = true;
          if (this.state !== "chase" && this.state !== "attack") {
            w.groan(this.pos, this.pitch, true);
            this.path = [];
          }
          if (this.state !== "attack") this.state = "chase";
          this.lastKnown.copy(pp);
          this.lostT = 0;
        }
      }
    }
    if (!w.playerAlive && (this.state === "chase" || this.state === "attack")) this.state = "wander";

    this.groanT -= dt;
    if (this.groanT <= 0) {
      this.groanT = (this.state === "chase" ? 2.5 : 5) + Math.random() * 6;
      if (distP < 25) w.groan(this.pos, this.pitch, this.state === "chase");
    }

    let moveSpeed = 0;
    let goal: THREE.Vector3 | null = null;

    // any living companion within reach gets bitten regardless of state
    if (this.state !== "attack" && w.victims) {
      for (const v of w.victims) {
        if (!v.alive || Math.abs(v.pos.y - this.pos.y) > 1) continue;
        if (Math.hypot(v.pos.x - this.pos.x, v.pos.z - this.pos.z) < 1.35) {
          this.victim = v; this.state = "attack"; this.attackT = 0; this.attackHit = false;
          this.lastKnown.copy(v.pos);
          break;
        }
      }
    }

    if (this.state === "attack") {
      this.attackT += dt;
      const k = this.attackT / 0.9;
      this.armL.rotation.x = this.armR.rotation.x = -1.4 - Math.sin(k * Math.PI) * 0.9;
      this.body.rotation.x = 0.1 + Math.sin(k * Math.PI) * 0.25;
      if (this.victim) this.yaw = lerpAngle(this.yaw, Math.atan2(this.victim.pos.x - this.pos.x, this.victim.pos.z - this.pos.z), dt * 8);
      else this.yaw = lerpAngle(this.yaw, Math.atan2(dx, dz), dt * 8);
      if (k > 0.5 && !this.attackHit) {
        this.attackHit = true;
        if (this.victim) { if (this.victim.alive && this.victim.pos.distanceTo(this.pos) < 1.7) this.victim.hurt(10 + Math.random() * 6); }
        else if (distP < 1.6 && Math.abs(dy) < 1.2) w.damagePlayer(10 + Math.random() * 6, this.pos);
      }
      if (k >= 1) { this.state = "chase"; this.attackT = 0; }
    } else if (this.state === "chase") {
      if (!this.hasLos) this.lostT += dt;
      if (this.lostT > 8) { this.state = "investigate"; }
      // companions: if one is right next to us (closer than the player), bite it instead
      this.victim = null;
      let vBest = 1.35;
      if (w.victims) for (const v of w.victims) {
        if (!v.alive || Math.abs(v.pos.y - this.pos.y) > 1) continue;
        const dv = Math.hypot(v.pos.x - this.pos.x, v.pos.z - this.pos.z);
        if (dv < vBest && dv < distP) { vBest = dv; this.victim = v; }
      }
      if (this.victim) {
        this.state = "attack"; this.attackT = 0; this.attackHit = false;
        const vv = this.victim;
        this.yaw = lerpAngle(this.yaw, Math.atan2(vv.pos.x - this.pos.x, vv.pos.z - this.pos.z), 1);
      } else if (distP < 1.25 && Math.abs(dy) < 1 && this.hasLos) {
        this.state = "attack"; this.attackT = 0; this.attackHit = false;
      } else if (this.hasLos && Math.abs(dy) < 1.0) {
        goal = pp;
        this.path = [];
      } else {
        goal = this.followPath(dt, w, this.lastKnown);
      }
      moveSpeed = this.speed;
    } else if (this.state === "investigate") {
      const d = Math.hypot(this.lastKnown.x - this.pos.x, this.lastKnown.z - this.pos.z);
      if (d < 1.2 && Math.abs(this.lastKnown.y - this.pos.y) < 1.5) { this.state = "wander"; this.path = []; }
      else goal = this.followPath(dt, w, this.lastKnown);
      moveSpeed = this.speed * 0.75;
    } else if (this.state === "wander") {
      if (this.wanderNode < 0 || Math.hypot(lv.nav[this.wanderNode].x - this.pos.x, lv.nav[this.wanderNode].z - this.pos.z) < 0.8) {
        const cur = this.wanderNode >= 0 ? this.wanderNode : this.nearestNode(lv.nav, this.pos, w);
        const edges = lv.nav[cur].edges.filter((e) => !e.door || !lv.doors.find((d) => d.id === e.door)?.locked);
        if (Math.random() < 0.3) { this.state = "idle"; this.pathT = 2 + Math.random() * 4; }
        this.wanderNode = edges.length ? edges[Math.floor(Math.random() * edges.length)].to : cur;
      }
      const n = lv.nav[this.wanderNode];
      goal = this.tmp.set(n.x, n.y, n.z);
      moveSpeed = 0.9;
    } else if (this.state === "idle") {
      this.pathT -= dt;
      if (this.pathT <= 0) this.state = "wander";
    }

    if (goal && moveSpeed > 0) {
      const gx = goal.x - this.pos.x, gz = goal.z - this.pos.z;
      const gd = Math.hypot(gx, gz);
      if (gd > 0.05) {
        const want = Math.atan2(gx, gz);
        this.yaw = lerpAngle(this.yaw, want, dt * 5);
        const step = Math.min(gd, moveSpeed * dt);
        const ox = this.pos.x, oz = this.pos.z;
        w.move(this.pos, (gx / gd) * step, (gz / gd) * step, 0.3, 1.8);
        const moved = Math.hypot(this.pos.x - ox, this.pos.z - oz);
        // door forcing
        if (moved < step * 0.3) {
          for (const d of lv.doors) {
            if (d.open || d.locked) continue;
            if (Math.abs(d.y - this.pos.y) < 1 && Math.hypot(d.x - this.pos.x, d.z - this.pos.z) < 1.6) {
              const prevT = d.forceT;
              d.forceT += dt;
              if (Math.floor(prevT / 0.7) !== Math.floor(d.forceT / 0.7)) w.bang(this.pos);
              if (d.forceT > 2.4) { d.forceT = 0; w.doorOpen(d.id); }
            }
          }
          this.stuckT += dt;
          if (this.stuckT > 2.5) { this.stuckT = 0; this.path = []; this.wanderNode = -1; if (this.state === "wander") this.wanderNode = -1; }
        } else this.stuckT = 0;
      }
      this.animWalk(dt, moveSpeed, true);
    } else if (this.state !== "attack") {
      this.animWalk(dt * 0.2, 0.3, true);
    }

    // gravity / ground
    const g = lv.groundAt(this.pos.x, this.pos.z, this.pos.y);
    if (this.pos.y > g + 0.01) { this.vy -= 20 * dt; this.pos.y = Math.max(g, this.pos.y + this.vy * dt); }
    else { this.pos.y = g; this.vy = 0; }

    this.root.position.copy(this.pos);
    this.root.rotation.y = this.yaw;
  }

  tmp = new THREE.Vector3();

  pathGoal = new THREE.Vector3(1e9, 0, 0);
  pathFailed = false;

  followPath(dt: number, w: ZWorld, goal: THREE.Vector3, strict = false): THREE.Vector3 {
    this.pathT -= dt;
    // direct only if genuinely visible, close and on the same level
    if (!strict && Math.abs(goal.y - this.pos.y) < 1 && Math.hypot(goal.x - this.pos.x, goal.z - this.pos.z) < 3) return goal;
    if (strict && Math.abs(goal.y - this.pos.y) < 1 && Math.hypot(goal.x - this.pos.x, goal.z - this.pos.z) < 2.5 && w.los(this.pos.x, this.pos.y + 0.5, this.pos.z, goal.x, goal.y + 0.5, goal.z)) return goal;
    const goalMoved = this.pathGoal.distanceToSquared(goal) > 2.25;
    if (this.pathT <= 0 || !this.path.length || goalMoved) {
      this.pathT = strict ? 0.8 : 1.2;
      this.pathGoal.copy(goal);
      this.path = this.findPath(w, goal);
      this.pathFailed = this.path.length === 0;
    }
    const nav = w.level.nav;
    while (this.path.length) {
      const n = nav[this.path[0]];
      if (Math.hypot(n.x - this.pos.x, n.z - this.pos.z) < 0.7 && Math.abs(n.y - this.pos.y) < 1.5) this.path.shift();
      else break;
    }
    if (!this.path.length) return goal;
    // skip ahead if next node visible — but never skip a door node (the edge between them is a doorway)
    if (this.path.length > 1) {
      const n1 = nav[this.path[0]], n2 = nav[this.path[1]];
      const isDoorEdge = n1.edges.some((e) => e.to === n2.id && e.door);
      if (!isDoorEdge && Math.abs(n2.y - this.pos.y) < 0.6 && w.los(this.pos.x, this.pos.y + 0.5, this.pos.z, n2.x, n2.y + 0.5, n2.z)) this.path.shift();
    }
    const n = nav[this.path[0]];
    // approaching a doorway: line up with the door axis before pushing through
    if (strict && this.path.length > 1) {
      const n2 = nav[this.path[1]];
      const e = n.edges.find((ed) => ed.to === n2.id && ed.door);
      if (e) {
        const lateral = Math.abs(n.x - this.pos.x);
        if (lateral > 0.35 && Math.abs(n.z - this.pos.z) < 1.6) return this.tmp.set(n.x, n.y, this.pos.z);
      }
    }
    return this.tmp.set(n.x, n.y, n.z);
  }
}

export function lerpAngle(a: number, b: number, t: number) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * Math.min(1, t);
}
