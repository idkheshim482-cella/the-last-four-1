import { useState } from "react";
import type { Engine } from "../game/engine";
import { ROOMS } from "../game/level";
import { MAP_ROADS, MAP_BLOCKS, GAS_STATION, PHARMACY, GUNSTORE, MINIMART, GARAGE, HIDEOUT, HARBOR } from "../game/city";

const Lbl = ({ x, y, t, c = "#ddd", s = 5.5 }: { x: number; y: number; t: string; c?: string; s?: number }) => (
  <text x={x} y={y} textAnchor="middle" fontSize={s} fill={c} style={{ paintOrder: "stroke", stroke: "#000", strokeWidth: 1.6 }}>{t}</text>
);

function Player({ x, z, yaw, scale = 1 }: { x: number; z: number; yaw: number; scale?: number }) {
  const rot = (Math.atan2(-Math.cos(yaw), -Math.sin(yaw)) * 180) / Math.PI + 90;
  return (
    <g transform={`translate(${x},${z}) rotate(${rot}) scale(${scale})`}>
      <polygon points="0,-6 4,5 0,2.5 -4,5" fill="#ff4040" stroke="#fff" strokeWidth={0.8} />
    </g>
  );
}

function SchoolMap({ engine }: { engine: Engine }) {
  const px = engine.pos.x, pz = engine.pos.z;
  const curFloor = engine.pos.y > 7 ? 2 : engine.pos.y > 3 ? 1 : 0;
  const [floor, setFloor] = useState(curFloor);
  const wp = engine.waypointTarget();
  const wpFloor = wp ? (wp.y > 7 ? 2 : wp.y > 3 ? 1 : 0) : -1;
  const visited = engine.visitedRooms;
  const rooms = ROOMS.filter((r) => r.floor === floor);
  const fl = ["GROUND FLOOR", "2ND FLOOR", "ROOFTOP"];
  return (
    <>
      <div className="mb-1 flex items-center justify-between px-2">
        <div className="text-[10px] tracking-widest text-white/50">RIVERSIDE HIGH SCHOOL — {fl[floor]}{floor === curFloor ? " (YOU ARE HERE)" : ""}</div>
        <div className="flex gap-1">
          {[0, 1, 2].map((f) => (
            <button key={f} onClick={() => setFloor(f)} className={`rounded px-2 py-0.5 text-[10px] font-bold ${floor === f ? "bg-amber-600 text-white" : "bg-white/10 text-white/60"}`}>{["G", "2", "R"][f]}</button>
          ))}
        </div>
      </div>
      <svg viewBox="-34 -16 68 32" className="h-auto w-full rounded bg-[#1b1d17]" style={{ maxHeight: "60vh" }}>
        {/* outline */}
        <rect x={-30} y={-12} width={60} height={24} fill="#22241f" stroke="#55574f" strokeWidth={0.3} />
        {floor < 2 && (
          <>
            {/* corridor */}
            <rect x={-30} y={-2} width={48} height={4} fill={visited.has("corridor" + floor) ? "#3a3c38" : "#2a2b28"} />
            <Lbl x={-6} y={0.8} t="CORRIDOR" c="#9a9c90" s={2.4} />
            {/* lobby + stairs */}
            <rect x={18} y={-12} width={12} height={24} fill={visited.has("lobby") ? "#3a3426" : "#2a2824"} stroke="#55574f" strokeWidth={0.2} />
            <Lbl x={24} y={0.8} t={visited.has("lobby") ? "LOBBY" : "?"} c="#9a9c90" s={2.4} />
            <rect x={10} y={2} width={8} height={10} fill="#2f3340" stroke="#55574f" strokeWidth={0.2} />
            <Lbl x={14} y={7.5} t="STAIRS" c="#9ab" s={2.2} />
            {floor === 0 && <rect x={29.2} y={-1.8} width={0.8} height={3.6} fill={engine.stage >= 3 ? "#4a4" : "#a33"} />}
            {rooms.map((r) => {
              const seen = visited.has(r.id);
              const z0 = r.side === "N" ? 2 : -12;
              const locked = engine.level.doors.find((d) => d.id === r.id)?.locked;
              return (
                <g key={r.id}>
                  <rect x={r.x0} y={z0} width={r.x1 - r.x0} height={10} fill={seen ? (r.id === "office" ? "#3a4a2a" : "#2e3330") : "#232523"} stroke={locked ? "#a33" : "#55574f"} strokeWidth={locked ? 0.4 : 0.2} />
                  <Lbl x={(r.x0 + r.x1) / 2} y={z0 + 5.8} t={seen ? r.name : "?"} c={seen ? "#cfd0c4" : "#555"} s={seen ? 1.9 : 2.2} />
                  {locked && seen && <Lbl x={(r.x0 + r.x1) / 2} y={z0 + 8.4} t="🔒" s={2.2} />}
                  <rect x={r.door - 0.7} y={r.side === "N" ? 1.8 : -2.2} width={1.4} height={0.4} fill={locked ? "#a33" : "#8a7"} />
                </g>
              );
            })}
            {floor === 1 && <Lbl x={-12} y={-7} t="📻" s={3} />}
          </>
        )}
        {floor === 2 && (
          <>
            <rect x={-30} y={-12} width={60} height={24} fill={visited.has("roof") ? "#2f3330" : "#232523"} />
            <rect x={14} y={2} width={4} height={9} fill="#2f3340" stroke="#55574f" strokeWidth={0.2} />
            <Lbl x={-8} y={1} t="H" c="#8a7a2a" s={6} />
            <Lbl x={0} y={8} t={visited.has("roof") ? "ROOF TERRACE — HELIPAD" : "?"} c="#9a9c90" s={2.4} />
          </>
        )}
        {/* objective */}
        {wp && wpFloor === floor && (
          <g transform={`translate(${wp.x},${wp.z})`}>
            <circle r={2.2} fill="none" stroke="#ffd23a" strokeWidth={0.5}><animate attributeName="r" values="1.5;3;1.5" dur="1.6s" repeatCount="indefinite" /></circle>
            <Lbl x={0} y={-3} t={wp.label} c="#ffd23a" s={2.2} />
          </g>
        )}
        {wp && wpFloor !== floor && <Lbl x={0} y={-13.5} t={`OBJECTIVE: ${wp.label} — ${["GROUND", "2ND FLOOR", "ROOF"][wpFloor]}`} c="#ffd23a" s={2.2} />}
        {/* companions */}
        {floor === curFloor && engine.companions.map((c) => (
          <g key={c.def.id} transform={`translate(${c.pos.x},${c.pos.z})`}>
            <circle r={0.9} fill={c.alive ? "#4ad" : "#888"} stroke="#fff" strokeWidth={0.25} />
            <Lbl x={0} y={-1.6} t={c.def.name[0]} c="#bdf" s={1.8} />
          </g>
        ))}
        {floor === curFloor && <Player x={px} z={pz} yaw={engine.yaw} scale={0.35} />}
      </svg>
      <div className="mt-1 px-2 text-[10px] text-white/50">Grey rooms with "?" are undiscovered. Red doors are locked. Blue dots: your squad (N, M, H).</div>
    </>
  );
}

function CityMap({ engine }: { engine: Engine }) {
  const px = engine.pos.x, pz = engine.pos.z;
  const wp = engine.waypointTarget();
  const M = (x: number, z: number, icon: string, label: string, color: string) => (
    <g key={label} transform={`translate(${x},${z})`}>
      <text x={0} y={2} textAnchor="middle" fontSize={11} fill={color} style={{ paintOrder: "stroke", stroke: "#000", strokeWidth: 2.5 }}>{icon}</text>
      <Lbl x={0} y={12} t={label} />
    </g>
  );
  return (
    <>
      <div className="mb-1 px-2 text-[10px] tracking-widest text-white/50">RIVERSIDE CITY — MINA'S FATHER'S MAP</div>
      <svg viewBox="-50 -130 400 250" className="h-auto w-full rounded bg-[#1b1d17]" style={{ maxHeight: "60vh" }}>
        <rect x={300} y={-130} width={100} height={250} fill="#11202e" />
        {MAP_ROADS.map((r, i) => <rect key={i} x={r.x0} y={r.z0} width={r.x1 - r.x0} height={r.z1 - r.z0} fill="#3a3c38" stroke="#55574f" strokeWidth={0.6} />)}
        {MAP_BLOCKS.map((b, i) => (
          <g key={i}>
            <rect x={b.x0} y={b.z0} width={b.x1 - b.x0} height={b.z1 - b.z0} fill={b.label === "SCHOOL" ? "#3a2f2a" : b.label === "HARBOR" ? "#28323a" : "#2a2c26"} stroke="#4a4c44" strokeWidth={0.6} />
            {b.label && <text x={(b.x0 + b.x1) / 2} y={(b.z0 + b.z1) / 2 + 2} textAnchor="middle" fontSize={6} fill="#9a9c90">{b.label}</text>}
          </g>
        ))}
        {M(GAS_STATION.x, GAS_STATION.z, "⛽", "FUEL-N-GO", "#e0a030")}
        {M(PHARMACY.x, PHARMACY.z, "✚", "PHARMACY", "#50d080")}
        {M(GUNSTORE.x, GUNSTORE.z, "⌖", "GUN STORE", "#d0a050")}
        {M(MINIMART.x, MINIMART.z, "🛒", "MINIMART", "#80b0e0")}
        {M(GARAGE.x, GARAGE.z, "🔧", "RAVI'S GARAGE", "#60a0e0")}
        {M(HIDEOUT.x, HIDEOUT.z + 8, "⌂", "HIDEOUT", "#60e080")}
        {M(HARBOR.x - 18, HARBOR.z, "⚓", "EVAC ZONE", "#e05050")}
        {wp && (
          <g transform={`translate(${wp.x},${wp.z})`}>
            <circle r={6} fill="none" stroke="#ffd23a" strokeWidth={1.4}><animate attributeName="r" values="4;8;4" dur="1.6s" repeatCount="indefinite" /></circle>
            <Lbl x={0} y={-8} t={wp.label} c="#ffd23a" s={6} />
          </g>
        )}
        {engine.companions.map((c) => <circle key={c.def.id} cx={c.pos.x} cy={c.pos.z} r={2.2} fill={c.alive ? "#4ad" : "#888"} stroke="#fff" strokeWidth={0.6} />)}
        <Player x={px} z={pz} yaw={engine.yaw} />
        <Lbl x={px} y={pz + 13} t="AKHIL" c="#ff8080" s={6} />
      </svg>
      <div className="mt-1 px-2 text-[10px] text-white/50">The yellow ring is your current objective. Blue dots are your squad.</div>
    </>
  );
}

export default function MapView({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const inSchool = Math.abs(engine.pos.x) < 31 && Math.abs(engine.pos.z) < 13;
  const hasCity = engine.keys.includes("city_map");
  const [tab, setTab] = useState<"school" | "city">(inSchool || !hasCity ? "school" : "city");
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/80 p-3" onClick={onClose}>
      <div className="lf-in relative w-full max-w-3xl rounded border-2 border-amber-900/60 bg-[#141510] p-2 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-1 flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div className="text-xs font-bold tracking-[0.3em] text-amber-200">MAP</div>
            <button onClick={() => setTab("school")} className={`rounded px-2 py-0.5 text-[10px] font-bold ${tab === "school" ? "bg-amber-700 text-white" : "bg-white/10 text-white/60"}`}>SCHOOL</button>
            <button onClick={() => hasCity && setTab("city")} className={`rounded px-2 py-0.5 text-[10px] font-bold ${tab === "city" ? "bg-amber-700 text-white" : hasCity ? "bg-white/10 text-white/60" : "bg-white/5 text-white/25"}`}>{hasCity ? "CITY" : "CITY 🔒"}</button>
          </div>
          <button onClick={onClose} className="rounded border border-white/30 bg-black/50 px-3 py-1 text-xs font-bold">CLOSE [M]</button>
        </div>
        {tab === "school" ? <SchoolMap engine={engine} /> : <CityMap engine={engine} />}
        {!hasCity && engine.stage >= 3 && <div className="mt-1 px-2 text-[10px] text-amber-300/70">Mina has a map of the city. Help her first.</div>}
      </div>
    </div>
  );
}
