// LAST FOUR — graphics presets.
// Every preset genuinely changes: shadow resolution, light budget, post-processing chain,
// particle density, vegetation density, texture size and pixel ratio.

export interface GfxPreset {
  id: number;
  name: string;
  desc: string;
  pixelRatio: number;       // device pixel ratio cap
  shadows: boolean;
  shadowMap: number;        // shadow map resolution
  shadowDistance: number;   // metres
  softShadows: boolean;
  lightBudget: number;      // dynamic lights allowed
  ambientOcclusion: boolean;
  bloom: boolean;
  bloomStrength: number;
  smaa: boolean;
  fogDensity: number;
  particleScale: number;    // 0..1 multiplier on particle counts
  vegetation: number;       // 0..1 multiplier on plant counts
  textureSize: 128 | 256 | 512;
  anisotropy: number;
  vegetationWind: boolean;
  godRays: boolean;
  detailProps: number;     // 0..1 multiplier on scatter props
}

export const PRESETS: GfxPreset[] = [
  {
    id: 0, name: "LOW", desc: "Fastest. No shadows or post-processing — for older phones.",
    pixelRatio: 0.7, shadows: false, shadowMap: 512, shadowDistance: 22, softShadows: false,
    lightBudget: 4, ambientOcclusion: false, bloom: false, bloomStrength: 0, smaa: false,
    fogDensity: 1.0, particleScale: 0.25, vegetation: 0.35, textureSize: 128, anisotropy: 1,
    vegetationWind: false, godRays: false, detailProps: 0.3,
  },
  {
    id: 1, name: "MEDIUM", desc: "Balanced. Hard shadows, gentle bloom, reduced detail.",
    pixelRatio: 1.0, shadows: true, shadowMap: 1024, shadowDistance: 34, softShadows: false,
    lightBudget: 8, ambientOcclusion: false, bloom: true, bloomStrength: 0.22, smaa: false,
    fogDensity: 0.85, particleScale: 0.6, vegetation: 0.7, textureSize: 256, anisotropy: 2,
    vegetationWind: true, godRays: false, detailProps: 0.65,
  },
  {
    id: 2, name: "HIGH", desc: "Cinematic. Soft shadows, ambient occlusion, full atmosphere.",
    pixelRatio: 1.4, shadows: true, shadowMap: 2048, shadowDistance: 48, softShadows: true,
    lightBudget: 14, ambientOcclusion: true, bloom: true, bloomStrength: 0.34, smaa: true,
    fogDensity: 0.7, particleScale: 1, vegetation: 1, textureSize: 256, anisotropy: 4,
    vegetationWind: true, godRays: true, detailProps: 1,
  },
  {
    id: 3, name: "ULTRA", desc: "Maximum. Full resolution, deep shadows, heavy atmosphere.",
    pixelRatio: 2.0, shadows: true, shadowMap: 4096, shadowDistance: 64, softShadows: true,
    lightBudget: 24, ambientOcclusion: true, bloom: true, bloomStrength: 0.42, smaa: true,
    fogDensity: 0.55, particleScale: 1.5, vegetation: 1.45, textureSize: 512, anisotropy: 8,
    vegetationWind: true, godRays: true, detailProps: 1.35,
  },
];

/** Guess a sensible starting preset from the device. */
export function autoPreset(): number {
  try {
    const mem = (navigator as any).deviceMemory as number | undefined;
    const cores = navigator.hardwareConcurrency || 2;
    const dpr = window.devicePixelRatio || 1;
    const touch = "ontouchstart" in window;
    if (mem && mem <= 2) return 0;
    if (touch && cores <= 4) return 0;
    if (touch && cores <= 6) return 1;
    if (cores >= 8 && dpr <= 2) return 2;
    return 1;
  } catch {
    return 1;
  }
}
