// Procedural WebAudio sound engine — no external assets needed.
export class Audio {
  ctx: AudioContext | null = null;
  master!: GainNode;
  sfx!: GainNode;
  ambient!: GainNode;
  noiseBuf!: AudioBuffer;
  volume = 0.8;
  voiceEnabled = true;
  private heliNodes: { srcs: AudioScheduledSourceNode[]; gain: GainNode } | null = null;
  private alarmNodes: { osc: OscillatorNode; gain: GainNode; timer: number } | null = null;
  private staticNode: { src: AudioBufferSourceNode; gain: GainNode } | null = null;
  private ambientStarted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(this.ctx.destination);
    this.sfx = this.ctx.createGain();
    this.sfx.connect(this.master);
    this.ambient = this.ctx.createGain();
    this.ambient.gain.value = 0.5;
    this.ambient.connect(this.master);
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.ctx) this.master.gain.value = v;
  }

  setListener(x: number, y: number, z: number, fx: number, fz: number) {
    if (!this.ctx) return;
    const l = this.ctx.listener as any;
    if (l.positionX) {
      const t = this.ctx.currentTime;
      l.positionX.setValueAtTime(x, t);
      l.positionY.setValueAtTime(y, t);
      l.positionZ.setValueAtTime(z, t);
      l.forwardX.setValueAtTime(fx, t);
      l.forwardY.setValueAtTime(0, t);
      l.forwardZ.setValueAtTime(fz, t);
      l.upX.setValueAtTime(0, t);
      l.upY.setValueAtTime(1, t);
      l.upZ.setValueAtTime(0, t);
    } else {
      l.setPosition(x, y, z);
      l.setOrientation(fx, 0, fz, 0, 1, 0);
    }
  }

  private out(pos?: { x: number; y: number; z: number }): AudioNode {
    if (!pos || !this.ctx) return this.sfx;
    const p = this.ctx.createPanner();
    p.panningModel = "equalpower";
    p.distanceModel = "inverse";
    p.refDistance = 2;
    p.maxDistance = 60;
    p.rolloffFactor = 1.3;
    p.positionX.value = pos.x;
    p.positionY.value = pos.y;
    p.positionZ.value = pos.z;
    p.connect(this.sfx);
    return p;
  }

  private noise(dur: number, freq: number, type: BiquadFilterType, vol: number, dest: AudioNode, q = 1, delay = 0, freqEnd?: number) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(dest);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, delay = 0, freqEnd?: number) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  gunshot(kind: "pistol" | "shotgun" | "rifle") {
    if (!this.ctx) return;
    const d = this.sfx;
    if (kind === "pistol") {
      this.noise(0.25, 3000, "lowpass", 0.9, d, 0.7, 0, 400);
      this.tone(160, 0.12, "sine", 0.8, d, 0, 50);
      this.noise(0.6, 900, "bandpass", 0.12, d, 0.5, 0.05);
    } else if (kind === "shotgun") {
      this.noise(0.5, 2200, "lowpass", 1.2, d, 0.6, 0, 200);
      this.tone(90, 0.25, "sine", 1.0, d, 0, 35);
      this.noise(1.0, 600, "bandpass", 0.2, d, 0.4, 0.06);
      this.noise(0.08, 1800, "bandpass", 0.3, d, 3, 0.45); // pump
      this.noise(0.08, 1400, "bandpass", 0.3, d, 3, 0.6);
    } else {
      this.noise(0.18, 4000, "lowpass", 0.8, d, 0.8, 0, 500);
      this.tone(130, 0.1, "square", 0.25, d, 0, 50);
      this.noise(0.4, 1000, "bandpass", 0.1, d, 0.5, 0.04);
    }
  }

  /** Positional, quieter gunshot for companions. */
  gunshotAt(kind: "pistol" | "shotgun" | "rifle", pos: { x: number; y: number; z: number }) {
    if (!this.ctx) return;
    const o = this.out(pos);
    if (kind === "shotgun") { this.noise(0.4, 2000, "lowpass", 0.7, o, 0.6, 0, 200); this.tone(90, 0.2, "sine", 0.5, o, 0, 35); }
    else if (kind === "rifle") { this.noise(0.15, 3800, "lowpass", 0.45, o, 0.8, 0, 500); this.tone(130, 0.08, "square", 0.12, o, 0, 50); }
    else { this.noise(0.22, 3000, "lowpass", 0.5, o, 0.7, 0, 400); this.tone(160, 0.1, "sine", 0.4, o, 0, 50); }
  }

  click() {
    if (!this.ctx) return;
    this.noise(0.04, 3000, "highpass", 0.4, this.sfx, 2);
  }

  reload(kind: string) {
    if (!this.ctx) return;
    const d = this.sfx;
    if (kind === "shotgun") {
      for (let i = 0; i < 3; i++) this.noise(0.07, 1600, "bandpass", 0.35, d, 4, 0.2 + i * 0.35);
      this.noise(0.1, 1200, "bandpass", 0.4, d, 3, 1.3);
    } else {
      this.noise(0.06, 2000, "bandpass", 0.4, d, 4, 0.15);
      this.noise(0.08, 1500, "bandpass", 0.5, d, 3, 0.7);
      this.noise(0.05, 2500, "bandpass", 0.5, d, 4, kind === "rifle" ? 1.4 : 1.0);
    }
  }

  footstep(run: boolean) {
    if (!this.ctx) return;
    this.noise(0.09, run ? 500 : 380, "lowpass", run ? 0.35 : 0.22, this.sfx, 1);
    this.noise(0.05, 2500, "bandpass", 0.04, this.sfx, 1);
  }

  land() {
    if (!this.ctx) return;
    this.noise(0.15, 300, "lowpass", 0.5, this.sfx, 1);
  }

  pickup() {
    if (!this.ctx) return;
    this.tone(660, 0.1, "triangle", 0.2, this.sfx);
    this.tone(990, 0.15, "triangle", 0.2, this.sfx, 0.08);
  }

  unlock() {
    if (!this.ctx) return;
    this.noise(0.08, 2500, "bandpass", 0.5, this.sfx, 5);
    this.noise(0.1, 1800, "bandpass", 0.5, this.sfx, 5, 0.15);
  }

  door(pos: { x: number; y: number; z: number }) {
    if (!this.ctx) return;
    const o = this.out(pos);
    this.tone(180, 0.5, "sawtooth", 0.05, o, 0, 120);
    this.noise(0.2, 400, "lowpass", 0.4, o, 1, 0.35);
  }

  bang(pos: { x: number; y: number; z: number }) {
    if (!this.ctx) return;
    const o = this.out(pos);
    this.noise(0.25, 250, "lowpass", 1.0, o, 1);
    this.tone(70, 0.2, "sine", 0.6, o, 0, 40);
  }

  glass(pos?: { x: number; y: number; z: number }) {
    if (!this.ctx) return;
    const o = this.out(pos);
    this.noise(0.6, 5000, "highpass", 0.8, o, 1);
    for (let i = 0; i < 8; i++) this.tone(2000 + Math.random() * 4000, 0.3, "sine", 0.06, o, Math.random() * 0.4);
  }

  groan(pos: { x: number; y: number; z: number }, pitch = 1, aggressive = false) {
    if (!this.ctx) return;
    const c = this.ctx;
    const o = this.out(pos);
    const t = c.currentTime;
    const dur = aggressive ? 0.7 : 1.2 + Math.random() * 0.8;
    const osc = c.createOscillator();
    osc.type = "sawtooth";
    const base = (aggressive ? 140 : 85 + Math.random() * 30) * pitch;
    osc.frequency.setValueAtTime(base, t);
    osc.frequency.linearRampToValueAtTime(base * (aggressive ? 1.6 : 0.8), t + dur * 0.4);
    osc.frequency.linearRampToValueAtTime(base * 0.7, t + dur);
    const lfo = c.createOscillator();
    lfo.frequency.value = 6 + Math.random() * 10;
    const lg = c.createGain();
    lg.gain.value = base * 0.15;
    lfo.connect(lg).connect(osc.frequency);
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = aggressive ? 900 : 600;
    f.Q.value = 2;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(aggressive ? 0.7 : 0.45, t + 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(f).connect(g).connect(o);
    osc.start(t);
    lfo.start(t);
    osc.stop(t + dur + 0.1);
    lfo.stop(t + dur + 0.1);
    this.noise(dur * 0.8, 1200, "bandpass", aggressive ? 0.25 : 0.12, o, 1.5);
  }

  zombieHit(pos: { x: number; y: number; z: number }) {
    if (!this.ctx) return;
    const o = this.out(pos);
    this.noise(0.12, 700, "lowpass", 0.6, o, 1);
  }

  hurt() {
    if (!this.ctx) return;
    this.tone(220, 0.25, "sawtooth", 0.15, this.sfx, 0, 120);
    this.noise(0.15, 300, "lowpass", 0.6, this.sfx, 1);
  }

  heartbeat() {
    if (!this.ctx) return;
    this.tone(55, 0.15, "sine", 0.6, this.sfx, 0, 40);
    this.tone(50, 0.15, "sine", 0.45, this.sfx, 0.22, 38);
  }

  impact() {
    if (!this.ctx) return;
    this.noise(0.06, 1500, "bandpass", 0.12, this.sfx, 2);
  }

  startAlarm() {
    if (!this.ctx || this.alarmNodes) return;
    const c = this.ctx;
    const osc = c.createOscillator();
    osc.type = "square";
    const g = c.createGain();
    g.gain.value = 0.06;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 2000;
    osc.connect(f).connect(g).connect(this.master);
    osc.start();
    let hi = false;
    const timer = window.setInterval(() => {
      hi = !hi;
      osc.frequency.setValueAtTime(hi ? 960 : 720, c.currentTime);
    }, 380);
    this.alarmNodes = { osc, gain: g, timer };
  }

  stopAlarm() {
    if (!this.alarmNodes || !this.ctx) return;
    clearInterval(this.alarmNodes.timer);
    this.alarmNodes.gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.3);
    const o = this.alarmNodes.osc;
    setTimeout(() => o.stop(), 1500);
    this.alarmNodes = null;
  }

  bell() {
    if (!this.ctx) return;
    for (let i = 0; i < 6; i++) {
      this.tone(1200, 0.3, "triangle", 0.1, this.master, i * 0.35);
      this.tone(1500, 0.3, "triangle", 0.06, this.master, i * 0.35);
    }
  }

  crowd(dur = 3) {
    if (!this.ctx) return;
    // screams: modulated high bandpassed noise + tones
    for (let i = 0; i < 6; i++) {
      const d = Math.random() * dur;
      this.tone(600 + Math.random() * 500, 0.6, "sawtooth", 0.03, this.master, d, 900 + Math.random() * 600);
      this.noise(0.8, 1500 + Math.random() * 1000, "bandpass", 0.12, this.master, 4, d);
    }
  }

  startStatic(vol = 0.25) {
    if (!this.ctx) return;
    if (this.staticNode) {
      this.staticNode.gain.gain.setTargetAtTime(vol, this.ctx.currentTime, 0.1);
      return;
    }
    const c = this.ctx;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 2500;
    f.Q.value = 0.6;
    const g = c.createGain();
    g.gain.value = vol;
    src.connect(f).connect(g).connect(this.master);
    src.start();
    this.staticNode = { src, gain: g };
  }

  setStatic(vol: number) {
    if (this.staticNode && this.ctx) this.staticNode.gain.gain.setTargetAtTime(vol, this.ctx.currentTime, 0.1);
  }

  stopStatic() {
    if (!this.staticNode || !this.ctx) return;
    const s = this.staticNode;
    s.gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
    setTimeout(() => s.src.stop(), 1000);
    this.staticNode = null;
  }

  private engineNodes: { osc: OscillatorNode; osc2: OscillatorNode; gain: GainNode; filter: BiquadFilterNode } | null = null;

  setEngine(kind: "moto" | "car" | "sports" | null, rpm: number) {
    if (!this.ctx) return;
    const c = this.ctx;
    if (!kind) {
      if (this.engineNodes) {
        const e = this.engineNodes;
        e.gain.gain.setTargetAtTime(0, c.currentTime, 0.15);
        setTimeout(() => { try { e.osc.stop(); e.osc2.stop(); } catch { /* ignore */ } }, 800);
        this.engineNodes = null;
      }
      return;
    }
    if (!this.engineNodes) {
      const osc = c.createOscillator();
      osc.type = "sawtooth";
      const osc2 = c.createOscillator();
      osc2.type = "square";
      const filter = c.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 500;
      const gain = c.createGain();
      gain.gain.value = 0;
      osc.connect(filter);
      osc2.connect(filter);
      filter.connect(gain).connect(this.master);
      osc.start();
      osc2.start();
      this.engineNodes = { osc, osc2, gain, filter };
    }
    const e = this.engineNodes;
    const base = kind === "moto" ? 55 : kind === "sports" ? 48 : 38;
    const f = base + rpm * (kind === "moto" ? 160 : kind === "sports" ? 140 : 90);
    e.osc.frequency.setTargetAtTime(f, c.currentTime, 0.08);
    e.osc2.frequency.setTargetAtTime(f * 0.5, c.currentTime, 0.08);
    e.filter.frequency.setTargetAtTime(300 + rpm * 900, c.currentTime, 0.1);
    e.gain.gain.setTargetAtTime(0.035 + rpm * 0.055, c.currentTime, 0.1);
  }

  bikeTick() {
    if (!this.ctx) return;
    this.noise(0.02, 5000, "highpass", 0.06, this.sfx, 2);
  }

  carThud() {
    if (!this.ctx) return;
    this.noise(0.2, 250, "lowpass", 0.8, this.sfx, 1);
    this.tone(60, 0.18, "sine", 0.5, this.sfx, 0, 38);
  }

  boatHorn() {
    if (!this.ctx) return;
    this.tone(110, 1.6, "sawtooth", 0.25, this.master, 0, 105);
    this.tone(165, 1.6, "sawtooth", 0.12, this.master, 0.05, 160);
    this.tone(110, 2.4, "sawtooth", 0.3, this.master, 2.2, 102);
  }

  startHeli(vol = 0.1) {
    if (!this.ctx) return;
    if (this.heliNodes) { this.setHeliVol(vol); return; }
    const c = this.ctx;
    const gain = c.createGain();
    gain.gain.value = 0;
    gain.gain.setTargetAtTime(vol, c.currentTime, 1.2);
    gain.connect(this.master);
    // rotor chop: lowpassed noise amplitude-modulated by a square LFO
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 380;
    const chop = c.createGain();
    chop.gain.value = 0.4;
    const lfo = c.createOscillator();
    lfo.type = "square";
    lfo.frequency.value = 15.5;
    const lfoG = c.createGain();
    lfoG.gain.value = 0.35;
    lfo.connect(lfoG).connect(chop.gain);
    src.connect(lp).connect(chop).connect(gain);
    // turbine whine
    const whine = c.createOscillator();
    whine.type = "sawtooth";
    whine.frequency.value = 620;
    const wf = c.createBiquadFilter();
    wf.type = "bandpass";
    wf.frequency.value = 900;
    wf.Q.value = 3;
    const wg = c.createGain();
    wg.gain.value = 0.05;
    whine.connect(wf).connect(wg).connect(gain);
    // low thump
    const thump = c.createOscillator();
    thump.type = "sine";
    thump.frequency.value = 31;
    const tg = c.createGain();
    tg.gain.value = 0.5;
    const tlg = c.createGain();
    tlg.gain.value = 0.5;
    lfo.connect(tlg).connect(tg.gain);
    thump.connect(tg).connect(gain);
    src.start();
    lfo.start();
    whine.start();
    thump.start();
    this.heliNodes = { srcs: [src, lfo, whine, thump], gain };
  }

  setHeliVol(v: number) {
    if (this.heliNodes && this.ctx) this.heliNodes.gain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.6);
  }

  stopHeli() {
    if (!this.heliNodes || !this.ctx) return;
    const h = this.heliNodes;
    h.gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.8);
    setTimeout(() => h.srcs.forEach((s) => { try { s.stop(); } catch { /* ignore */ } }), 4000);
    this.heliNodes = null;
  }

  radioBeep() {
    if (!this.ctx) return;
    this.tone(1400, 0.08, "sine", 0.2, this.master);
    this.tone(1400, 0.08, "sine", 0.2, this.master, 0.12);
  }

  startAmbient() {
    if (!this.ctx || this.ambientStarted) return;
    this.ambientStarted = true;
    const c = this.ctx;
    // wind/drone
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 280;
    const g = c.createGain();
    g.gain.value = 0.25;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.08;
    const lg = c.createGain();
    lg.gain.value = 0.12;
    lfo.connect(lg).connect(g.gain);
    lfo.start();
    src.connect(f).connect(g).connect(this.ambient);
    src.start();
    const drone = c.createOscillator();
    drone.type = "sine";
    drone.frequency.value = 48;
    const dg = c.createGain();
    dg.gain.value = 0.08;
    drone.connect(dg).connect(this.ambient);
    drone.start();
    // fluorescent hum
    const hum = c.createOscillator();
    hum.type = "sawtooth";
    hum.frequency.value = 100;
    const hf = c.createBiquadFilter();
    hf.type = "lowpass";
    hf.frequency.value = 300;
    const hg = c.createGain();
    hg.gain.value = 0.015;
    hum.connect(hf).connect(hg).connect(this.ambient);
    hum.start();
  }

  distantGroan() {
    if (!this.ctx) return;
    const a = Math.random() * Math.PI * 2;
    this.groan({ x: Math.cos(a) * 30, y: 2, z: Math.sin(a) * 30 }, 0.8);
  }

  speak(text: string, voice: "soldier" | "operator" | "akhil") {
    if (!this.voiceEnabled) return;
    try {
      const ss = window.speechSynthesis;
      if (!ss) return;
      ss.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = voice === "akhil" ? 1.1 : 1.05;
      u.pitch = voice === "soldier" ? 0.6 : voice === "operator" ? 0.9 : 1.0;
      u.volume = Math.min(1, this.volume + 0.1);
      const voices = ss.getVoices().filter((v) => v.lang.startsWith("en"));
      if (voices.length) u.voice = voices[(voice === "operator" ? 1 : 0) % voices.length];
      ss.speak(u);
    } catch {
      /* ignore */
    }
  }

  stopSpeech() {
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* ignore */
    }
  }
}

export const audio = new Audio();
