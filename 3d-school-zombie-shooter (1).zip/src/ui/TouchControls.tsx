import { useRef, useState } from "react";
import type { Engine, UIState } from "../game/engine";

interface Props { engine: Engine; ui: UIState }

function Btn({ label, onDown, onUp, onMove, className = "", active = false }: {
  label: string; onDown: () => void; onUp?: () => void; onMove?: (dx: number, dy: number) => void; className?: string; active?: boolean;
}) {
  const last = useRef<{ x: number; y: number } | null>(null);
  return (
    <div
      className={`absolute flex select-none items-center justify-center rounded-full border-2 text-[11px] font-bold tracking-wider backdrop-blur-sm touch-none ${active ? "border-amber-300 bg-amber-500/40 text-white" : "border-white/30 bg-black/35 text-white/90"} ${className}`}
      onPointerDown={(e) => {
        e.stopPropagation();
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        last.current = { x: e.clientX, y: e.clientY };
        onDown();
      }}
      onPointerMove={(e) => {
        if (!last.current || !onMove) return;
        onMove(e.clientX - last.current.x, e.clientY - last.current.y);
        last.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerUp={() => { last.current = null; onUp?.(); }}
      onPointerCancel={() => { last.current = null; onUp?.(); }}
    >
      {label}
    </div>
  );
}

export default function TouchControls({ engine, ui }: Props) {
  const inp = engine.input;
  const joyId = useRef<number | null>(null);
  const joyOrigin = useRef({ x: 0, y: 0 });
  const [knob, setKnob] = useState<{ ox: number; oy: number; dx: number; dy: number } | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const [adsOn, setAdsOn] = useState(false);
  const R = 55;
  const lookMul = 1.5;

  return (
    <div className="absolute inset-0 z-10 touch-none select-none">
      {/* left: joystick zone */}
      <div
        className="absolute bottom-0 left-0 top-1/4 w-1/2"
        onPointerDown={(e) => {
          if (joyId.current !== null) return;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          joyId.current = e.pointerId;
          joyOrigin.current = { x: e.clientX, y: e.clientY };
          setKnob({ ox: e.clientX, oy: e.clientY, dx: 0, dy: 0 });
        }}
        onPointerMove={(e) => {
          if (e.pointerId !== joyId.current) return;
          let dx = e.clientX - joyOrigin.current.x, dy = e.clientY - joyOrigin.current.y;
          const d = Math.hypot(dx, dy);
          inp.sprint = d > R * 1.35 && dy < -R * 0.8;
          if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
          inp.moveX = dx / R;
          inp.moveY = -dy / R;
          setKnob({ ox: joyOrigin.current.x, oy: joyOrigin.current.y, dx, dy });
        }}
        onPointerUp={(e) => {
          if (e.pointerId !== joyId.current) return;
          joyId.current = null;
          inp.moveX = inp.moveY = 0;
          inp.sprint = false;
          setKnob(null);
        }}
        onPointerCancel={() => { joyId.current = null; inp.moveX = inp.moveY = 0; inp.sprint = false; setKnob(null); }}
      >
        {knob ? (
          <div className="pointer-events-none absolute" style={{ left: knob.ox - R, top: knob.oy - R }}>
            <div className="h-[110px] w-[110px] rounded-full border-2 border-white/30 bg-white/5" />
            <div className="absolute h-12 w-12 rounded-full border-2 border-white/60 bg-white/25" style={{ left: R - 24 + knob.dx, top: R - 24 + knob.dy }} />
            {inp.sprint && <div className="absolute -top-6 left-0 w-[110px] text-center text-[10px] font-bold text-amber-300">SPRINT</div>}
          </div>
        ) : (
          <div className="pointer-events-none absolute bottom-10 left-10 h-[110px] w-[110px] rounded-full border-2 border-dashed border-white/20">
            <div className="flex h-full items-center justify-center text-[10px] text-white/40">MOVE</div>
          </div>
        )}
      </div>
      {/* right: look zone */}
      <div
        className="absolute bottom-0 right-0 top-0 w-1/2"
        onPointerDown={(e) => {
          if (lookId.current !== null) return;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          lookId.current = e.pointerId;
          lookLast.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (e.pointerId !== lookId.current) return;
          inp.lookX += (e.clientX - lookLast.current.x) * lookMul;
          inp.lookY += (e.clientY - lookLast.current.y) * lookMul;
          lookLast.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerUp={(e) => { if (e.pointerId === lookId.current) lookId.current = null; }}
        onPointerCancel={() => { lookId.current = null; }}
      />
      {/* buttons */}
      <Btn label="FIRE" className="bottom-24 right-24 h-20 w-20 border-red-400/60 bg-red-900/40 text-sm" active={inp.fire}
        onDown={() => (inp.fire = true)} onUp={() => (inp.fire = false)}
        onMove={(dx, dy) => { inp.lookX += dx * lookMul; inp.lookY += dy * lookMul; }} />
      <Btn label="FIRE" className="left-6 top-[45%] h-14 w-14 border-red-400/50 bg-red-900/30"
        onDown={() => (inp.fire = true)} onUp={() => (inp.fire = false)} />
      <Btn label="AIM" className="bottom-48 right-6 h-14 w-14" active={adsOn}
        onDown={() => { const v = !adsOn; setAdsOn(v); inp.ads = v; }} />
      <Btn label="JUMP" className="bottom-6 right-6 h-14 w-14" onDown={() => (inp.jump = true)} />
      <Btn label="RELOAD" className="bottom-6 right-24 h-14 w-14" onDown={() => (inp.reload = true)} />
      <Btn label="SWAP" className="bottom-24 right-48 h-12 w-12" onDown={() => (inp.switchW = true)} />
      <Btn label="LIGHT" className="bottom-6 right-44 h-12 w-12" active={ui.flashOn} onDown={() => (inp.flash = true)} />
      {ui.squad.length > 0 && <Btn label="FOLLOW" className="left-6 top-[58%] h-12 w-12 border-sky-400/50 bg-sky-900/30 text-[9px]" onDown={() => (inp.follow = true)} />}
      <Btn label="USE" className={`bottom-48 right-28 h-14 w-14 ${ui.prompt ? "animate-pulse" : "opacity-50"}`} active={!!ui.prompt}
        onDown={() => (inp.interact = true)} />
    </div>
  );
}
