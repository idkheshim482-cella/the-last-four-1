// LAST FOUR — vegetation: instanced, wind-animated, multi-variant.
// One InstancedMesh per part (trunk / foliage) so hundreds of plants cost a handful of draw calls.

import * as THREE from "three";

export interface PlantVariant {
  trunkH: number; trunkR: number; foliage: "round" | "conifer" | "scrub" | "dead";
  foliageH: number; foliageR: number; leaf: number; trunk: number; leaf2: number;
}

export const TREE_VARIANTS: PlantVariant[] = [
  { trunkH: 5.2, trunkR: 0.28, foliage: "round", foliageH: 3.4, foliageR: 2.1, leaf: 0x4a6b34, trunk: 0x4a3a2c, leaf2: 0x5c7d3e },
  { trunkH: 6.4, trunkR: 0.36, foliage: "round", foliageH: 3.0, foliageR: 2.5, leaf: 0x3f5f2e, trunk: 0x40332a, leaf2: 0x51703a },
  { trunkH: 7.8, trunkR: 0.30, foliage: "conifer", foliageH: 6.0, foliageR: 1.7, leaf: 0x334d2c, trunk: 0x3a2f26, leaf2: 0x3f5c33 },
  { trunkH: 5.8, trunkR: 0.32, foliage: "conifer", foliageH: 5.2, foliageR: 1.5, leaf: 0x2f472a, trunk: 0x352c24, leaf2: 0x3a5630 },
  { trunkH: 2.4, trunkR: 0.20, foliage: "scrub", foliageH: 1.4, foliageR: 1.3, leaf: 0x55703a, trunk: 0x4a3f30, leaf2: 0x637d44 },
  { trunkH: 4.6, trunkR: 0.26, foliage: "dead", foliageH: 2.6, foliageR: 1.5, leaf: 0x4a4238, trunk: 0x3d352c, leaf2: 0x554b3f },
];

/** One InstancedMesh holding many copies of a variant. */
export class VegetationField {
  group = new THREE.Group();
  private windTime = 0;
  private movers: { mesh: THREE.InstancedMesh; base: Float32Array; phase: Float32Array }[] = [];

  constructor(quality: number) {
    const detail = quality <= 0 ? 0.55 : quality === 1 ? 0.8 : 1;
    this.detail = detail;
  }
  detail = 1;

  /** Build a field of plants around a region. */
  populate(opts: {
    center: [number, number];
    radius: number;
    count: number;
    groundAt: (x: number, z: number) => number;
    variant?: number[];
    minH?: number;
  }) {
    const { center, radius, count, groundAt } = opts;
    const variantPool = opts.variant ?? TREE_VARIANTS.map((_, i) => i);
    const buckets = new Map<number, number[][]>();
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * radius;
      const x = center[0] + Math.cos(a) * r;
      const z = center[1] + Math.sin(a) * r;
      const y = groundAt(x, z);
      if (y < -5) continue;
      const vi = variantPool[Math.floor(Math.random() * variantPool.length)];
      if (!buckets.has(vi)) buckets.set(vi, []);
      buckets.get(vi)!.push([x, y, z, Math.random() * Math.PI * 2, 0.7 + Math.random() * 0.65]);
    }
    for (const [vi, list] of buckets) {
      const v = TREE_VARIANTS[vi];
      this.addVariant(v, list, groundAt);
    }
  }

  private addVariant(v: PlantVariant, list: number[][], groundAt: (x: number, z: number) => number) {
    const n = list.length;
    if (!n) return;
    const trunkGeo = new THREE.CylinderGeometry(v.trunkR * 0.72, v.trunkR, v.trunkH, 6);
    trunkGeo.translate(0, v.trunkH / 2, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: v.trunk, roughness: 0.95, metalness: 0 });
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, n);
    trunks.castShadow = true;
    trunks.receiveShadow = true;

    let folGeo: THREE.BufferGeometry;
    if (v.foliage === "conifer") {
      folGeo = new THREE.ConeGeometry(v.foliageR, v.foliageH, 7, 3);
      folGeo.translate(0, v.trunkH + v.foliageH * 0.42, 0);
    } else if (v.foliage === "scrub") {
      folGeo = new THREE.IcosahedronGeometry(v.foliageR, 0);
      folGeo.scale(1, 0.72, 1);
      folGeo.translate(0, v.trunkH + v.foliageH * 0.3, 0);
    } else if (v.foliage === "dead") {
      folGeo = new THREE.ConeGeometry(v.foliageR * 0.6, v.foliageH, 5, 1);
      folGeo.translate(0, v.trunkH + v.foliageH * 0.4, 0);
    } else {
      // clustered blobs read as a canopy instead of a single ball
      folGeo = new THREE.IcosahedronGeometry(v.foliageR, 1);
      const pos = folGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const k = 0.82 + ((Math.sin(i * 12.9) * 43758.5) % 1 + 1) % 1 * 0.4;
        pos.setXYZ(i, x * k, y * k * 0.86, z * k);
      }
      folGeo.computeVertexNormals();
      folGeo.translate(0, v.trunkH + v.foliageH * 0.32, 0);
    }
    const folMat = new THREE.MeshStandardMaterial({ color: v.leaf, roughness: 0.88, metalness: 0, flatShading: true });
    const foliage = new THREE.InstancedMesh(folGeo, folMat, n);
    foliage.castShadow = true;
    foliage.receiveShadow = true;

    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const sc = new THREE.Vector3();
    const pos = new THREE.Vector3();
    const bases = new Float32Array(n);
    const phases = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const [x, y, z, rot, s] = list[i];
      e.set(0, rot, 0);
      q.setFromEuler(e);
      sc.set(s, s * (0.9 + Math.random() * 0.25), s);
      pos.set(x, y, z);
      m.compose(pos, q, sc);
      trunks.setMatrixAt(i, m);
      foliage.setMatrixAt(i, m);
      bases[i] = y;
      phases[i] = Math.random() * Math.PI * 2;
    }
    trunks.instanceMatrix.needsUpdate = true;
    foliage.instanceMatrix.needsUpdate = true;
    this.group.add(trunks, foliage);
    this.movers.push({ mesh: foliage, base: bases, phase: phases });
    void groundAt;
  }

  /** Animate the canopy sway. Called once per frame. */
  update(dt: number, windStrength = 1) {
    this.windTime += dt;
    const t = this.windTime;
    for (const mv of this.movers) {
      const mesh = mv.mesh;
      const arr = mesh.instanceMatrix.array as Float32Array;
      // cheap sway: rotate the upper canopy slightly by nudging the matrix (applied on the CPU for a subset)
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion();
      const e = new THREE.Euler();
      const sc = new THREE.Vector3();
      const p = new THREE.Vector3();
      for (let i = 0; i < mv.phase.length; i++) {
        const idx = i * 16;
        m.fromArray(arr, idx);
        m.decompose(p, q, sc);
        const sway = Math.sin(t * 1.15 + mv.phase[i]) * 0.03 * windStrength;
        e.set(sway * 0.6, 0, sway);
        const q2 = new THREE.Quaternion().setFromEuler(e);
        q.multiply(q2);
        m.compose(p, q, sc);
        m.toArray(arr, idx);
      }
      mesh.instanceMatrix.needsUpdate = true;
    }
  }
}
