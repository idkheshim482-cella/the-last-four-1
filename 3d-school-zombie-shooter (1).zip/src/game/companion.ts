import * as THREE from "three";
import { Zombie, type ZWorld, type Look, lerpAngle } from "./zombie";
import type { WeaponId } from "./weapons";
import type { CharId } from "./dialogue";

export interface CompanionDef { id: CharId; name: string; weapon: WeaponId; look: Look; slot: THREE.Vector2 }

export const COMPANION_DEFS: CompanionDef[] = [
  { id: "narendra", name: "NARENDRA", weapon: "rifle", look: { shirt: 0x2a6a3a, pants: 0x2a2a3a, skin: 0xc49a74, hair: 0x1a1410, scale: 1.04 }, slot: new THREE.Vector2(-1.3, 1.8) },
  { id: "mahesh", name: "MAHESH", weapon: "shotgun", look: { shirt: 0x8a2a2a, pants: 0x22262e, skin: 0xa07050, hair: 0x101010, scale: 1.0 }, slot: new THREE.Vector2(1.3, 1.8) },
  { id: "harsha", name: "HARSHA", weapon: "pistol", look: { shirt: 0xd0a030, pants: 0x1e2a50, skin: 0x9a6a48, hair: 0x0c0c0c, scale: 0.96 }, slot: new THREE.Vector2(0, 3.0) },
];

// range = max firing distance from where the companion already stands; they never move to extend it.
const WSTAT: Record<WeaponId, { mag: number; dmg: number; rate: number; reload: number; range: number; burst: number }> = {
  pistol: { mag: 12, dmg: 30, rate: 0.45, reload: 1.4, range: 14, burst: 1 },
  shotgun: { mag: 6, dmg: 70, rate: 1.0, reload: 2.2, range: 9, burst: 1 },
  rifle: { mag: 30, dmg: 24, rate: 0.14, reload: 2.0, range: 16, burst: 3 },
};
// A zombie is only worth shooting if it is this close to Akhil or a companion (threat radius).
const THREAT_R = 11;
export type CState = "FOLLOW" | "DEFEND" | "ATTACK" | "REGROUP" | "RECOVERY" | "HOLD" | "DOWN";

export interface CompanionWorld extends ZWorld {
  playerYaw: number;
  playerMoving: boolean;
  playerInteracting: boolean;
  zombies: Zombie[];
  followOrderT: number; // seconds since Akhil pressed FOLLOW ME (Infinity if never)
  shoot(c: Companion, target: Zombie, hit: boolean): void; // fx + sound + damage are applied by engine
  event(c: Companion, ev: string): void;
}

export class Companion extends Zombie {
  def: CompanionDef;
  gun: THREE.Group;
  mag: number;
  reloadT = 0;
  fireT = 0;
  burstLeft = 0;
  tgt: Zombie | null = null;
  targetLostT = 0;
  chp = 100;
  downT = 0;
  st: CState = "FOLLOW";
  stateT = 0;
  decideT = 0;
  // navigation
  moveGoal = new THREE.Vector3();
  hasGoal = false;
  softGoal = false; // optional goal (e.g. back-away): never triggers stuck-recovery
  progressT = 0;
  lastProg = new THREE.Vector3();
  recoverT = 0;
  recoverDir = new THREE.Vector3();
  recoveries = 0;
  sepT = 0;
  holdT = 0;
  chatT = 15 + Math.random() * 20;
  moveSpeed = 0;
  hurtFlash = 0;
  dbg = "";

  constructor(def: CompanionDef, pos: THREE.Vector3) {
    super("c_" + def.id, def.look, pos, false, true);
    this.def = def;
    this.mag = WSTAT[def.weapon].mag;
    this.speed = 4.4;
    this.state = "idle";
    const g = new THREE.Group();
    const gm = new THREE.MeshLambertMaterial({ color: 0x2a2c30 });
    const wm = new THREE.MeshLambertMaterial({ color: 0x6b4426 });
    const bx = (m: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number) => { const mm = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m); mm.position.set(x, y, z); g.add(mm); };
    if (def.weapon === "pistol") { bx(gm, 0, 0, 0.1, 0.05, 0.06, 0.24); bx(gm, 0, -0.08, 0.0, 0.045, 0.12, 0.06); }
    else if (def.weapon === "shotgun") { bx(gm, 0, 0.02, 0.3, 0.05, 0.05, 0.7); bx(wm, 0, 0, 0.15, 0.07, 0.07, 0.2); bx(wm, 0, -0.03, -0.18, 0.06, 0.1, 0.28); }
    else { bx(gm, 0, 0.02, 0.28, 0.06, 0.08, 0.62); bx(gm, 0, -0.1, 0.12, 0.05, 0.14, 0.07); bx(gm, 0, -0.02, -0.18, 0.06, 0.1, 0.22); bx(gm, 0, 0.09, 0.15, 0.03, 0.05, 0.16); }
    g.position.set(0, -0.6, 0.1);
    this.armR.add(g);
    this.gun = g;
    this.root.position.copy(pos);
    this.lastProg.copy(pos);
  }

  get alive() { return this.st !== "DOWN"; }
  get cstate() { return this.st === "ATTACK" || this.st === "DEFEND" ? "combat" : this.st === "DOWN" ? "down" : "follow"; }
  get weaponStat() { return WSTAT[this.def.weapon]; }

  hurt(n: number) {
    if (this.st === "DOWN") return;
    this.chp -= n;
    this.hurtFlash = 0.2;
    if (this.chp <= 0) { this.chp = 0; this.setState("DOWN"); this.downT = 12; this.tgt = null; }
  }
  damage(): boolean { return false; }

  setState(s: CState) { if (s !== this.st) { this.st = s; this.stateT = 0; } }

  /** Is the straight line from me to (x,z) walkable for a 0.3m-radius body? Three parallel rays at knee height. */
  clearPath(w: CompanionWorld, x: number, z: number) {
    const dx = x - this.pos.x, dz = z - this.pos.z, l = Math.hypot(dx, dz) || 1;
    const px = (-dz / l) * 0.3, pz = (dx / l) * 0.3;
    const y = this.pos.y + 0.4;
    // extend the ray by the body radius so we don't stop with our edge inside an obstacle
    const ex = x + (dx / l) * 0.3, ez = z + (dz / l) * 0.3;
    return w.los(this.pos.x, y, this.pos.z, ex, y, ez) && w.los(this.pos.x + px, y, this.pos.z + pz, ex + px, y, ez + pz) && w.los(this.pos.x - px, y, this.pos.z - pz, ex - px, y, ez - pz);
  }

  /** Local steering around furniture: probe a fan of headings, pick the clearest one that still progresses. */
  steerSide = 0;      // +1 / -1: which way we last detoured (hysteresis against oscillation)
  steerHold = 0;      // seconds to keep committing to that side
  steerAround(w: CompanionWorld, gx: number, gz: number, dt: number): [number, number] | null {
    const base = Math.atan2(gx, gz);
    let best: [number, number] | null = null, bs = -Infinity, bestOff = 0;
    this.steerHold -= dt;
    const bias = this.steerHold > 0 ? this.steerSide : 0;
    // long probes first (smooth detours), then short ones (tight pockets)
    for (const probe of [1.6, 0.9, 0.5]) {
      for (const off of [0, 0.5, -0.5, 1.0, -1.0, 1.5, -1.5, 2.1, -2.1, 2.7, -2.7]) {
        const a = base + off;
        const dx = Math.sin(a), dz = Math.cos(a);
        if (!this.clearPath(w, this.pos.x + dx * probe, this.pos.z + dz * probe)) continue;
        let score = Math.cos(off) * 2 - Math.abs(off) * 0.1 + probe * 0.2;
        if (bias !== 0 && Math.sign(off) === bias) score += 1.5; // keep going the way we already committed
        if (score > bs) { bs = score; best = [dx, dz]; bestOff = off; }
      }
      if (best) break;
    }
    if (best && bestOff !== 0) { const sideNow = Math.sign(bestOff); if (sideNow !== this.steerSide || this.steerHold <= 0) { this.steerSide = sideNow; this.steerHold = 0.7; } }
    return best;
  }

  /** If (x,z) is within a doorway's frame zone, snap it onto the door axis so a body fits through. */
  doorSnap(w: CompanionWorld, x: number, z: number): [number, number] {
    for (const d of w.level.doors) {
      if (Math.abs(d.y - this.pos.y) > 1) continue;
      if (Math.abs(x - d.x) < 1.1 && Math.abs(z - d.z) < 1.3) return [d.x, z];
    }
    return [x, z];
  }

  // ---- perception helpers ----
  canHit(z: Zombie, w: CompanionWorld) {
    if (!z.alive) return false;
    const d = Math.hypot(z.pos.x - this.pos.x, z.pos.z - this.pos.z);
    if (d > this.weaponStat.range || Math.abs(z.pos.y - this.pos.y) > 1.6) return false;
    return w.los(this.pos.x, this.pos.y + 1.5, this.pos.z, z.pos.x, z.pos.y + 1.2, z.pos.z);
  }
  isThreat(z: Zombie, w: CompanionWorld) {
    if (!z.alive) return false;
    const dP = Math.hypot(z.pos.x - w.playerPos.x, z.pos.z - w.playerPos.z);
    const dMe = Math.hypot(z.pos.x - this.pos.x, z.pos.z - this.pos.z);
    const aggressive = z.state === "chase" || z.state === "attack";
    return dP < THREAT_R || dMe < THREAT_R * 0.6 || (aggressive && dP < THREAT_R * 1.4);
  }

  pickTarget(w: CompanionWorld): Zombie | null {
    // Decide, don't react: only zombies that threaten the group AND can be hit from HERE.
    let best: Zombie | null = null, bs = Infinity;
    for (const z of w.zombies) {
      if (!this.isThreat(z, w)) continue;
      if (!this.canHit(z, w)) continue;
      const dP = Math.hypot(z.pos.x - w.playerPos.x, z.pos.z - w.playerPos.z);
      const dMe = Math.hypot(z.pos.x - this.pos.x, z.pos.z - this.pos.z);
      let score = Math.min(dP, dMe) + (z.state === "attack" ? -6 : z.state === "chase" ? -3 : 0);
      if (z === this.tgt) score -= 4; // stickiness
      if (score < bs) { bs = score; best = z; }
    }
    return best;
  }

  updateCompanion(dt: number, w: CompanionWorld) {
    const lv = w.level;
    this.stateT += dt;
    if (this.hurtFlash > 0) this.hurtFlash -= dt;
    const pp = w.playerPos;
    const dPlayer = Math.hypot(pp.x - this.pos.x, pp.z - this.pos.z);
    const sameFloor = Math.abs(pp.y - this.pos.y) < 1.2;

    // ===== DOWN =====
    if (this.st === "DOWN") {
      this.downT -= dt;
      this.body.rotation.x = 1.2; this.body.position.y = -0.85; this.head.rotation.x = 0.4;
      this.armL.rotation.x = this.armR.rotation.x = -0.4;
      if (this.downT <= 0) { this.setState("REGROUP"); this.chp = 55; this.body.rotation.x = 0; this.body.position.y = 0; this.head.rotation.x = 0; w.event(this, "revive"); }
      this.root.position.copy(this.pos);
      return;
    }
    this.chp = Math.min(100, this.chp + dt * 1.5);
    if (this.reloadT > 0) { this.reloadT -= dt; if (this.reloadT <= 0) this.mag = this.weaponStat.mag; }
    if (this.fireT > 0) this.fireT -= dt;

    // ===== formation slot =====
    const fx = -Math.sin(w.playerYaw), fz = -Math.cos(w.playerYaw), rx = Math.cos(w.playerYaw), rz = -Math.sin(w.playerYaw);
    const slot = this.def.slot;
    // formation slot must be free of walls AND furniture (knee-height check); shrink toward Akhil until it is
    let formX = pp.x, formZ = pp.z;
    const slotOk = (cx: number, cz: number) => {
      // body-width corridor from Akhil to the slot, plus the slot itself must have 0.35m clearance on both axes
      const dx = cx - pp.x, dz = cz - pp.z, l = Math.hypot(dx, dz) || 1, px = (-dz / l) * 0.3, pz = (dx / l) * 0.3;
      const y = pp.y + 0.35;
      if (!w.los(pp.x, y, pp.z, cx, y, cz) || !w.los(pp.x + px, y, pp.z + pz, cx + px, y, cz + pz) || !w.los(pp.x - px, y, pp.z - pz, cx - px, y, cz - pz)) return false;
      return w.los(cx - 0.35, y, cz, cx + 0.35, y, cz) && w.los(cx, y, cz - 0.35, cx, y, cz + 0.35);
    };
    for (const k of [1, 0.7, 0.45, 0.25]) {
      const cx = pp.x - fx * slot.y * k + rx * slot.x * k, cz = pp.z - fz * slot.y * k + rz * slot.x * k;
      if (slotOk(cx, cz)) { formX = cx; formZ = cz; break; }
    }
    if (formX === pp.x && formZ === pp.z) {
      // every slot is in a pocket: stand wherever is open next to Akhil (try 8 directions at 1.1m)
      for (let i = 0; i < 8; i++) {
        const a = w.playerYaw + Math.PI + (i * Math.PI) / 4 * (i % 2 ? 1 : -1);
        const cx = pp.x - Math.sin(a) * 1.1, cz = pp.z - Math.cos(a) * 1.1;
        if (slotOk(cx, cz)) { formX = cx; formZ = cz; break; }
      }
    }
    const dForm = Math.hypot(formX - this.pos.x, formZ - this.pos.z);
    const followOrdered = w.followOrderT < 6;

    // ===== target validation / selection (every 0.25s, not every frame) =====
    this.decideT -= dt;
    if (this.tgt && (!this.tgt.alive || !this.canHit(this.tgt, w))) {
      this.targetLostT += dt;
      if (!this.tgt.alive) { w.event(this, "kill"); this.tgt = null; this.targetLostT = 0; }
      else if (this.targetLostT > 0.6) { this.tgt = null; this.targetLostT = 0; }
    } else this.targetLostT = 0;
    if (this.decideT <= 0) {
      this.decideT = 0.25;
      if (followOrdered && this.tgt) {
        const dT = Math.hypot(this.tgt.pos.x - this.pos.x, this.tgt.pos.z - this.pos.z);
        const onAkhil = this.tgt.state === "attack" && Math.hypot(this.tgt.pos.x - pp.x, this.tgt.pos.z - pp.z) < 3;
        if (dT > 4 && !onAkhil) this.tgt = null;
      }
      // while regrouping on order / far from Akhil, only self-defense (very close attackers) counts
      const nt = this.pickTarget(w);
      if (nt && nt !== this.tgt) {
        const selfDefense = Math.hypot(nt.pos.x - this.pos.x, nt.pos.z - this.pos.z) < 4 || (nt.state === "attack" && Math.hypot(nt.pos.x - pp.x, nt.pos.z - pp.z) < 3);
        const regrouping = this.st === "REGROUP" || followOrdered;
        if (!regrouping || selfDefense) { if (!this.tgt && this.st === "FOLLOW") w.event(this, "spot"); this.tgt = nt; }
      } else if (!nt) this.tgt = null;
    }

    // ===== STATE TRANSITIONS (priority order) =====
    const tooFar = dPlayer > 10 || !sameFloor;
    if (this.st === "RECOVERY") {
      this.recoverT -= dt;
      if (this.recoverT <= 0) this.setState(tooFar ? "REGROUP" : "FOLLOW");
    } else if (this.st === "HOLD") {
      this.holdT -= dt;
      if (this.holdT <= 0 || tooFar) this.setState("FOLLOW");
    } else if (followOrdered && dPlayer > 3.5) {
      this.setState("REGROUP");
    } else if (tooFar) {
      // Akhil left: regroup beats fighting (self-defense still fires while moving, see below)
      this.setState("REGROUP");
    } else if (this.st === "REGROUP") {
      if (dPlayer < 4 && sameFloor) this.setState(this.tgt ? "ATTACK" : "FOLLOW");
    } else if (this.tgt) {
      this.setState("ATTACK");
    } else {
      const threatNear = w.zombies.some((z) => z.alive && this.isThreat(z, w) && Math.hypot(z.pos.x - this.pos.x, z.pos.z - this.pos.z) < THREAT_R * 1.3);
      this.setState(threatNear ? "DEFEND" : "FOLLOW");
    }

    // ===== MOVEMENT GOAL per state =====
    this.hasGoal = false;
    this.softGoal = false;
    let strictPath = false;
    let speedCap = this.speed;
    if (this.st === "REGROUP") {
      this.moveGoal.set(formX, pp.y, formZ); this.hasGoal = true; strictPath = true; speedCap = this.speed * 1.3;
    } else if (this.st === "FOLLOW" || this.st === "DEFEND") {
      if (dForm > 1.4 || !sameFloor) {
        this.moveGoal.set(formX, pp.y, formZ); this.hasGoal = true; speedCap = Math.min(this.speed, 1.8 + dForm * 0.7);
        // close enough and can see Akhil over the furniture? then this is a "nice to have" position, not a must
        if (sameFloor && dPlayer < 4.5 && w.los(this.pos.x, this.pos.y + 1.5, this.pos.z, pp.x, pp.y + 1.5, pp.z)) this.softGoal = true;
      }
      // step aside if Akhil walks into me or needs the spot I'm standing on
      const toMe = (this.pos.x - pp.x) * fx + (this.pos.z - pp.z) * fz;
      if (dPlayer < 1.5 && ((w.playerMoving && toMe > 0.1) || w.playerInteracting)) {
        const side = slot.x >= 0 ? 1 : -1;
        let sx = this.pos.x + rx * side * 1.4, sz = this.pos.z + rz * side * 1.4;
        if (!this.clearPath(w, sx, sz)) { sx = this.pos.x - rx * side * 1.4; sz = this.pos.z - rz * side * 1.4; }
        if (!this.clearPath(w, sx, sz)) { sx = this.pos.x - fx * 1.4; sz = this.pos.z - fz * 1.4; }
        this.moveGoal.set(sx, this.pos.y, sz); this.hasGoal = true; speedCap = this.speed; this.softGoal = true;
      }
    } else if (this.st === "ATTACK" && this.tgt) {
      // Bodyguard: fight from here. Only move to back away from a zombie that is almost on me,
      // or to drift back toward Akhil if I've ended up > 6m from him.
      const dT = Math.hypot(this.tgt.pos.x - this.pos.x, this.tgt.pos.z - this.pos.z);
      if (dT < 2.2) {
        const bx2 = this.pos.x - this.tgt.pos.x, bz2 = this.pos.z - this.tgt.pos.z, bl = Math.hypot(bx2, bz2) || 1;
        const gx = this.pos.x + (bx2 / bl) * 1.5, gz = this.pos.z + (bz2 / bl) * 1.5;
        // only back away if the spot is actually open; otherwise stand and shoot
        if (this.clearPath(w, gx, gz)) { this.moveGoal.set(gx, this.pos.y, gz); this.hasGoal = true; speedCap = this.speed * 0.8; this.softGoal = true; }
      } else if (dPlayer > 6) { this.moveGoal.set(formX, pp.y, formZ); this.hasGoal = true; speedCap = this.speed * 0.9; }
    }

    // ===== SHOOTING (any state except DOWN/RECOVERY; also self-defense while regrouping) =====
    if (this.tgt && this.st !== "RECOVERY") {
      const t = this.tgt;
      const dT = Math.hypot(t.pos.x - this.pos.x, t.pos.z - this.pos.z);
      if (this.st === "ATTACK" || this.st === "DEFEND" || dT < 5) this.yaw = lerpAngle(this.yaw, Math.atan2(t.pos.x - this.pos.x, t.pos.z - this.pos.z), dt * 10);
      if (this.reloadT <= 0 && this.fireT <= 0 && this.canHit(t, w)) {
        if (this.mag <= 0) { this.reloadT = this.weaponStat.reload; w.event(this, "reload"); }
        else {
          this.mag--;
          const ws = this.weaponStat;
          if (ws.burst > 1) { this.burstLeft = this.burstLeft > 0 ? this.burstLeft - 1 : ws.burst - 1; this.fireT = this.burstLeft > 0 ? ws.rate : ws.rate * 4; }
          else this.fireT = ws.rate;
          const moving = this.moveSpeed > 0.5;
          const acc = (this.def.weapon === "shotgun" ? 0.9 : 0.74 - Math.min(0.25, dT * 0.015)) * (moving ? 0.7 : 1);
          w.shoot(this, t, Math.random() < acc);
          this.armR.rotation.x = -1.65;
        }
      }
    }

    // ===== NAVIGATION =====
    let moveSpeed = 0;
    if (this.st === "RECOVERY") {
      // bounded recovery: step along a recovery direction (perpendicular/back) and re-path afterwards
      const step = this.speed * 0.8 * dt;
      w.move(this.pos, this.recoverDir.x * step, this.recoverDir.z * step, 0.3, 1.8);
      moveSpeed = this.speed * 0.8;
      this.yaw = lerpAngle(this.yaw, Math.atan2(this.recoverDir.x, this.recoverDir.z), dt * 6);
    } else if (this.hasGoal) {
      const goal = this.moveGoal;
      const gd = Math.hypot(goal.x - this.pos.x, goal.z - this.pos.z);
      // PATH FIRST. Direct steering only when the goal is close and provably visible at ground level.
      const direct = !strictPath && Math.abs(goal.y - this.pos.y) < 1 && gd < 4.5 && this.clearPath(w, goal.x, goal.z);
      const g2 = direct ? goal : this.followPath(dt, w, goal, true);
      // never aim a step into a door frame post
      const snapped = this.doorSnap(w, g2.x, g2.z);
      if (snapped[0] !== g2.x) { const myOwn = g2 === goal; if (myOwn) { this.tmp.set(snapped[0], g2.y, snapped[1]); } else { g2.x = snapped[0]; } }
      const gUse = (g2 === goal && snapped[0] !== g2.x) ? this.tmp : g2;
      if (!direct && this.pathFailed) {
        // unreachable: head to the nearest nav node we can see instead (reachable fallback)
        const n = lv.nav[this.nearestNode(lv.nav, this.pos, w)];
        g2.set(n.x, n.y, n.z);
      }
      // trivial path (we're already at the only node) and the goal is still blocked: it's unreachable from
      // here by the graph — make the goal "soft" so we don't grind, and let local steering do what it can
      if (!direct && this.path.length <= 1 && !this.clearPath(w, goal.x, goal.z)) this.softGoal = true;
      let gx = gUse.x - this.pos.x, gz = gUse.z - this.pos.z, gl = Math.hypot(gx, gz);
      // the next waypoint itself may sit behind furniture (rooms have sparse nav nodes): steer around locally
      if (gl > 0.12 && !this.clearPath(w, this.pos.x + (gx / gl) * Math.min(gl, 1.2), this.pos.z + (gz / gl) * Math.min(gl, 1.2))) {
        const sdir = this.steerAround(w, gx, gz, dt);
        if (sdir) { gx = sdir[0]; gz = sdir[1]; gl = 1; }
      }
      if (gl > 0.12 && gd > 0.35) {
        moveSpeed = Math.min(speedCap, this.speed * 1.3);
        const step = Math.min(gl, moveSpeed * dt);
        // open any closed door we are about to pass through
        for (const d of lv.doors) if (!d.open && !d.locked && Math.abs(d.y - this.pos.y) < 1 && Math.hypot(d.x - this.pos.x, d.z - this.pos.z) < 1.8) w.doorOpen(d.id);
        w.move(this.pos, (gx / gl) * step, (gz / gl) * step, 0.3, 1.8);
        if (this.st !== "ATTACK" && this.st !== "DEFEND") this.yaw = lerpAngle(this.yaw, Math.atan2(gx, gz), dt * 8);
      }
      // progress watchdog: little movement over 0.9s while wanting to move -> recovery (not for optional goals)
      if (moveSpeed > 0 && !this.softGoal) {
        this.progressT += dt;
        if (this.progressT > 0.9) {
          const prog = this.lastProg.distanceTo(this.pos);
          this.lastProg.copy(this.pos);
          this.progressT = 0;
          if (prog < 0.35) {
            this.recoveries++;
            this.path = []; this.pathT = 0; this.pathGoal.set(1e9, 0, 0);
            // pick a recovery direction that is actually open
            const cands = [[-gz / gl, gx / gl], [gz / gl, -gx / gl], [-gx / gl, -gz / gl]];
            let chosen = cands[this.recoveries % 3];
            for (const c of cands) if (w.los(this.pos.x, this.pos.y + 0.45, this.pos.z, this.pos.x + c[0] * 1.2, this.pos.y + 0.45, this.pos.z + c[1] * 1.2)) { chosen = c; break; }
            this.recoverDir.set(chosen[0], 0, chosen[1]);
            this.recoverT = 0.45;
            this.setState("RECOVERY");
          } else this.recoveries = 0;
        }
      } else { this.progressT = 0; this.lastProg.copy(this.pos); }
    } else {
      this.progressT = 0; this.lastProg.copy(this.pos);
      if (this.st === "FOLLOW") this.yaw = lerpAngle(this.yaw, w.playerYaw, dt * 2);
    }
    this.moveSpeed = moveSpeed;

    // ===== last-resort rescue (bounded): hopelessly far, or recovery failed many times =====
    const hopeless = dPlayer > 30 || (!sameFloor && dPlayer > 16) || this.recoveries >= 8;
    if (hopeless) {
      this.sepT += dt;
      if (this.sepT > 5) {
        this.sepT = 0; this.recoveries = 0; this.path = [];
        // only to a spot right behind Akhil that is visible from him (never inside a wall)
        let nx = pp.x - fx * 2.0 + rx * slot.x * 0.5, nz = pp.z - fz * 2.0 + rz * slot.x * 0.5;
        if (!w.los(pp.x, pp.y + 0.6, pp.z, nx, pp.y + 0.6, nz)) { nx = pp.x - fx * 1.0; nz = pp.z - fz * 1.0; }
        this.pos.set(nx, pp.y, nz);
        w.move(this.pos, 0, 0, 0.3, 1.8);
        this.setState("FOLLOW");
        w.event(this, "separated");
      } else if (this.sepT > 1 && this.sepT < 1.05) w.event(this, "separated");
    } else this.sepT = 0;

    // ===== gravity =====
    const g = lv.groundAt(this.pos.x, this.pos.z, this.pos.y);
    if (this.pos.y > g + 0.01) { this.vy -= 20 * dt; this.pos.y = Math.max(g, this.pos.y + this.vy * dt); } else { this.pos.y = g; this.vy = 0; }

    // ===== animation =====
    if (moveSpeed > 0.1) this.animWalk(dt, moveSpeed, false);
    else { this.animWalk(dt * 0.1, 0.2, false); this.legL.rotation.x = this.legR.rotation.x = 0; }
    const aiming = this.st === "ATTACK" || this.st === "DEFEND";
    this.armR.rotation.x += ((aiming ? -1.5 : -0.5) - this.armR.rotation.x) * Math.min(1, dt * 8);
    if (this.def.weapon !== "pistol") this.armL.rotation.x += ((aiming ? -1.3 : -0.6) - this.armL.rotation.x) * Math.min(1, dt * 8);
    this.body.rotation.x = 0; this.head.rotation.z = 0;
    this.root.position.copy(this.pos);
    this.root.rotation.y = this.yaw;

    this.chatT -= dt;
    if (this.chatT <= 0) { this.chatT = 25 + Math.random() * 30; if (this.st === "FOLLOW" && dPlayer < 8) w.event(this, "idle_chat"); }
    this.dbg = this.st;
  }
}
