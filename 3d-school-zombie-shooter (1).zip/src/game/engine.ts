import * as THREE from "three";
import { Level, ROOMS as ROOMS_REF, type Door, type PickupDef, type PickupKind } from "./level";
import { audio } from "./audio";
import { WEAPONS, buildViewModel, buildPickupModel, muzzleTexture, type WeaponId, type ViewModel } from "./weapons";
import { Zombie, Humanoid, ZOMBIE_LOOKS, type ZWorld } from "./zombie";
import { Companion, COMPANION_DEFS, type CompanionWorld } from "./companion";
import { voice, type CharId, type Ctx } from "./dialogue";
import { MISSIONS, prereqs } from "./missions";
import { PRESETS, autoPreset, type GfxPreset } from "../gfx/presets";
import { RenderPipeline } from "../gfx/pipeline";
import { VegetationField } from "../gfx/vegetation";
import { ParticleField, lightShaft } from "../gfx/atmosphere";
import { VEHICLE_SPAWNS, NPCS, CITY_SPAWNS, ROADBLOCK_SPAWNS, M1_SPAWNS, M3_SPAWNS, M4_SPAWNS, GARAGE, HARBOR, GAS_STATION, type NPCDef, type VehicleSpawn } from "./city";

export type Mode = "menu" | "intro" | "playing" | "paused" | "radio" | "dead" | "ending" | "complete";

export interface UIState {
  mode: Mode;
  health: number;
  weapon: string | null;
  weaponId: WeaponId | null;
  mag: number;
  reserve: number;
  owned: WeaponId[];
  keys: string[];
  hasFlashlight: boolean;
  flashOn: boolean;
  objective: string;
  objectiveSub: string;
  prompt: string | null;
  subtitle: { who: string; text: string } | null;
  bigText: string | null;
  caption: string | null;
  fade: number;
  letterbox: boolean;
  toasts: { id: number; text: string }[];
  note: { title: string; text: string } | null;
  choices: string[] | null;
  damageT: number;
  hitT: number;
  killT: number;
  ads: boolean;
  reloading: boolean;
  kills: number;
  stage: number;
  surviveTime: number;
  fps: number;
  canSkip: boolean;
  speed: number | null;
  waypoint: { label: string; dist: number } | null;
  dialog: { name: string; text: string; options: string[] } | null;
  hasMap: boolean;
  lockOn: boolean;
  medkits: number;
  vsub: { who: string; text: string; color: string } | null;
  squad: { name: string; hp: number; down: boolean; weapon: string; cd: number }[];
  squadMode: boolean;
  missions: { id: number; title: string; status: number; prog: string; giver: string }[];
  newFile: { title: string; text: string } | null;
}

export interface Input {
  keys: Set<string>;
  lookX: number; lookY: number;
  moveX: number; moveY: number; // joystick
  sprint: boolean;
  fire: boolean;
  ads: boolean;
  jump: boolean;
  reload: boolean;
  interact: boolean;
  switchW: boolean;
  flash: boolean;
  weaponSlot: number;
  follow: boolean;
}

const KEY_NAMES: Record<string, string> = { key_janitor: "Janitor's Key", key_principal: "Principal's Key", key_office: "Office Key", key_roof: "Military Override", toolbox: "Ravi's Toolbox", city_map: "City Map", file_4b: "Medical File 4B", helix_keycard: "Helix Keycard" };

interface VKind { max: number; rev: number; acc: number; turn: number; r: number; seatH: number; eng: "moto" | "car" | "sports" | null; name: string }
const VKINDS: Record<string, VKind> = {
  bicycle: { max: 8.5, rev: 2.5, acc: 5, turn: 2.4, r: 0.5, seatH: 1.35, eng: null, name: "Bicycle" },
  moto: { max: 15, rev: 3, acc: 7.5, turn: 1.9, r: 0.55, seatH: 1.3, eng: "moto", name: "Motorbike" },
  sedan: { max: 17, rev: 5, acc: 7, turn: 1.3, r: 1.35, seatH: 1.45, eng: "car", name: "Sedan" },
  sports: { max: 23, rev: 5, acc: 11, turn: 1.5, r: 1.3, seatH: 1.32, eng: "sports", name: "Sports car" },
};

interface Vehicle { id: string; kind: string; spawn: VehicleSpawn; pos: THREE.Vector3; yaw: number; speed: number; group: THREE.Group; wheels: THREE.Object3D[]; light: THREE.SpotLight | null }
interface NPCEnt { def: NPCDef; h: Humanoid }
const SAVE_KEY = "lastfour_school_save_v1";
const QUALITY_KEY = "lastfour_quality";

const SPAWNS: [number, number, number, number, boolean?][] = [
  [-2, 0, 0.6, 0], [8, 0, -0.6, 1], [24, 0, 4, 2], [26, 0, -5, 3], [21, 0, -2, 4], [-13, 0, 8.6, 0], [1, 0, 8, 1], [6, 0, 6.8, 4],
  [-26, 0, -9.5, 3], [7, 0, -7.6, 0], [14, 0, -4, 2], [-3, 0, -8.6, 1], [-22, 4, 0.5, 0], [4, 4, -0.4, 4, true], [12, 4, 0.5, 1],
  [-12, 4, 8.6, 3], [10, 4, -8, 0], [-2, 4, -9.5, 2], [-24, 4, -5.6, 1, true], [-8, 4, -7.4, 4],
];

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

interface Shot {
  dur: number;
  from: [THREE.Vector3, THREE.Vector3];
  to: [THREE.Vector3, THREE.Vector3];
  start?: () => void;
  update?: (t: number, dt: number) => void;
  shake?: number;
}

interface Actor { h: Humanoid; path: THREE.Vector3[]; seg: number; speed: number; delay: number; zombie: boolean }

interface Particle { x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number }

export class Engine {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  vmScene = new THREE.Scene();
  vmCam: THREE.PerspectiveCamera;
  vmLight: THREE.PointLight;
  vmAmb: THREE.AmbientLight;
  level!: Level;
  quality = 1;
  sensitivity = 1;
  preset: GfxPreset = PRESETS[1];
  pipeline: RenderPipeline | null = null;
  sun!: THREE.DirectionalLight;
  vegetation = new VegetationField(1);
  dust: ParticleField | null = null;
  fillLight!: THREE.PointLight;
  isTouch: boolean;

  input: Input = { keys: new Set(), lookX: 0, lookY: 0, moveX: 0, moveY: 0, sprint: false, fire: false, ads: false, jump: false, reload: false, interact: false, switchW: false, flash: false, weaponSlot: 0, follow: false };

  mode: Mode = "menu";
  baseFov = 72;
  invertY = false;
  killsAtRadio = 0;
  fogDen = 0.055;
  heli = new THREE.Group();
  heliRotor!: THREE.Object3D;
  heliTailRotor!: THREE.Object3D;
  heliSpot!: THREE.SpotLight;
  heliCone!: THREE.Mesh;
  heliBlink!: THREE.Mesh;
  blinkT = 0;
  dustPts!: THREE.Points;
  dustVel: Float32Array = new Float32Array(0);
  // chapter 2 — city
  vehicles: Vehicle[] = [];
  driving: Vehicle | null = null;
  vehiclesUnlocked = false;
  m2 = 0;
  // extended missions: status per id (0 = not taken, 1 = active, 2 = objective done (turn in), 3 = complete); kill counters
  mst: Record<number, number> = {};
  mkills: Record<number, number> = {};
  // Chapter 3 — The Voyage
  boatDeck = new THREE.Group();
  boatCrew: Humanoid[] = [];
  evacConfirmed = false;
  side = 0; sideKills = 0;
  leftSchool = false;
  cityActive = false;
  npcs: NPCEnt[] = [];
  dialogActs: (() => void)[] = [];
  waySprite!: THREE.Sprite;
  boat = new THREE.Group();
  boatLight!: THREE.SpotLight;
  engineSndT = 0;
  crashCD = 0;
  // companions
  companions: Companion[] = [];
  squadMode = true; // true = play with Narendra, Mahesh & Harsha; false = Akhil alone
  followOrderAt = -Infinity;
  ammoCD: Record<string, number> = {};
  visitedRooms = new Set<string>();
  curRoom = "";
  hordeT = 0;
  // auto-shoot & inventory
  autoShoot = false;
  medkits = 0;
  tracerGeo!: THREE.BoxGeometry;
  tracers: { mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; life: number }[] = [];
  // player
  pos = V(0, 0, 0);
  vel = V(0, 0, 0);
  yaw = 0;
  pitch = 0;
  onGround = true;
  health = 100;
  stepDist = 0;
  bobT = 0;
  recoilPitch = 0;
  shakeT = 0;
  // inventory
  owned: WeaponId[] = [];
  ammo: Record<WeaponId, { mag: number; reserve: number }> = { pistol: { mag: 0, reserve: 0 }, shotgun: { mag: 0, reserve: 0 }, rifle: { mag: 0, reserve: 0 } };
  current: WeaponId | null = null;
  keys: string[] = [];
  hasFlashlight = false;
  flashOn = false;
  fireCD = 0;
  reloadT = 0;
  switchT = 0;
  pendingWeapon: WeaponId | null | undefined = undefined;
  adsT = 0;
  triggerHeld = false;
  punchT = 0;
  // world
  zombies: Zombie[] = [];
  deadIds = new Set<string>();
  pickups: { def: PickupDef; mesh: THREE.Object3D; taken: boolean }[] = [];
  taken = new Set<string>();
  readNotes = new Set<string>();
  stage = 0; // 0 find radio, 1 radio done
  kills = 0;
  surviveTime = 0;
  spawnT = 20;
  dropN = 0;
  // viewmodels
  vms: Record<string, ViewModel> = {};
  vmGroup = new THREE.Group();
  flashTex = muzzleTexture();
  flashT = 0;
  muzzleLight: THREE.PointLight;
  flashlight: THREE.SpotLight;
  // effects
  particles: Particle[] = [];
  pPoints: THREE.Points;
  pGeo: THREE.BufferGeometry;
  pColors: Float32Array;
  // boxes
  boxes!: Float32Array;
  // cutscene
  shots: Shot[] = [];
  shotIdx = 0;
  shotT = 0;
  actors: Actor[] = [];
  cutsceneEnd: (() => void) | null = null;
  camBlend = 0;
  camFrom = V(0, 0, 0);
  camLookFrom = V(0, 0, 0);
  radioLines: { who: string; text: string; voice: "soldier" | "operator" | "akhil"; dur: number; choice?: string[] }[] = [];
  entranceGlass = new THREE.Group();
  // ui
  ui: UIState;
  toastId = 0;
  toastTimes: number[] = [];
  lastTime = 0;
  running = false;
  frames = 0;
  fpsT = 0;
  saveT = 0;
  perfSamples: number[] = [];
  autoDowngraded = false;
  heartT = 0;
  ambientT = 5;
  interactT = 0;
  lightBudget = 99;
  lightCullT = 0;
  currentInteract: { label: string; act: () => void } | null = null;
  tmpV = V(0, 0, 0);
  tmpV2 = V(0, 0, 0);

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.isTouch = "ontouchstart" in window || window.matchMedia("(pointer: coarse)").matches;
    const q = localStorage.getItem(QUALITY_KEY);
    this.quality = q !== null ? +q : autoPreset();
    this.preset = PRESETS[Math.max(0, Math.min(PRESETS.length - 1, this.quality))];
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance", stencil: false });
    this.renderer.autoClear = false;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.18;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.camera = new THREE.PerspectiveCamera(72, 1, 0.05, 70);
    this.camera.rotation.order = "YXZ";
    this.vmCam = new THREE.PerspectiveCamera(60, 1, 0.01, 5);
    this.scene.background = new THREE.Color(0x05070a);
    this.scene.fog = new THREE.FogExp2(0x05070a, 0.055);
    this.scene.add(this.camera);

    this.level = new Level(this.scene, 2);
    this.makeEntranceGlass();

    // flashlight & muzzle light (always present to avoid shader recompiles)
    this.flashlight = new THREE.SpotLight(0xfff2d8, 0, 28, 0.5, 0.45, 1.3);
    this.flashlight.position.set(0.2, -0.15, 0);
    this.camera.add(this.flashlight);
    this.flashlight.target.position.set(0, 0, -5);
    this.camera.add(this.flashlight.target);
    this.muzzleLight = new THREE.PointLight(0xffaa44, 0, 9, 2);
    this.scene.add(this.muzzleLight);
    // soft bounce/fill light on the camera so nearby surfaces never crush to black
    this.fillLight = new THREE.PointLight(0xa8bcd4, 0.5, 7.5, 1.6);
    this.fillLight.position.set(0, 0.2, 0.2);
    this.camera.add(this.fillLight);

    // viewmodel scene
    this.vmAmb = new THREE.AmbientLight(0x8890a0, 0.9);
    this.vmScene.add(this.vmAmb);
    const dl = new THREE.DirectionalLight(0xffffff, 0.8);
    dl.position.set(0.5, 1, 0.6);
    this.vmScene.add(dl);
    this.vmLight = new THREE.PointLight(0xffaa44, 0, 2);
    this.vmLight.position.set(0.1, 0, -0.8);
    this.vmScene.add(this.vmLight);
    this.vmScene.add(this.vmGroup);
    for (const id of ["hands", "pistol", "shotgun", "rifle"] as const) {
      const vm = buildViewModel(id, this.flashTex);
      vm.group.visible = false;
      this.vmGroup.add(vm.group);
      this.vms[id] = vm;
    }

    // particles
    const N = 300;
    this.pGeo = new THREE.BufferGeometry();
    this.pGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
    this.pColors = new Float32Array(N * 3);
    this.pGeo.setAttribute("color", new THREE.BufferAttribute(this.pColors, 3));
    this.pPoints = new THREE.Points(this.pGeo, new THREE.PointsMaterial({ size: 0.06, vertexColors: true, sizeAttenuation: true }));
    this.pPoints.frustumCulled = false;
    this.scene.add(this.pPoints);
    for (let i = 0; i < N; i++) this.particles.push({ x: 0, y: -100, z: 0, vx: 0, vy: 0, vz: 0, life: 0 });

    this.buildHeli();
    this.buildDust();
    this.buildTracers();
    this.buildVehicles();
    this.buildNPCs();
    this.buildBoat();
    this.buildWaypoint();
    this.buildBoxes();
    this.applyQuality();

    this.ui = {
      mode: "menu", health: 100, weapon: null, weaponId: null, mag: 0, reserve: 0, owned: [], keys: [], hasFlashlight: false, flashOn: false,
      objective: "", objectiveSub: "", prompt: null, subtitle: null, bigText: null, caption: null, fade: 0, letterbox: false, toasts: [], note: null,
      choices: null, damageT: 0, hitT: 0, killT: 0, ads: false, reloading: false, kills: 0, stage: 0, surviveTime: 0, fps: 0, canSkip: false,
      speed: null, waypoint: null, dialog: null, hasMap: false, lockOn: false, medkits: 0, vsub: null, squad: [], squadMode: true, missions: [], newFile: null,
    };

    this.dressScene();

    // menu backdrop camera
    this.camera.position.set(20, 3, -8);
    this.camera.lookAt(-10, 1.5, 0);
    this.resize();
    window.addEventListener("resize", this.resize);
    this.running = true;
    requestAnimationFrame(this.loop);
  }

  dispose() {
    this.running = false;
    window.removeEventListener("resize", this.resize);
    audio.stopSpeech();
    this.renderer.dispose();
  }

  // ================= COMPANIONS =================
  /** Place the squad in formation around Akhil's current position (used after cutscenes / chapter jumps). */
  placeSquad() {
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw), rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    for (const c of this.companions) {
      const d = c.def.slot;
      c.pos.set(this.pos.x - fx * d.y + rx * d.x, this.pos.y, this.pos.z - fz * d.y + rz * d.x);
      this.move(c.pos, 0, 0, 0.3, 1.8);
      c.pos.y = this.level.groundAt(c.pos.x, c.pos.z, this.pos.y + 0.5);
      c.path = []; c.tgt = null; c.recoveries = 0; c.setState("FOLLOW");
      c.root.position.copy(c.pos);
    }
  }

  spawnCompanions() {
    if (this.companions.length || !this.squadMode) return;
    this.makeCWorld();
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw), rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    for (const def of COMPANION_DEFS) {
      const p = V(this.pos.x - fx * def.slot.y + rx * def.slot.x, this.pos.y, this.pos.z - fz * def.slot.y + rz * def.slot.x);
      const c = new Companion(def, p);
      this.move(c.pos, 0, 0, 0.3, 1.8);
      c.root.position.copy(c.pos);
      c.yaw = this.yaw + Math.PI;
      this.scene.add(c.root);
      this.companions.push(c);
    }
    this.zworld.victims = this.companions;
  }

  companionShoot(c: Companion, t: Zombie, hit: boolean) {
    const sx = c.pos.x, sy = c.pos.y + 1.35, sz = c.pos.z;
    const tx = t.pos.x + (hit ? 0 : (Math.random() - 0.5) * 1.2), ty = t.pos.y + 1.2 + (hit ? (Math.random() - 0.5) * 0.4 : (Math.random() - 0.5) * 1.5), tz = t.pos.z + (hit ? 0 : (Math.random() - 0.5) * 1.2);
    this.spawnTracer(sx, sy, sz, tx, ty, tz);
    audio.gunshotAt(c.def.weapon, c.pos);
    if (hit) {
      this.spawnBurst(tx, ty, tz, 5, [0.45, 0.02, 0.02], 2);
      audio.zombieHit(t.pos);
      if (t.damage(c.weaponStat.dmg, this.zworld)) this.onKill(t);
    }
    // gunfire noise alerts nearby infected
    for (const z of this.zombies) if (z.alive && z.pos.distanceTo(c.pos) < 20 && Math.abs(z.pos.y - c.pos.y) < 2) z.hear(c.pos, this.zworld);
  }

  companionEvent(c: Companion, ev: string) {
    const ctx = ev as Ctx;
    const cd: Partial<Record<Ctx, number>> = { spot: 14, kill: 10, reload: 18, separated: 20, idle_chat: 40, revive: 5, down: 5 };
    if (ev === "revive") this.toast(`${c.def.name} is back up.`);
    voice.say(c.def.id, ctx, { cooldown: cd[ctx] ?? 12, priority: ev === "down" || ev === "revive" ? 3 : 1 });
  }

  /** Broadcast a story/mission event to the squad (one of them speaks). */
  squadSay(ctx: Ctx, who?: CharId, priority = 2) {
    const list = this.companions.filter((c) => c.alive);
    if (!list.length) {
      // solo: Akhil talks to himself for the key beats only
      if (!this.squadMode && (ctx === "area" || ctx === "horde" || ctx === "door_locked" || ctx === "mission_start" || ctx === "mission_done" || ctx === "radio" || ctx === "vehicle"))
        voice.say("akhil", ctx, { cooldown: 20, priority });
      return;
    }
    const pick = who ? list.find((c) => c.def.id === who) : list[Math.floor(Math.random() * list.length)];
    if (pick) voice.say(pick.def.id, ctx, { cooldown: 6, priority, force: priority >= 2 });
  }

  /** Keep every ammo counter sane (no negatives, no absurd values). */
  requestAmmo(c: Companion) {
    const now = performance.now() / 1000;
    const last = this.ammoCD[c.def.id] ?? -999;
    const left = 60 - (now - last);
    const w = c.def.weapon;
    const names: Record<string, string> = { pistol: "9mm rounds", shotgun: "shotgun shells", rifle: "5.56 rounds" };
    if (left > 0) {
      voice.say(c.def.id, "ammo_cooldown", { cooldown: 2, priority: 2, force: true });
      this.toast(`${c.def.name} can share more ammo in ${Math.ceil(left)}s.`);
      return;
    }
    this.ammoCD[c.def.id] = now;
    this.ammo[w].reserve += 100;
    audio.pickup();
    voice.say(c.def.id, "ammo_give", { cooldown: 2, priority: 2, force: true });
    this.toast(`+100 ${names[w]} from ${c.def.name}${this.owned.includes(w) ? "" : " (you have no " + w + " yet — it'll be waiting)"}`);
    this.save();
  }

  openCompanionDialog(c: Companion) {
    const now = performance.now() / 1000;
    const left = Math.max(0, 60 - (now - (this.ammoCD[c.def.id] ?? -999)));
    const wname = { pistol: "9mm", shotgun: "shells", rifle: "5.56" }[c.def.weapon];
    const flavor: Record<string, string> = {
      narendra: "Status report: holding. What do you need?",
      mahesh: "Sup! You look like you need something. Ammo? A hug? I've got both.",
      harsha: "Yeah?",
    };
    this.ui.dialog = {
      name: c.def.name,
      text: `${flavor[c.def.id]}  (${c.def.name} carries unlimited ${wname} for the ${c.def.weapon}.)`,
      options: [left > 0 ? `Ask for ammo — ready in ${Math.ceil(left)}s` : `Ask for 100 ${wname} rounds`, "How are you holding up?", "Everyone on me — follow!", "Never mind"],
    };
    this.dialogActs = [
      () => this.requestAmmo(c),
      () => { voice.say(c.def.id, c.chp < 50 ? "down" : "check", { cooldown: 0, priority: 2, force: true }); this.toast(`${c.def.name}: ${Math.round(c.chp)}% — ${c.st}`); },
      () => this.followMe(),
      () => {},
    ];
    this.input.fire = false;
    if (document.pointerLockElement) document.exitPointerLock();
  }

  roomAt(x: number, y: number, z: number): string {
    if (x > 30) return y > 7 ? "roof" : "lobby";
    if (y > 7) return "roof";
    const f = y > 3 ? 1 : 0;
    if (Math.abs(z) <= 2) return x > 18 ? "lobby" : "corridor" + f;
    for (const r of ROOMS_REF) if (r.floor === f && x >= r.x0 && x <= r.x1 && ((r.side === "N" && z > 2) || (r.side === "S" && z < -2))) return r.id;
    return "corridor" + f;
  }

  /** FOLLOW ME: a priority change, not an off switch. Companions drop non-defensive targets and regroup via paths. */
  followMe() {
    if (!this.companions.length) return;
    this.followOrderAt = performance.now() / 1000;
    for (const c of this.companions) {
      if (!c.alive) continue;
      const t = c.tgt;
      if (t && Math.hypot(t.pos.x - c.pos.x, t.pos.z - c.pos.z) > 4) c.tgt = null; // abandon distant pursuit, keep self-defense
      if (Math.hypot(c.pos.x - this.pos.x, c.pos.z - this.pos.z) > 3.5) c.setState("REGROUP");
    }
    audio.click();
    this.toast("FOLLOW ME — squad regrouping on you.");
    this.squadSay("follow", undefined, 2);
  }

  updateCompanions(dt: number) {
    if (!this.companions.length) return;
    const cw = this.cworld;
    cw.level = this.level;
    cw.zombies = this.zombies;
    cw.followOrderT = performance.now() / 1000 - this.followOrderAt;
    cw.playerYaw = this.yaw;
    cw.playerMoving = this.vel.lengthSq() > 1;
    cw.playerInteracting = !!this.currentInteract;
    cw.playerAlive = this.mode === "playing";
    for (const c of this.companions) {
      c.updateCompanion(dt, cw);
      c.root.visible = true;
    }
    // separation between companions
    for (let i = 0; i < this.companions.length; i++) for (let j = i + 1; j < this.companions.length; j++) {
      const a = this.companions[i], b = this.companions[j];
      const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, d2 = dx * dx + dz * dz;
      if (d2 < 0.8 && d2 > 1e-6) {
        const d = Math.sqrt(d2), push = (0.9 - d) / 2;
        this.move(a.pos, -(dx / d) * push, -(dz / d) * push, 0.3, 1.8);
        this.move(b.pos, (dx / d) * push, (dz / d) * push, 0.3, 1.8);
      }
    }
    // never idle inside a doorway: if standing still within a door frame, nudge through it
    for (const c of this.companions) {
      if (!c.alive || c.moveSpeed > 0.1) continue;
      for (const d of this.level.doors) {
        if (Math.abs(d.y - c.pos.y) > 1) continue;
        if (Math.abs(d.x - c.pos.x) < 0.9 && Math.abs(d.z - c.pos.z) < 0.7) {
          const side = Math.sign(this.pos.z - d.z) || 1; // toward Akhil's side of the door
          this.move(c.pos, 0, side * 2.5 * dt, 0.3, 1.8);
        }
      }
    }
    // horde warning
    this.hordeT -= dt;
    if (this.hordeT <= 0) {
      this.hordeT = 3;
      const near = this.zombies.filter((z) => z.alive && z.pos.distanceTo(this.pos) < 12).length;
      if (near >= 4) this.squadSay("horde", undefined, 2);
    }
    // area discovery
    const room = this.roomAt(this.pos.x, this.pos.y, this.pos.z);
    if (room !== this.curRoom) {
      this.curRoom = room;
      if (!this.visitedRooms.has(room)) { this.visitedRooms.add(room); if (!room.startsWith("corridor")) this.squadSay("area", undefined, 1); }
    }
  }

  // ================= TRACERS & MEDKITS =================
  buildTracers() {
    this.tracerGeo = new THREE.BoxGeometry(0.018, 0.018, 1);
    this.tracerGeo.translate(0, 0, 0.5);
    for (let i = 0; i < 14; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffc98a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
      const mesh = new THREE.Mesh(this.tracerGeo, mat);
      mesh.visible = false;
      mesh.frustumCulled = false;
      this.scene.add(mesh);
      this.tracers.push({ mesh, mat, life: 0 });
    }
  }

  spawnTracer(sx: number, sy: number, sz: number, ex: number, ey: number, ez: number) {
    const t = this.tracers.find((tt) => tt.life <= 0);
    if (!t) return;
    const len = Math.hypot(ex - sx, ey - sy, ez - sz);
    if (len < 0.6) return;
    t.mesh.position.set(sx, sy, sz);
    t.mesh.lookAt(ex, ey, ez);
    t.mesh.scale.set(1, 1, len);
    t.mesh.visible = true;
    t.life = 0.09;
    t.mat.opacity = 0.85;
  }

  updateTracers(dt: number) {
    for (const t of this.tracers) {
      if (t.life <= 0) continue;
      t.life -= dt;
      t.mat.opacity = Math.max(0, t.life / 0.09) * 0.85;
      if (t.life <= 0) t.mesh.visible = false;
    }
  }

  useMedkit() {
    if (this.medkits <= 0) { this.toast("No medkits. Loot pharmacies, lockers and desks."); return; }
    if (this.health >= 100) { this.toast("Health is already full."); return; }
    this.medkits--;
    this.health = Math.min(100, this.health + 45);
    audio.pickup();
    this.toast(`Medkit used (+45 HP) — ${this.medkits} left`);
    this.save();
  }

  // ================= CHAPTER 2: VEHICLES =================
  buildVehicles() {
    const dark = new THREE.MeshLambertMaterial({ color: 0x1c1e22 });
    const chrome = new THREE.MeshLambertMaterial({ color: 0x8a9098 });
    const glassM = new THREE.MeshLambertMaterial({ color: 0x16222e, emissive: 0x0c161f, emissiveIntensity: 0.5 });
    const bodyCols: Record<string, number> = { sedan1: 0x7a2020, sedan2: 0x3a5a7a, sports1: 0xc0481a, moto1: 0x2a4a2a };
    const bx = (g: THREE.Group, m: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number) => {
      const mm = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m);
      mm.position.set(x, y, z);
      g.add(mm);
      return mm;
    };
    const wheel = (g: THREE.Group, x: number, y: number, z: number, r: number, w: number) => {
      const mm = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 10), dark);
      mm.rotation.z = Math.PI / 2;
      const piv = new THREE.Group();
      piv.position.set(x, y, z);
      piv.add(mm);
      g.add(piv);
      return piv;
    };
    for (const sp of VEHICLE_SPAWNS) {
      const g = new THREE.Group();
      const wheels: THREE.Object3D[] = [];
      if (sp.kind === "bicycle") {
        wheels.push(wheel(g, 0, 0.35, -0.55, 0.34, 0.06), wheel(g, 0, 0.35, 0.55, 0.34, 0.06));
        bx(g, chrome, 0, 0.6, 0, 0.05, 0.08, 1.1);
        bx(g, chrome, 0, 0.75, -0.5, 0.05, 0.5, 0.05);
        bx(g, chrome, 0, 1.0, -0.52, 0.5, 0.05, 0.05); // handlebar
        bx(g, dark, 0, 0.92, 0.25, 0.14, 0.06, 0.3); // seat
        bx(g, chrome, 0, 0.5, 0.12, 0.04, 0.35, 0.04);
      } else if (sp.kind === "moto") {
        const body = new THREE.MeshLambertMaterial({ color: bodyCols[sp.id] ?? 0x3a3a3a });
        wheels.push(wheel(g, 0, 0.35, -0.72, 0.34, 0.14), wheel(g, 0, 0.35, 0.72, 0.34, 0.14));
        bx(g, body, 0, 0.62, 0.05, 0.3, 0.35, 1.1);
        bx(g, dark, 0, 0.88, 0.3, 0.26, 0.12, 0.5);
        bx(g, chrome, 0, 0.9, -0.6, 0.55, 0.06, 0.06);
        bx(g, chrome, 0, 0.72, -0.64, 0.06, 0.4, 0.06);
        bx(g, new THREE.MeshBasicMaterial({ color: 0xffeeaa }), 0, 0.72, -0.85, 0.12, 0.12, 0.06);
      } else {
        const low = sp.kind === "sports";
        const body = new THREE.MeshLambertMaterial({ color: bodyCols[sp.id] ?? 0x5a5a5a });
        wheels.push(wheel(g, -0.85, 0.34, -1.25, 0.34, 0.22), wheel(g, 0.85, 0.34, -1.25, 0.34, 0.22), wheel(g, -0.85, 0.34, 1.25, 0.34, 0.22), wheel(g, 0.85, 0.34, 1.25, 0.34, 0.22));
        bx(g, body, 0, low ? 0.52 : 0.6, 0, 1.8, low ? 0.4 : 0.55, 4.1);
        bx(g, body, 0, low ? 0.92 : 1.12, 0.25, 1.6, low ? 0.4 : 0.5, 2.0);
        bx(g, glassM, 0, low ? 0.94 : 1.14, 0.25, 1.62, low ? 0.32 : 0.4, 2.02);
        bx(g, new THREE.MeshBasicMaterial({ color: 0xffeeaa }), -0.55, 0.6, -2.06, 0.3, 0.12, 0.04);
        bx(g, new THREE.MeshBasicMaterial({ color: 0xffeeaa }), 0.55, 0.6, -2.06, 0.3, 0.12, 0.04);
        bx(g, new THREE.MeshBasicMaterial({ color: 0xaa2222 }), 0, 0.6, 2.06, 1.5, 0.1, 0.04);
        if (low) bx(g, dark, 0, 0.95, 1.9, 1.5, 0.1, 0.3); // spoiler
      }
      // headlight (off until ridden)
      let light: THREE.SpotLight | null = null;
      if (sp.kind !== "bicycle") {
        light = new THREE.SpotLight(0xfff0cc, 0, 55, 0.42, 0.5, 1.1);
        light.position.set(0, 0.85, -1.6);
        g.add(light, light.target);
        light.target.position.set(0, 0.2, -18);
      }
      g.position.set(sp.x, 0, sp.z);
      g.rotation.y = sp.yaw;
      this.scene.add(g);
      this.vehicles.push({ id: sp.id, kind: sp.kind, spawn: sp, pos: new THREE.Vector3(sp.x, 0, sp.z), yaw: sp.yaw, speed: 0, group: g, wheels, light });
    }
  }

  buildNPCs() {
    for (const def of NPCS) {
      const h = new Humanoid(def.look, false);
      h.root.position.set(def.x, 0, def.z);
      h.root.rotation.y = def.yaw;
      this.scene.add(h.root);
      this.npcs.push({ def, h });
    }
  }

  buildBoat() {
    const hullM = new THREE.MeshLambertMaterial({ color: 0x4a5560 });
    const darkM = new THREE.MeshLambertMaterial({ color: 0x23282e });
    const bx = (m: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number) => {
      const mm = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m);
      mm.position.set(x, y, z);
      this.boat.add(mm);
    };
    bx(hullM, 0, 0.5, 0, 4, 1.6, 11);
    bx(hullM, 0, 0.9, -6, 2.6, 0.8, 2.2); // bow
    bx(darkM, 0, 1.9, 1, 2.6, 1.4, 4);
    bx(darkM, 0, 2.9, 1.5, 0.2, 1.6, 0.2);
    bx(new THREE.MeshBasicMaterial({ color: 0xffdd88 }), 0, 2.2, -1.1, 1.8, 0.5, 0.1);
    bx(new THREE.MeshBasicMaterial({ color: 0x22ff44 }), 1.4, 3.4, 1.5, 0.12, 0.12, 0.12);
    this.boatLight = new THREE.SpotLight(0xfff2cc, 0, 80, 0.3, 0.5, 1.2);
    this.boatLight.position.set(0, 3, -4);
    this.boat.add(this.boatLight, this.boatLight.target);
    this.boatLight.target.position.set(-10, 0, -14);
    this.boat.visible = false;
    this.scene.add(this.boat);
  }

  buildWaypoint() {
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const g = c.getContext("2d")!;
    g.strokeStyle = "#ffd23a";
    g.lineWidth = 6;
    g.beginPath();
    g.moveTo(32, 6); g.lineTo(58, 32); g.lineTo(32, 58); g.lineTo(6, 32); g.closePath();
    g.stroke();
    g.fillStyle = "rgba(255,210,58,0.35)";
    g.fill();
    const tex = new THREE.CanvasTexture(c);
    this.waySprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, fog: false }));
    this.waySprite.scale.set(1.6, 1.6, 1);
    this.waySprite.renderOrder = 999;
    this.waySprite.visible = false;
    this.scene.add(this.waySprite);
  }

  // ---------- driving ----------
  enterVehicle(v: Vehicle) {
    this.driving = v;
    if (v.light) v.light.intensity = 14;
    this.vmGroup.visible = false;
    this.adsT = 0;
    this.input.fire = false;
    this.reloadT = 0;
    audio.click();
    this.toast(`${VKINDS[v.kind].name} — joystick/WASD to drive, USE to get off`);
  }

  exitVehicle() {
    const v = this.driving;
    if (!v) return;
    this.driving = null;
    audio.setEngine(null, 0);
    if (v.light) v.light.intensity = 0;
    v.speed = 0;
    const rx = Math.cos(v.yaw), rz = -Math.sin(v.yaw);
    this.pos.set(v.pos.x + rx * (VKINDS[v.kind].r + 0.7), v.pos.y, v.pos.z + rz * (VKINDS[v.kind].r + 0.7));
    this.move(this.pos, 0, 0, 0.35, 1.75);
    this.equip(this.current, true);
  }

  updateDriving(dt: number) {
    const v = this.driving!;
    const K = VKINDS[v.kind];
    const inp = this.input;
    const sens = 0.0022 * this.sensitivity;
    this.yaw -= inp.lookX * sens;
    this.pitch -= inp.lookY * sens * (this.invertY ? -1 : 1);
    this.pitch = THREE.MathUtils.clamp(this.pitch, -1.2, 1.2);
    inp.lookX = inp.lookY = 0;
    const k = inp.keys;
    let th = inp.moveY, st = inp.moveX;
    if (k.has("KeyW") || k.has("ArrowUp")) th += 1;
    if (k.has("KeyS") || k.has("ArrowDown")) th -= 1;
    if (k.has("KeyA") || k.has("ArrowLeft")) st -= 1;
    if (k.has("KeyD") || k.has("ArrowRight")) st += 1;
    th = THREE.MathUtils.clamp(th, -1, 1);
    st = THREE.MathUtils.clamp(st, -1, 1);
    // physics
    if (th > 0) v.speed += K.acc * th * dt;
    else if (th < 0) v.speed += (v.speed > 0.5 ? K.acc * 1.6 : K.acc * 0.8) * th * dt;
    v.speed -= v.speed * 0.5 * dt;
    if (Math.abs(v.speed) < 0.05 && th === 0) v.speed = 0;
    v.speed = THREE.MathUtils.clamp(v.speed, -K.rev, K.max);
    const sp = Math.abs(v.speed);
    if (sp > 0.3) {
      const dYaw = -st * K.turn * dt * THREE.MathUtils.clamp(sp / 8, 0.3, 1) * Math.sign(v.speed);
      v.yaw += dYaw;
      this.yaw += dYaw; // camera follows the turn
    }
    const dx = -Math.sin(v.yaw) * v.speed * dt, dz = -Math.cos(v.yaw) * v.speed * dt;
    const ox = v.pos.x, oz = v.pos.z;
    this.move(v.pos, dx, dz, K.r, 1.5);
    const intended = Math.hypot(dx, dz), moved = Math.hypot(v.pos.x - ox, v.pos.z - oz);
    if (intended > 0.001 && moved < intended * 0.35) {
      if (sp > 6 && this.crashCD <= 0) {
        this.crashCD = 0.8;
        audio.carThud();
        this.shakeT = 0.3;
        if (sp > 14) this.damagePlayer(6);
      }
      v.speed *= -0.15;
    }
    if (this.crashCD > 0) this.crashCD -= dt;
    v.pos.y = this.level.groundAt(v.pos.x, v.pos.z, v.pos.y + 0.3);
    // run over zombies
    if (sp > 3.5) {
      for (const z of this.zombies) {
        if (!z.alive || Math.abs(z.pos.y - v.pos.y) > 1.5) continue;
        const d = Math.hypot(z.pos.x - v.pos.x, z.pos.z - v.pos.z);
        if (d < K.r + 0.55) {
          const dir = this.tmpV.set(z.pos.x - v.pos.x, 0, z.pos.z - v.pos.z).normalize();
          z.knock(dir, this.zworld, 1.2);
          audio.carThud();
          this.spawnBurst(z.pos.x, z.pos.y + 1.2, z.pos.z, 10, [0.45, 0.02, 0.02], 3);
          if (z.damage(25 + sp * 5, this.zworld)) this.onKill(z);
          v.speed *= 0.82;
          this.ui.hitT = performance.now();
        }
      }
    }
    // noise attracts
    this.engineSndT -= dt;
    if (this.engineSndT <= 0) {
      this.engineSndT = 0.5;
      if (sp > 6 && K.eng) for (const z of this.zombies) if (z.alive && z.pos.distanceTo(v.pos) < 26) z.hear(v.pos, this.zworld);
    }
    // sounds
    if (K.eng) audio.setEngine(K.eng, sp / K.max);
    else {
      this.stepDist += moved;
      if (sp > 2 && this.stepDist > 1.4) { this.stepDist = 0; audio.bikeTick(); }
    }
    // visuals
    for (const w of v.wheels) w.rotation.x += (v.speed * dt) / 0.34;
    v.group.position.copy(v.pos);
    v.group.rotation.y = v.yaw;
    v.group.rotation.z = (v.kind === "bicycle" || v.kind === "moto") ? st * THREE.MathUtils.clamp(sp / K.max, 0, 1) * 0.25 : 0;
    // player follows
    this.pos.copy(v.pos);
    this.camera.position.set(v.pos.x, v.pos.y + K.seatH + Math.sin(performance.now() * 0.02) * 0.012 * (sp / K.max), v.pos.z);
    let shake = 0;
    if (this.shakeT > 0) { this.shakeT -= dt; shake = this.shakeT * 0.12; }
    this.camera.position.y += (Math.random() - 0.5) * shake;
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    const tf = this.baseFov + (sp / K.max) * 12;
    if (Math.abs(this.camera.fov - tf) > 0.1) { this.camera.fov += (tf - this.camera.fov) * Math.min(1, dt * 6); this.camera.updateProjectionMatrix(); }
    audio.setListener(this.pos.x, this.pos.y + 1.4, this.pos.z, -Math.sin(this.yaw), -Math.cos(this.yaw));
    // interact (exit / nothing else while driving)
    this.ui.prompt = "Get off " + VKINDS[v.kind].name;
    if (inp.interact || k.has("KeyE")) { inp.interact = false; k.delete("KeyE"); this.exitVehicle(); }
  }

  // ---------- CHAPTER 2 MISSIONS ----------
  /** Mission status: 0 = not taken, 1 = active, 2 = objective done (turn in), 3 = complete. */
  mStatus(id: number): number { return this.mst[id] ?? 0; }

  // ================= SCENE DRESSING (visual upgrade) =================
  /** Populate the world with vegetation, atmosphere and god rays. Called once per level load. */
  dressScene() {
    const lv = this.level;
    const p = this.preset;
    this.vegetation = new VegetationField(p.id);
    // Plants only grow on the outdoor terrain: flat ground (y ~ 0) outside the school footprint.
    const inSchool = (x: number, z: number) => x > -32 && x < 32 && z > -14 && z < 14;
    const areas: [number, number, number, number][] = [
      [12, -36, 44, 120], [-40, 8, 28, 60], [150, 30, 70, 150], [80, -80, 55, 90], [210, -60, 60, 110],
    ];
    for (const [cx, cz, r, n] of areas) {
      this.vegetation.populate({
        center: [cx, cz], radius: r, count: Math.round(n * p.vegetation),
        // only outdoor ground counts as soil
        groundAt: (x, z) => (inSchool(x, z) ? -99 : lv.groundAt(x, z, 1)),
      });
    }
    lv.root.add(this.vegetation.group);

    this.dust = new ParticleField({
      count: Math.round(160 * p.particleScale), area: [30, 12, 30],
      color: 0xb9c2d4, size: 0.028, mode: "dust", rise: 0.05,
    });
    this.scene.add(this.dust.points);

    if (p.godRays) {
      for (const [x, z, h] of [[-24, 10.2, 4], [-6, 10.2, 4], [8, 10.2, 4], [24, 4, 6]] as [number, number, number][]) {
        const shaft = lightShaft(0.5, 1.5, h, 0xffe6bc, 0.045);
        shaft.position.set(x, h / 2 - 0.2, z);
        shaft.rotation.z = 0.16;
        this.scene.add(shaft);
      }
    }
  }
  mAvailable(id: number) { return this.mStatus(id) === 0 && prereqs(id).every((p) => this.mStatus(p) === 3); }
  mActiveAny() { return MISSIONS.find((m) => this.mStatus(m.id) === 1 || this.mStatus(m.id) === 2) ?? null; }
  spawnPack(prefix: string, pack: [number, number, number, boolean?][]) {
    pack.forEach((sp, i) => { const id = prefix + "-" + i; if (!this.deadIds.has(id) && !this.zombies.find((z) => z.id === id)) this.spawnZombie(id, V(sp[0], 0, sp[1]), sp[2], !!sp[3]); });
  }
  packFor(id: number) { return ({ 1: M1_SPAWNS, 3: M3_SPAWNS, 4: M4_SPAWNS } as Record<number, [number, number, number, boolean?][]>)[id]; }
  startMission(id: number) {
    const m = MISSIONS[id - 1];
    this.mst[id] = 1; this.mkills[id] = 0;
    const pack = this.packFor(id);
    if (pack) this.spawnPack("mx" + id, pack);
    if (id === 1) { // the pharmacy crossing pack converges on the crossing
      for (const z of this.zombies) if (z.id.startsWith("mx1")) { z.state = "investigate"; z.lastKnown.set(78, 0, 22); }
    }
    if (id === 4) { // the horde blocks the road to the pier
      for (const z of this.zombies) if (z.id.startsWith("mx4")) { z.state = "investigate"; z.lastKnown.set(235, 0, 53); }
    }
    this.toast(`MISSION ${id}: ${m.title}`);
    this.squadSay("mission_start", undefined, 2);
    this.updateObjective(); this.save();
  }
  completeMission(id: number) {
    const m = MISSIONS[id - 1];
    this.mst[id] = 3;
    // rewards
    switch (id) {
      case 1: this.ammo.pistol.reserve += 24; break;
      case 2: this.vehiclesUnlocked = true; break;
      case 3: this.evacConfirmed = true; this.ammo.rifle.reserve += 60; break;
      case 4: this.health = 100; for (const w of this.owned) this.ammo[w].reserve += WEAPONS[w].pickupAmmo; break;
    }
    audio.pickup();
    this.toast(`MISSION COMPLETE: ${m.title} — ${m.reward}`);
    this.squadSay("mission_done", undefined, 2);
    this.updateObjective();
    if (this.mode === "playing" || this.mode === "paused") this.save();
  }
  /** Called from onKill for kill-zone missions. */
  missionKill(z: Zombie) {
    for (const m of MISSIONS) {
      if (m.type !== "kill" || !m.area || this.mst[m.id] !== 1) continue;
      // the mission's own pack always counts; other infected only inside the zone
      const own = z.id.startsWith("mx" + m.id);
      const inZone = own || Math.hypot(z.pos.x - m.area.x, z.pos.z - m.area.z) < m.area.r;
      if (!inZone) continue;
      this.mkills[m.id] = (this.mkills[m.id] || 0) + 1;
      if (this.mkills[m.id] >= (m.need || 1)) {
        this.mst[m.id] = 2;
        // no turn-in point (missions 3 and 4 resolve on the spot)
        if (!m.ret) this.completeMission(m.id);
        this.toast(m.ret ? `${m.title}: objective done — return to ${m.giver}` : `${m.title}: objective done!`);
        this.squadSay("mission_done", undefined, 2);
      } else this.toast(`${m.title}: ${this.mkills[m.id]}/${m.need}`);
      this.updateObjective();
    }
  }
  /** Called each frame for reach missions. */
  missionReachCheck() {
    for (const m of MISSIONS) {
      if (m.type !== "reach" || this.mst[m.id] !== 1) continue;
      if (Math.hypot(this.pos.x - m.wp.x, this.pos.z - m.wp.z) < 4) {
        // reach missions resolve on the spot (dialogue line from Akhil/squad), then complete
        this.toast(m.done);
        voice.sayText("akhil", m.done.slice(0, 160));
        this.completeMission(m.id);
      }
    }
  }
  /** Mission dialog shared by all givers (returns true if it produced a dialog). */
  missionDialog(giver: "MINA" | "RAVI" | "ASTRA", D: (name: string, text: string, options: string[], acts: (() => void)[]) => void, close: () => void): boolean {
    const mine = MISSIONS.filter((m) => m.giver === giver);
    // turn-ins first
    for (const m of mine) if (this.mst[m.id] === 2 && m.ret) {
      D(giver, m.done, ["Hand it over / report in"], [() => this.completeMission(m.id)]);
      return true;
    }
    for (const m of mine) if (this.mst[m.id] === 1) {
      const prog = m.type === "kill" ? ` (${this.mkills[m.id] || 0}/${m.need})` : "";
      D(giver, `Still working on it? ${m.title}${prog}. ${m.wp.label} — you've got this.`, ["On it"], [close]);
      return true;
    }
    // final mission: Mina gives M10 when 9 is done
    for (const m of mine) if (this.mAvailable(m.id) && !this.mActiveAny()) {
      const brief = m.id === 10 ? (this.squadMode ? "Everyone's here. " : "") + m.brief : m.brief;
      D(m.id === 10 ? "MINA" : giver, brief, [m.id === 10 ? "Let's go. All of us." : `Accept — ${m.title}`, "Not yet"], [() => { this.startMission(m.id); if (m.id === 10) { this.toast("DRIVE TO THE HARBOR. The boat will not wait."); this.squadSay("vehicle", undefined, 2); } }, close]);
      return true;
    }
    return false;
  }

  // ---------- NPC dialog ----------
  openDialog(id: string) {
    const D = (name: string, text: string, options: string[], acts: (() => void)[]) => {
      this.ui.dialog = { name, text, options };
      this.dialogActs = acts;
      this.input.fire = false;
      if (document.pointerLockElement) document.exitPointerLock();
    };
    const close = () => { this.ui.dialog = null; };
    if (id === "mina") {
      // --- MISSION 1: RESCUE MISSION (offer / progress / turn-in) ---
      if (this.mStatus(1) === 0) {
        D("MINA", (this.squadMode ? "Four of you came out of the school?! Nobody comes out of there..." : "You came out of the school?! Alone?! Nobody comes out of there...") + " I'm Mina. My little sister Astra is trapped in the pharmacy across the avenue — the crossing is crawling with infected. Clear them out and I'll get her out. Please. She's eleven.", ["Accept — rescue mission (6 infected)", "Not right now"], [
          () => {
            this.startMission(1);
            M1_SPAWNS.forEach((sp, i) => { const zid = "m1-" + i; if (!this.deadIds.has(zid)) this.spawnZombie(zid, V(sp[0], 0, sp[1]), sp[2], !!sp[3]); });
            this.toast("MISSION: RESCUE MISSION — clear the pharmacy crossing (0/6)");
            this.squadSay("mission_start", undefined, 2);
            this.updateObjective(); this.save();
          },
          close,
        ]);
      } else if (this.mStatus(1) === 1) {
        D("MINA", `Those things are still prowling the pharmacy crossing (${this.mkills[1] || 0}/6). Astra won't open the door until it's quiet.`, ["I'm on it"], [close]);
      } else if (this.mStatus(1) === 2) {
        D("MINA", "You actually did it! Astra's unbolting the door already. Here — my dad's CITY MAP. Everything's marked: the hideout, the garage, the harbor. And thank you. For my sister.", ["Take the city map"], [
          () => {
            this.completeMission(1);
            if (!this.keys.includes("city_map")) this.keys.push("city_map");
            this.ammo.pistol.reserve += 24;
            audio.pickup();
            this.toast("ASTRA IS SAFE · City Map acquired — press M / MAP to view it");
            this.toast("+24 9mm from Mina");
            this.squadSay("mission_done", undefined, 2);
            this.updateObjective(); this.save();
          },
        ]);
      } else if (!this.missionDialog("MINA", D, close)) {
        D("MINA", this.mStatus(4) === 3 ? "You did it. The road's open. Get on the boat before I cry in front of my sister." : "Ravi's garage — up the street, past the old hideout. Tell him Mina sent you. He knows about the toolbox.", ["Leave"], [close]);
      }
    } else if (id === "ravi") {
      // --- MISSION 2: TOOLBOX RECOVERY ---
      if (this.mStatus(2) === 0) {
        D("RAVI", "Mina's runner, huh? Good. I need a favour before any boat leaves this city. My TOOLBOX — the big red one — got dragged off by looters into the minimart storeroom by the gas station. Bring it back and every set of wheels out there is yours. Cars, bikes, all of it.", ["Accept — recover the toolbox", "Maybe later"], [
          () => {
            this.startMission(2);
            this.toast("MISSION: TOOLBOX RECOVERY — minimart storeroom");
            this.updateObjective(); this.save();
          },
          close,
        ]);
      } else if (this.mStatus(2) === 1 && !this.keys.includes("toolbox")) {
        D("RAVI", "Minimart. Storeroom. Big red TOOLBOX. The bicycles out there need no key if you want wheels right now.", ["On my way"], [close]);
      } else if (this.mStatus(2) === 2) {
        D("RAVI", "My tools! Give me two minutes... aand done. Jump pack's charged — the sedans, my bike, even this sports car: ALL YOURS.", ["Take the keys"], [
          () => {
            this.completeMission(2);
            this.vehiclesUnlocked = true;
            this.keys = this.keys.filter((kk) => kk !== "toolbox");
            audio.unlock();
            this.toast("ALL VEHICLES UNLOCKED — ride anything you find.");
            this.squadSay("vehicle", "mahesh", 2);
            this.updateObjective(); this.save();
          },
        ]);
      } else if (!this.missionDialog("RAVI", D, close)) {
        D("RAVI", "Pedal to the floor, kid. The pier is east — follow the big street past the roadblock.", ["Leave"], [close]);
      }
    } else if (id === "astra") {
      if (this.mStatus(1) < 2) {
        D("ASTRA", "(a small voice behind the pharmacy counter) Go away! Mina said don't open the door until it's quiet!", ["Stay hidden, we'll clear them"], [close]);
        voice.say("astra", "idle_chat", { cooldown: 5, priority: 2, force: true });
      } else {
        D("ASTRA", "You made it quiet! I counted the groans — there were six and now there's none. Mina says I'm the lookout. I'm a really good lookout. Is the boat big?", ["Go find your sister at the gas station", "Leave"], [
          () => { close(); this.toast("Astra will meet Mina at the gas station."); },
          close,
        ]);
        voice.say("astra", "greet", { cooldown: 5, priority: 2, force: true });
      }
    }
  }

  dialogChoose(i: number) {
    const act = this.dialogActs[i];
    this.ui.dialog = null;
    this.dialogActs = [];
    act?.();
    if (!this.isTouch && this.mode === "playing" && !this.ui.dialog) this.lockPointer();
  }

  // ---------- city stage ----------
  applyCityStage() {
    if (this.stage < 3) return;
    // tear the barricade open
    if (this.level.barricadeBox) {
      const i = this.level.colliders.indexOf(this.level.barricadeBox);
      if (i >= 0) { this.level.colliders.splice(i, 1); this.buildBoxes(); }
      this.level.barricade.visible = false;
    }
    this.vehiclesUnlocked = this.mStatus(2) === 3;
    if (!this.cityActive) {
      this.cityActive = true;
      CITY_SPAWNS.forEach((s, i) => { const id = "cz" + i; if (!this.deadIds.has(id)) this.spawnZombie(id, V(s[0], 0, s[1]), s[2], !!s[3]); });
      ROADBLOCK_SPAWNS.forEach((s, i) => { const id = "rb" + i; if (!this.deadIds.has(id)) this.spawnZombie(id, V(s[0], 0, s[1]), s[2], !!s[3]); });
      if (this.mStatus(1) === 1) M1_SPAWNS.forEach((sp, i) => { const id = "m1-" + i; if (!this.deadIds.has(id)) this.spawnZombie(id, V(sp[0], 0, sp[1]), sp[2], !!sp[3]); });
      for (const m of MISSIONS) if (this.mst[m.id] === 1) { const pk = this.packFor(m.id); if (pk) this.spawnPack("mx" + m.id, pk); }
    }
    this.leftSchool = this.pos.x > 31;
  }

  waypointTarget(): { x: number; y: number; z: number; label: string } | null {
    if (this.stage < 3) return this.schoolWaypoint();
    if (this.stage >= 9) {
    }
    if (this.stage >= 8) return null;
    if (!this.leftSchool) return { x: 29, y: 1.5, z: 0, label: "EXIT THE SCHOOL" };
    if (this.mStatus(1) === 0) return { x: GAS_STATION.x + 0.5, y: 1.5, z: GAS_STATION.z - 1.5, label: "SURVIVOR — MINA" };
    if (this.mStatus(2) === 0) return { x: GARAGE.x - 3, y: 1.5, z: GARAGE.z - 9, label: "RAVI'S GARAGE" };
    // extended chain
    const act = this.mActiveAny();
    if (act) {
      const st = this.mStatus(act.id);
      if (st === 2 && act.ret) return act.ret;
      return act.wp;
    }
    const next = MISSIONS.find((m) => this.mAvailable(m.id));
    if (next) {
      const giverPos: Record<string, { x: number; z: number }> = { MINA: { x: 48, z: 28 }, RAVI: { x: 104, z: 55 }, ASTRA: { x: 82.5, z: 25.5 } };
      const g = giverPos[next.giver] || giverPos.MINA;
      return { x: g.x, y: 1.5, z: g.z, label: `TALK TO ${next.giver === "EVERYONE" ? "MINA" : next.giver} — ${next.title}` };
    }
    return { x: HARBOR.x, y: 2, z: HARBOR.z, label: "HARBOR EVAC" };
  }

  schoolWaypoint(): { x: number; y: number; z: number; label: string } | null {
    if (this.stage === 2) return { x: 12, y: 5, z: 2, label: "ROOF ACCESS" };
    if (this.stage === 1) return null;
    if (!this.owned.length) return { x: -28, y: 0.8, z: 6.4, label: "PISTOL — TEACHER'S DESK" };
    if (this.keys.includes("key_office")) return { x: -9, y: 5.2, z: -2, label: "SCHOOL OFFICE" };
    if (this.keys.includes("key_principal")) return { x: -21, y: 5.2, z: -2, label: "PRINCIPAL'S OFFICE" };
    if (this.readNotes.has("n4") || this.readNotes.has("n5") || this.readNotes.has("n3")) return { x: 7, y: 1, z: 3.6, label: "LIBRARY — KEYS" };
    if (this.keys.includes("key_janitor") && !this.owned.includes("shotgun")) return { x: -2, y: 1.2, z: -2, label: "SECURITY ROOM" };
    if (this.owned.includes("pistol") && !this.keys.includes("key_janitor")) return { x: -9, y: 1.2, z: 2, label: "SCIENCE LAB" };
    return { x: -12, y: 5.2, z: -10, label: "MILITARY RADIO" };
  }

  playChapter2End() {
    this.mode = "ending";
    this.ui.letterbox = true;
    this.ui.canSkip = true;
    this.ui.prompt = null;
    this.input.fire = false;
    this.vmGroup.visible = false;
    if (this.driving) this.exitVehicle();
    if (document.pointerLockElement) document.exitPointerLock();
    audio.stopSpeech();
    this.clearActors();
    this.cutsceneEnd = null;
    this.clearActors();
    this.boat.visible = false;
    this.boatLight.intensity = 0;
    audio.stopSpeech();
    this.stage = 8;
    this.mode = "complete";
    this.ui.letterbox = false;
    this.ui.canSkip = false;
    this.ui.bigText = null;
    this.ui.subtitle = null;
    this.ui.fade = 1;
    this.pos.set(300, 0, 55);
    this.yaw = Math.PI / 2;
    this.pitch = 0;
    this.placeSquad();
    this.updateObjective();
    this.save();
  }

  buildHeli() {
    const mil = new THREE.MeshLambertMaterial({ color: 0x39412a });
    const dark = new THREE.MeshLambertMaterial({ color: 0x1e2218 });
    const glass = new THREE.MeshLambertMaterial({ color: 0x182430, emissive: 0x101a26, emissiveIntensity: 0.5 });
    const bx = (m: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m);
      mesh.position.set(x, y, z);
      this.heli.add(mesh);
      return mesh;
    };
    bx(mil, 0, 0, 0, 2.0, 1.6, 4.2); // cabin
    bx(glass, 0, 0.15, -2.2, 1.7, 1.0, 0.7); // cockpit glass
    bx(mil, 0, -0.1, -2.6, 1.6, 1.0, 0.6); // nose
    bx(mil, 0, 0.45, 3.6, 0.7, 0.7, 3.6); // tail boom
    bx(mil, 0, 1.1, 5.2, 0.15, 1.4, 0.9); // fin
    bx(mil, 0, 0.5, 5.0, 2.0, 0.15, 0.5); // stabilizer
    bx(dark, -0.9, -1.15, 0, 0.18, 0.18, 3.6); // skids
    bx(dark, 0.9, -1.15, 0, 0.18, 0.18, 3.6);
    bx(dark, -0.9, -0.85, -1.0, 0.12, 0.5, 0.12);
    bx(dark, 0.9, -0.85, -1.0, 0.12, 0.5, 0.12);
    bx(dark, -0.9, -0.85, 1.0, 0.12, 0.5, 0.12);
    bx(dark, 0.9, -0.85, 1.0, 0.12, 0.5, 0.12);
    bx(dark, 0, 0.95, 0, 0.5, 0.35, 1.2); // engine housing
    const rotor = new THREE.Group();
    rotor.position.set(0, 1.2, 0);
    const b1 = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.06, 0.34), dark);
    const b2 = b1.clone();
    b2.rotation.y = Math.PI / 2;
    rotor.add(b1, b2);
    this.heli.add(rotor);
    this.heliRotor = rotor;
    const tr = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.6, 0.2), dark);
    tr.position.set(0.18, 1.1, 5.2);
    this.heli.add(tr);
    this.heliTailRotor = tr;
    this.heliBlink = bx(new THREE.MeshBasicMaterial({ color: 0xff2222 }), 0, 1.0, 4.9, 0.12, 0.12, 0.12);
    bx(new THREE.MeshBasicMaterial({ color: 0x22ff44 }), 1.05, 0, -1.5, 0.1, 0.1, 0.1);
    bx(new THREE.MeshBasicMaterial({ color: 0xff4444 }), -1.05, 0, -1.5, 0.1, 0.1, 0.1);
    this.heliSpot = new THREE.SpotLight(0xfff6dd, 0, 90, 0.32, 0.5, 1.1);
    this.heliSpot.position.set(0, -0.9, -1.8);
    this.heli.add(this.heliSpot);
    this.heli.add(this.heliSpot.target);
    this.heliSpot.target.position.set(0, -20, -8);
    const cone = new THREE.Mesh(
      new THREE.CylinderGeometry(0.15, 3.4, 16, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xfff2cc, transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false })
    );
    cone.position.set(0, -8.9, -4.8);
    cone.rotation.x = 0.33;
    this.heli.add(cone);
    this.heliCone = cone;
    cone.visible = false;
    this.heli.scale.setScalar(1.6);
    this.heli.visible = false;
    this.scene.add(this.heli);
  }

  buildDust() {
    const N = 90;
    const pos = new Float32Array(N * 3);
    this.dustVel = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 14;
      pos[i * 3 + 1] = Math.random() * 5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 14;
      this.dustVel[i] = 0.04 + Math.random() * 0.1;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    this.dustPts = new THREE.Points(g, new THREE.PointsMaterial({ color: 0x8890a8, size: 0.025, transparent: true, opacity: 0.5, depthWrite: false }));
    this.dustPts.frustumCulled = false;
    this.scene.add(this.dustPts);
  }

  updateDust(dt: number) {
    const pos = this.dustPts.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    const c = this.camera.position;
    const t = performance.now() / 1000;
    for (let i = 0; i < this.dustVel.length; i++) {
      arr[i * 3 + 1] -= this.dustVel[i] * dt;
      arr[i * 3] += Math.sin(t * 0.5 + i) * 0.02 * dt;
      // wrap around camera
      for (let k = 0; k < 3; k++) {
        const ck = k === 0 ? c.x : k === 1 ? c.y : c.z;
        const span = k === 1 ? 5 : 14;
        if (arr[i * 3 + k] < ck - span / 2) arr[i * 3 + k] += span;
        else if (arr[i * 3 + k] > ck + span / 2) arr[i * 3 + k] -= span;
      }
    }
    pos.needsUpdate = true;
  }

  makeEntranceGlass() {
    for (const z of [-0.75, 0.75]) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.08, 3, 1.45), new THREE.MeshLambertMaterial({ color: 0x557788, transparent: true, opacity: 0.35 }));
      m.position.set(29.9, 1.5, z);
      this.entranceGlass.add(m);
    }
    this.scene.add(this.entranceGlass);
  }

  buildBoxes() {
    const lv = this.level;
    const list = [...lv.colliders, ...lv.slabs.map((s) => ({ minx: s.minx, maxx: s.maxx, minz: s.minz, maxz: s.maxz, miny: s.top - 0.2, maxy: s.top }))];
    this.boxes = new Float32Array(list.length * 6);
    list.forEach((b, i) => this.boxes.set([b.minx, b.miny, b.minz, b.maxx, b.maxy, b.maxz], i * 6));
  }

  setQuality(q: number) {
    this.quality = q;
    localStorage.setItem(QUALITY_KEY, String(q));
    this.preset = PRESETS[Math.max(0, Math.min(PRESETS.length - 1, q))];
    this.applyQuality();
  }

  applyQuality() {
    const p = this.preset;
    const dpr = window.devicePixelRatio || 1;
    this.renderer.setPixelRatio(Math.min(dpr, p.pixelRatio));
    this.renderer.shadowMap.enabled = p.shadows;
    // light budget (nearest-N selection happens per-frame in update)
    this.lightBudget = p.lightBudget;
    this.lightCullT = 0;
    this.camera.far = p.id === 0 ? 46 : p.id === 1 ? 66 : 88;
    this.camera.updateProjectionMatrix();
    this.dustPts.visible = p.particleScale > 0.3;
    this.setupSun(p);
    if (!this.pipeline) this.pipeline = new RenderPipeline(this.scene, this.camera, this.renderer, p);
    else this.pipeline.setPreset(p);
    this.pipeline.setSize(window.innerWidth, window.innerHeight);
    this.resize();
  }

  /** Key light + shadow frustum sized to the current preset. */
  setupSun(p: GfxPreset) {
    if (!this.sun) {
      this.sun = new THREE.DirectionalLight(0xffe9cc, 0);
      this.sun.position.set(-42, 62, 34);
      this.scene.add(this.sun);
      this.scene.add(this.sun.target);
    }
    const s = this.sun;
    s.castShadow = p.shadows;
    if (p.shadows) {
      s.shadow.mapSize.set(p.shadowMap, p.shadowMap);
      const d = p.shadowDistance;
      const cam = s.shadow.camera as THREE.OrthographicCamera;
      cam.left = -d; cam.right = d; cam.top = d; cam.bottom = -d;
      cam.near = 1; cam.far = d * 3.2;
      cam.updateProjectionMatrix();
      s.shadow.bias = -0.0006;
      s.shadow.normalBias = 0.035;
      s.shadow.radius = p.softShadows ? 2.4 : 1;
    }
    s.visible = false;
    s.intensity = 0;
  }

  resize = () => {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.vmCam.aspect = w / h;
    this.vmCam.updateProjectionMatrix();
    this.pipeline?.setSize(w, h);
  };

  // ---------------- game flow ----------------
  hasSave() {
    return !!localStorage.getItem(SAVE_KEY);
  }

  resetWorld() {
    for (const z of this.zombies) this.scene.remove(z.root);
    this.zombies = [];
    for (const p of this.pickups) this.scene.remove(p.mesh);
    this.pickups = [];
    for (const a of this.actors) this.scene.remove(a.h.root);
    this.actors = [];
    this.owned = [];
    this.ammo = { pistol: { mag: 0, reserve: 0 }, shotgun: { mag: 0, reserve: 0 }, rifle: { mag: 0, reserve: 0 } };
    this.current = null;
    this.keys = [];
    this.hasFlashlight = false;
    this.flashOn = false;
    this.health = 100;
    this.taken.clear();
    this.deadIds.clear();
    this.readNotes.clear();
    this.stage = 0;
    this.kills = 0;
    this.surviveTime = 0;
    this.reloadT = this.switchT = 0;
    this.pendingWeapon = undefined;
    this.vel.set(0, 0, 0);
    this.recoilPitch = 0;
    this.ui.subtitle = null; this.ui.bigText = null; this.ui.caption = null; this.ui.note = null; this.ui.choices = null;
    this.ui.letterbox = false;
    this.ui.fade = 0;
    audio.stopAlarm();
    audio.stopStatic();
    audio.stopSpeech();
    for (const d of this.level.doors) {
      d.locked = !!d.keyId;
      d.forceT = 0;
      const lock = d.pivot.getObjectByName("lock");
      if (lock) lock.visible = d.locked;
    }
    this.level.setNormalDay(false);
    this.entranceGlass.visible = false;
    this.scene.fog = new THREE.FogExp2(0x05070a, 0.055);
    this.fogDen = 0.055;
    this.killsAtRadio = 0;
    this.heli.visible = false;
    this.heliSpot.intensity = 0;
    this.heliCone.visible = false;
    audio.stopHeli();
    // chapter 2 state
    this.medkits = 0;
    this.mst = {}; this.mkills = {}; this.evacConfirmed = false; this.ui.newFile = null;
    for (const c of this.companions) this.scene.remove(c.root);
    this.companions = [];
    this.ui.squad = [];
    this.ammoCD = {};
    this.visitedRooms.clear();
    this.curRoom = "";
    voice.clear();
    this.leftSchool = false;
    this.cityActive = false;
    this.vehiclesUnlocked = false;
    this.driving = null;
    audio.setEngine(null, 0);
    for (const v of this.vehicles) {
      v.pos.set(v.spawn.x, 0, v.spawn.z);
      v.yaw = v.spawn.yaw;
      v.speed = 0;
      v.group.position.copy(v.pos);
      v.group.rotation.set(0, v.yaw, 0);
    }
    this.boat.visible = false;
    this.boatLight.intensity = 0;
    this.waySprite.visible = false;
    this.ui.dialog = null;
    this.dialogActs = [];
    // restore barricade collider
    if (this.level.barricadeBox && !this.level.colliders.includes(this.level.barricadeBox)) {
      this.level.colliders.push(this.level.barricadeBox);
      this.buildBoxes();
    }
  }

  newGame() {
    audio.init();
    localStorage.removeItem(SAVE_KEY);
    this.resetWorld();
    this.playPrologue();
  }

  setSquadMode(on: boolean) {
    this.squadMode = on;
    localStorage.setItem("lastfour_squad", on ? "1" : "0");
  }

  /** Chapter select: start a chapter at its intended starting point with a sensible loadout. */
  startChapter(n: 1 | 2) {
    audio.init();
    localStorage.removeItem(SAVE_KEY);
    this.resetWorld();
    if (n === 1) { this.playPrologue(); return; }
    // Chapter 2 — The Escape: Akhil has already survived the school and the rooftop.
    this.stage = 3;
    this.owned = ["pistol", "shotgun"];
    this.ammo.pistol = { mag: 12, reserve: 36 };
    this.ammo.shotgun = { mag: 6, reserve: 12 };
    this.equip("pistol", true);
    this.hasFlashlight = true;
    this.flashOn = true;
    this.medkits = 2;
    this.keys = [];
    this.kills = 0;
    this.surviveTime = 0;
    // mark chapter-1 story beats as done so notes/objectives read correctly
    ["n1", "n2", "n3", "n4", "n5"].forEach((id) => this.readNotes.add(id));
    this.taken.add("pistol0");
    ["c1a", "corridor0", "lab", "staff", "sec", "lib", "corridor1", "prin", "office", "roof", "lobby"].forEach((r) => this.visitedRooms.add(r));
    for (const d of this.level.doors) { d.locked = false; const l = d.pivot.getObjectByName("lock"); if (l) l.visible = false; }
    this.pos.set(22, 0, 0);
    this.yaw = -Math.PI / 2;
    this.pitch = 0;
    this.startGameplay(false);
    this.save();
    this.ui.fade = 1;
    const fadeIn = () => { this.ui.fade = Math.max(0, this.ui.fade - 0.04); if (this.ui.fade > 0) setTimeout(fadeIn, 33); };
    setTimeout(fadeIn, 300);
    this.toast("CHAPTER 2 — THE ESCAPE");
    setTimeout(() => this.toast("The barricade is torn open. Someone is signalling from the gas station up the street..."), 2500);
  }

  continueGame() {
    audio.init();
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return this.newGame();
    this.resetWorld();
    try {
      const s = JSON.parse(raw);
      this.pos.set(s.pos[0], s.pos[1], s.pos[2]);
      this.yaw = s.yaw;
      this.pitch = 0;
      this.health = s.health;
      this.owned = s.owned;
      this.ammo = s.ammo;
      this.equip(s.current ?? null, true);
      this.keys = s.keys;
      this.hasFlashlight = s.hasFlashlight;
      this.flashOn = s.hasFlashlight;
      (s.taken as string[]).forEach((t) => this.taken.add(t));
      (s.dead as string[]).forEach((t) => this.deadIds.add(t));
      (s.notes as string[]).forEach((t) => this.readNotes.add(t));
      this.stage = s.stage;
      this.kills = s.kills;
      this.surviveTime = s.surviveTime || 0;
      this.killsAtRadio = s.killsAtRadio || 0;

      this.medkits = s.medkits || 0;
      if (typeof s.squadMode === "boolean") this.squadMode = s.squadMode;
      (s.visited || []).forEach((r: string) => this.visitedRooms.add(r));
      this.mst = s.mst || {}; this.mkills = s.mkills || {}; this.evacConfirmed = !!s.evac;
      if (s.vehicles) for (const vs of s.vehicles) {
        const v = this.vehicles.find((vv) => vv.id === vs.id);
        if (v) { v.pos.set(vs.x, 0, vs.z); v.yaw = vs.yaw; v.group.position.copy(v.pos); v.group.rotation.set(0, v.yaw, 0); }
      }
      if (this.stage >= 2 && this.stage < 3) audio.startHeli(0.04);
      for (const d of this.level.doors) {
        const st = s.doors[d.id];
        if (st) { d.locked = st.locked; d.open = st.open; d.angle = d.open ? d.openAngle : 0; d.pivot.rotation.y = d.angle; }
        const lock = d.pivot.getObjectByName("lock");
        if (lock) lock.visible = d.locked;
      }
    } catch {
      return this.newGame();
    }
    this.startGameplay(false);
  }

  save() {
    if (this.mode !== "playing" && this.mode !== "paused") return;
    if (this.health <= 0) return;
    const doors: Record<string, { locked: boolean; open: boolean }> = {};
    for (const d of this.level.doors) doors[d.id] = { locked: d.locked, open: d.open };
    const s = {
      pos: [this.pos.x, this.pos.y, this.pos.z], yaw: this.yaw, health: this.health, owned: this.owned, ammo: this.ammo, current: this.current,
      keys: this.keys, hasFlashlight: this.hasFlashlight, taken: [...this.taken], dead: [...this.deadIds], notes: [...this.readNotes],
      stage: this.stage, kills: this.kills, surviveTime: this.surviveTime, killsAtRadio: this.killsAtRadio, doors, squadMode: this.squadMode,
      medkits: this.medkits, visited: [...this.visitedRooms],
      mst: this.mst, mkills: this.mkills, evac: this.evacConfirmed,
      vehicles: this.vehicles.map((v) => ({ id: v.id, x: v.pos.x, z: v.pos.z, yaw: v.yaw })),
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(s));
  }

  spawnWorld() {
    for (const p of this.level.pickups) {
      if (this.taken.has(p.id)) continue;
      this.addPickup(p);
    }
    SPAWNS.forEach((s, i) => {
      const id = "z" + i;
      if (this.deadIds.has(id)) return;
      this.spawnZombie(id, V(s[0], s[1], s[2]), s[3], !!s[4]);
    });
  }

  addPickup(def: PickupDef) {
    const mesh = buildPickupModel(def.kind);
    mesh.position.set(def.x, def.y, def.z);
    mesh.rotation.y = Math.random() * 6;
    // glint
    const glint = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 4), new THREE.MeshBasicMaterial({ color: 0xfff0a0 }));
    glint.position.y = 0.2;
    glint.name = "glint";
    mesh.add(glint);
    this.scene.add(mesh);
    this.pickups.push({ def, mesh, taken: false });
  }

  spawnZombie(id: string, p: THREE.Vector3, lookIdx: number, runner: boolean) {
    const z = new Zombie(id, ZOMBIE_LOOKS[lookIdx % ZOMBIE_LOOKS.length], p, runner);
    this.scene.add(z.root);
    this.zombies.push(z);
    return z;
  }

  startGameplay(fresh: boolean) {
    this.level.setNormalDay(false);
    this.entranceGlass.visible = false;
    this.spawnWorld();
    if (fresh) {
      this.pos.copy(this.level.playerStart);
    }
    this.mode = "playing";
    this.ui.letterbox = false;
    this.ui.canSkip = false;
    audio.startAmbient();
    this.spawnCompanions();
    this.applyCityStage();
    this.updateObjective();
    this.equip(this.current, true);
    if (fresh) this.save();
  }

  updateObjective() {
    if (this.stage === 0) {
      this.ui.objective = "FIND THE MILITARY RADIO";
      let sub = "Search the school. The radio may be in an office.";
      if (!this.owned.length) sub = this.squadMode ? "Take the pistol on the teacher's desk and the medkit in the locker. Then move out with Narendra, Mahesh and Harsha." : "Take the pistol on the teacher's desk and the medkit in the locker. You're on your own — move carefully.";
      else if (this.keys.includes("key_office")) sub = "Unlock the SCHOOL OFFICE (2nd floor) and use the radio.";
      else if (this.keys.includes("key_principal")) sub = "Unlock the PRINCIPAL's office (2nd floor) — find the Office Key.";
      else if (this.readNotes.has("n4") || this.readNotes.has("n5")) sub = "Find the Principal's Key in the Library.";
      else if (this.keys.includes("key_janitor") && !this.owned.includes("shotgun")) sub = "The Janitor's Key opens the SECURITY room.";
      else if (this.owned.includes("pistol") && !this.keys.includes("key_janitor")) sub = "Read notes for clues. Find keys to locked rooms.";
      this.ui.objectiveSub = sub;
    } else if (this.stage === 1) {
      this.ui.objective = "SURVIVE. SECURE THE SCHOOL. WAIT FOR FURTHER ORDERS.";
      const prog = Math.min(8, this.kills - this.killsAtRadio);
      this.ui.objectiveSub = `Repel the infected (${prog}/8) and hold until Bravo Squad calls back.`;
    } else if (this.stage === 2) {
      this.ui.objective = "REACH THE ROOFTOP — EXTRACTION INBOUND";
      this.ui.objectiveSub = "Roof access: stairwell, 2nd floor. The door is unlocked. RUN.";
    } else if (this.stage === 3) {
      if (!this.leftSchool) {
        this.ui.objective = "CHAPTER 2 — LEAVE THE SCHOOL";
        this.ui.objectiveSub = "The entrance barricade is torn open. Head out into the city.";
      } else {
        const act = this.mActiveAny();
        if (act) {
          const st = this.mStatus(act.id);
          this.ui.objective = `MISSION ${act.id}: ${act.title}`;
          const prog = act.type === "kill" ? ` (${this.mkills[act.id] || this.sideKills || 0}/${act.need})` : "";
          this.ui.objectiveSub = st === 2 && act.ret ? `Done — ${act.ret.label}.` : act.id === 10 ? "Drive east. The last boat is holding the pier for minutes, not hours." : `${act.wp.label}${prog}`;
        } else {
          const next = MISSIONS.find((m) => this.mAvailable(m.id));
          this.ui.objective = next ? `NEXT: ${next.title}` : "REACH THE HARBOR EVAC ZONE";
          this.ui.objectiveSub = next ? `Talk to ${next.giver}. ` : "Drive east down the avenue — the LAST BOAT is waiting.";
        }
      }
    } else {
      this.ui.objective = "FREE ROAM — THE CITY IS YOURS";
      this.ui.objectiveSub = "Extraction secured. Loot, ride, survive.";
    }
  }

  pause() {
    if (this.mode !== "playing") return;
    this.mode = "paused";
    this.input.fire = false;
    audio.setEngine(null, 0);
    this.save();
    if (document.pointerLockElement) document.exitPointerLock();
  }

  resume() {
    if (this.mode !== "paused") return;
    this.mode = "playing";
    audio.init();
    if (!this.isTouch) this.lockPointer();
  }

  lockPointer() {
    try { this.canvas.requestPointerLock?.(); } catch { /* ignore */ }
  }

  quitToMenu() {
    this.save();
    this.resetWorld();
    this.mode = "menu";
    if (document.pointerLockElement) document.exitPointerLock();
    this.camera.position.set(20, 3, -8);
    this.camera.lookAt(-10, 1.5, 0);
    this.camera.fov = 72;
    this.camera.updateProjectionMatrix();
    this.vmGroup.visible = false;
  }

  restartFromSave() {
    if (this.hasSave()) this.continueGame();
    else this.newGame();
  }

  toast(text: string) {
    const id = ++this.toastId;
    this.ui.toasts = [...this.ui.toasts.slice(-3), { id, text }];
    setTimeout(() => { this.ui.toasts = this.ui.toasts.filter((t) => t.id !== id); }, 3500);
  }

  // ---------------- cutscenes ----------------
  runShots(shots: Shot[], onEnd: () => void, startAt = 0) {
    this.shots = shots;
    this.shotIdx = Math.min(startAt, shots.length - 1);
    this.shotT = 0;
    this.cutsceneEnd = onEnd;
    shots[this.shotIdx].start?.();
  }

  addActor(zombie: boolean, path: THREE.Vector3[], speed: number, delay = 0, lookIdx = 0) {
    const looks = zombie ? ZOMBIE_LOOKS : [
      { shirt: 0xe8e8e0, pants: 0x1e2a50, skin: 0xc89a74, hair: 0x1a1410, scale: 0.95 },
      { shirt: 0xd8e0f0, pants: 0x2a2a3a, skin: 0x8a5a3a, hair: 0x0a0a0a, scale: 0.92 },
      { shirt: 0x7a4a2a, pants: 0x3a3a3a, skin: 0xd8b090, hair: 0x7a5a3a, scale: 1.05 },
      { shirt: 0xe0d8d0, pants: 0x1a2a4a, skin: 0xb07a50, hair: 0x2a1a0a, scale: 0.9 },
      { shirt: 0x3a6aa0, pants: 0x22262e, skin: 0xc08a64, hair: 0x14100c, scale: 1 }, // Akhil (4)
      { shirt: 0xe6e6e6, pants: 0x3a3f48, skin: 0xd8b494, hair: 0x9a9a9a, scale: 1.02 }, // Scientist, white coat (5)
      { shirt: 0x8a8a7a, pants: 0x8a8a7a, skin: 0xb0a090, hair: 0x2a2a2a, scale: 0.98 }, // Test subject, gown (6)
      { shirt: 0x8a2a2a, pants: 0x22262e, skin: 0xa07050, hair: 0x101010, scale: 1.0 }, // Mahesh (7)
      { shirt: 0x2a6a3a, pants: 0x2a2a3a, skin: 0xc49a74, hair: 0x1a1410, scale: 1.04 }, // Narendra (8)
      { shirt: 0xd0a030, pants: 0x1e2a50, skin: 0x9a6a48, hair: 0x0c0c0c, scale: 0.96 }, // Harsha (9)
    ];
    const h = new Humanoid(looks[lookIdx % looks.length], zombie);
    h.root.position.copy(path[0]);
    h.root.visible = delay <= 0;
    this.scene.add(h.root);
    this.actors.push({ h, path, seg: 0, speed, delay, zombie });
  }

  clearActors() {
    for (const a of this.actors) this.scene.remove(a.h.root);
    this.actors = [];
  }

  updateActors(dt: number) {
    for (const a of this.actors) {
      if (a.delay > 0) { a.delay -= dt; if (a.delay <= 0) a.h.root.visible = true; else continue; }
      if (a.seg >= a.path.length - 1) { a.h.animWalk(dt * 0.2, 0.3, a.zombie); continue; }
      const p = a.h.root.position, t = a.path[a.seg + 1];
      const d = p.distanceTo(t);
      const step = a.speed * dt;
      if (d <= step) { p.copy(t); a.seg++; }
      else p.addScaledVector(this.tmpV.subVectors(t, p).normalize(), step);
      const dir = this.tmpV.subVectors(t, p);
      if (dir.lengthSq() > 0.001) a.h.root.rotation.y = Math.atan2(dir.x, dir.z);
      a.h.animWalk(dt, a.speed, a.zombie);
    }
  }

  // ================= PROLOGUE — THE SCIENTIST =================
  playPrologue() {
    this.mode = "intro";
    this.ui.letterbox = true;
    this.ui.canSkip = true;
    this.vmGroup.visible = false;
    this.inPrologue = true;
    const lv = this.level;
    const LY = lv.labY, LZ = -200;
    const L = (x: number, y: number, z: number) => V(x, LY + y, LZ + z);
    this.scene.fog = new THREE.FogExp2(0x060a0c, 0.02);
    lv.hemi.intensity = 0.9;
    lv.labAlarm.intensity = 0;
    lv.labLight.color.set(0x7ad0e0);
    lv.labLight.intensity = 2.2;
    (lv.labTank.material as THREE.MeshLambertMaterial).emissive.set(0x16404a);
    const say = (who: string, text: string, voice: "soldier" | "operator" | "akhil" | null) => {
      this.ui.subtitle = { who, text };
      if (voice) audio.speak(text, voice);
    };
    let sci: Humanoid, subj: Humanoid;
    const setMon = (c: number) => lv.labMonitors.forEach((m) => (m.material as THREE.MeshBasicMaterial).color.set(c));
    audio.startStatic(0.02);
    this.runShots([
      { // 1. establishing — slow push into the lab
        dur: 6.5, from: [L(7, 2.2, 4), L(-2, 1.2, -1)], to: [L(4, 1.9, 2.5), L(-2, 1.4, -1)],
        start: () => {
          this.ui.caption = "UNDISCLOSED RESEARCH FACILITY — 3 WEEKS BEFORE THE OUTBREAK";
          this.clearActors();
          this.addActor(false, [L(2.5, 0, -2.4)], 0, 0, 5); // scientist at console
          this.addActor(false, [L(-2, 0.25, -1)], 0, 0, 6); // subject in tank
          sci = this.actors[0].h; subj = this.actors[1].h;
          sci.root.rotation.y = Math.PI; // facing monitors (-z)
          subj.root.rotation.y = Math.PI / 2;
          subj.armL.rotation.x = subj.armR.rotation.x = 0.15;
          subj.head.rotation.x = 0.4; // head hung low
          setMon(0x1a4a3a);
        },
        update: () => { lv.labLight.intensity = 2.0 + Math.sin(performance.now() * 0.004) * 0.3; },
      },
      { // 2. over the scientist's shoulder at the monitors
        dur: 6, from: [L(3.4, 2.0, -0.8), L(2.5, 1.2, -3.9)], to: [L(2.8, 1.8, -1.4), L(2.5, 1.2, -3.9)],
        start: () => {
          this.ui.caption = null;
          say("SCIENTIST", "Subject 14. Serum batch nine... the cellular regeneration is holding. Vitals stable.", "soldier");
          sci.armR.rotation.x = -1.2; // hands on console
          sci.armL.rotation.x = -1.1;
        },
        update: (t) => { setMon(t % 0.3 < 0.15 ? 0x1a4a3a : 0x1f5a44); },
      },
      { // 3. the photo on the desk — his motive
        dur: 5.5, from: [L(4.9, 1.5, -2.6), L(4.4, 1.0, -3.5)], to: [L(4.7, 1.25, -3.0), L(4.4, 1.0, -3.5)],
        start: () => {
          say("SCIENTIST", "Three years, Maya. Three years since they put you in the ground. If this works... I will get her back.", "soldier");
          sci.head.rotation.y = 0.5;
        },
      },
      { // 4. subject convulses — it goes wrong
        dur: 6, from: [L(0.5, 1.6, 1.5), L(-2, 1.3, -1)], to: [L(-0.4, 1.4, 0.6), L(-2, 1.5, -1)],
        start: () => {
          say("SCIENTIST", "Wait— heart rate spiking. 160... 190... That's not possible. Shut it down. SHUT IT DOWN!", "soldier");
          setMon(0x8a1a1a);
          sci.root.rotation.y = -Math.PI / 2 + 0.4; // turns toward tank
          audio.radioBeep();
          setTimeout(() => audio.radioBeep(), 500);
          setTimeout(() => audio.radioBeep(), 1000);
          setTimeout(() => audio.groan(L(-2, 1.5, -1), 1.3, true), 2500);
        },
        update: (t, dt) => {
          const k = t * 6;
          subj.body.rotation.z = Math.sin(k * 14) * 0.18 * t;
          subj.head.rotation.x = 0.4 - t * 1.1;
          subj.armL.rotation.x = -t * 1.6; subj.armR.rotation.x = -t * 1.5;
          lv.labLight.intensity = 2.5 + Math.sin(k * 30) * 1.5 * t;
          lv.labLight.color.setHSL(0.52 - t * 0.52, 0.9, 0.55);
          (lv.labTank.material as THREE.MeshLambertMaterial).emissive.setHSL(0.52 - t * 0.5, 0.8, 0.2);
          if (t > 0.75) this.camera.position.x += (Math.random() - 0.5) * 0.02 * dt * 60;
        },
      },
      { // 5. the tank shatters, subject turns, alarm
        dur: 6.5, from: [L(2, 1.5, 1.8), L(-2, 1.3, -1)], to: [L(3.5, 1.7, 2.5), L(0, 1.3, 0)], shake: 0.02,
        start: () => {
          audio.glass(L(-2, 1.5, -1));
          audio.startAlarm();
          lv.labTank.visible = false;
          lv.labAlarm.intensity = 2.5;
          this.spawnBurst(LZ * 0 + -2, LY + 1.5, LZ - 1, 40, [0.5, 0.9, 1.0], 5);
          this.clearActors();
          this.addActor(false, [L(1.2, 0, 0.5), L(5, 0, 2.3), L(7.3, 0, 3)], 3.2, 0.6, 5); // scientist flees to exit
          this.addActor(true, [L(-2, 0, -1), L(0.5, 0, 0.3), L(5, 0, 2.2)], 1.4, 1.2, 1); // subject now infected, shambling after him
          sci = this.actors[0].h;
          say("SCIENTIST", "No... no, no, no. Containment breach — seal the— Oh God. Oh God, what have I done.", "soldier");
          audio.groan(L(-2, 1.5, -1), 1.1, true);
          setTimeout(() => audio.groan(L(0, 1.5, 0), 1.0, true), 2500);
        },
        update: (t) => { lv.labAlarm.intensity = 1.5 + Math.sin(t * 40) * 1.5; lv.labLight.intensity = 0.6; },
      },
      { // 6. black card
        dur: 2, from: [V(0, -500, 0), V(0, -500, 1)], to: [V(0, -500, 0), V(0, -500, 1)],
        start: () => { this.ui.fade = 1; this.ui.subtitle = null; audio.stopAlarm(); audio.stopStatic(); },
      },
      { // 7. the city — outbreak spreading down the avenue
        dur: 7, from: [V(60, 6, 60), V(68, 1, 20)], to: [V(63, 3.5, 40), V(68, 1, 0)],
        start: () => {
          this.ui.fade = 0;
          this.ui.bigText = null;
          this.ui.caption = "RIVERSIDE CITY — 19 DAYS LATER";
          this.clearActors();
          this.scene.fog = new THREE.FogExp2(0x0a0c12, 0.012);
          lv.hemi.intensity = 0.9;
          this.level.setNormalDay(false);
          for (let i = 0; i < 7; i++) this.addActor(false, [V(66 + (i % 3) * 2, 0, 20 - i * 3), V(66 + (i % 3) * 2, 0, -40 - i * 2)], 5 + Math.random(), i * 0.2, i % 5);
          for (let i = 0; i < 9; i++) this.addActor(true, [V(64 + (i % 4) * 2.5, 0, 42 + i * 1.5), V(64 + (i % 4) * 2.5, 0, -30)], 2.2 + Math.random() * 0.8, 0.5 + i * 0.25, i);
          audio.crowd(5);
          audio.startAmbient();
          setTimeout(() => audio.groan(V(66, 1.5, 30), 1, true), 1200);
          setTimeout(() => audio.carThud(), 2500);
          setTimeout(() => audio.glass(V(66, 2, 20)), 3200);
          setTimeout(() => audio.groan(V(66, 1.5, 10), 0.9, true), 4500);
        },
      },
      { // 8. survivors flee past the gas station; infected swarm the junction
        dur: 6, from: [V(40, 2.2, 36), V(55, 1, 45)], to: [V(44, 2.6, 32), V(66, 1, 50)], shake: 0.006,
        start: () => {
          this.ui.caption = null;
          this.clearActors();
          say("", "[radio] ...all units, hospital district has fallen. Infected are moving west on Main. Riverside High School is in their path... repeat, RIVERSIDE HIGH...", "operator");
          for (let i = 0; i < 5; i++) this.addActor(false, [V(70 + i, 0, 51 + (i % 2)), V(20, 0, 51 - (i % 3))], 5.5, i * 0.3, i % 5);
          for (let i = 0; i < 12; i++) this.addActor(true, [V(80 + (i % 4) * 3, 0, 46 + (i % 3) * 4), V(28, 0, 50 + (i % 3) * 2)], 2.4 + Math.random() * 0.9, 1.2 + i * 0.2, i);
          audio.crowd(4);
          setTimeout(() => audio.gunshot("pistol"), 1500);
          setTimeout(() => audio.gunshot("pistol"), 1900);
          setTimeout(() => audio.gunshot("pistol"), 2600);
        },
      },
      { // 9. the school — the four friends run the corridor, zombies behind
        dur: 7, from: [V(-14, 1.7, -1), V(10, 1.3, 0)], to: [V(-18, 1.6, 0.8), V(-26, 1.2, 4)],
        start: () => {
          this.clearActors();
          this.scene.fog = new THREE.FogExp2(0x05070a, 0.04);
          lv.hemi.intensity = 0.6;
          audio.startAlarm();
          audio.crowd(5);
          const into = (i: number) => [V(4 + i * 1.4, 0, (i % 2 ? 0.7 : -0.7)), V(-20.5, 0, 0.5), V(-21, 0, 3.2), V(-23 - (i % 2) * 2, 0, 6 + i * 0.8)];
          this.addActor(false, into(0), 6.0, 0, 4);
          if (this.squadMode) {
            say("AKHIL", "Mahesh! Narendra! Harsha — this way, the classroom! MOVE!", "akhil");
            // Akhil(4), Mahesh(7), Narendra(8), Harsha(9) sprint to Classroom 1A door (-21, 2) and inside
            this.addActor(false, into(1), 5.8, 0.25, 7);
            this.addActor(false, into(2), 5.6, 0.5, 8);
            this.addActor(false, into(3), 5.7, 0.75, 9);
          } else {
            say("AKHIL", "Mahesh?! NARENDRA! Where are you— I can't— I can't see you!", "akhil");
            // the crowd swallows his friends; they run the other way with everyone else
            this.addActor(false, [V(6, 0, 0.8), V(-28, 0, -0.6)], 5.5, 0.3, 7);
            this.addActor(false, [V(8, 0, -0.8), V(-28, 0, 0.6)], 5.4, 0.5, 8);
            this.addActor(false, [V(9.5, 0, 0.5), V(-28, 0, 0)], 5.6, 0.7, 9);
          }
          for (let i = 0; i < 4; i++) this.addActor(false, [V(2 + i * 2, 0, (i % 2 ? 1 : -1) * 0.8), V(-28, 0, -0.5)], 5.2, 0.1 + i * 0.3, i % 4);
          for (let i = 0; i < 7; i++) this.addActor(true, [V(14 + i * 1.6, 0, (i % 3 - 1) * 0.6), V(-28, 0, 0)], 2.6 + Math.random() * 0.6, 1.4 + i * 0.35, i);
          const c1a = lv.doors.find((d) => d.id === "c1a")!;
          c1a.open = true; c1a.angle = c1a.openAngle; c1a.pivot.rotation.y = c1a.angle;
          setTimeout(() => say(this.squadMode ? "MAHESH" : "AKHIL", this.squadMode ? "They're everywhere— Akhil, the door, BLOCK THE DOOR!" : "Okay. Okay. Classroom. Lock the door. Just— just lock the door.", "akhil"), 3800);
        },
        update: () => { lv.lampMat.emissiveIntensity = Math.random() < 0.2 ? 0.1 : 1.1; },
      },
      { // 10. inside Classroom 1A — the four barricade in; a bang on the door; Akhil goes down
        dur: 7.5, from: [V(-27.5, 1.8, 11), V(-21.5, 1.3, 3)], to: [V(-25, 1.6, 9), V(-21, 1.2, 3)], shake: 0.004,
        start: () => {
          this.clearActors();
          const c1a = lv.doors.find((d) => d.id === "c1a")!;
          c1a.open = false; c1a.angle = 0; c1a.pivot.rotation.y = 0;
          if (this.squadMode) {
            this.addActor(false, [V(-23.5, 0, 5.5), V(-22, 0, 3.6)], 2.5, 0, 7); // Mahesh braces the door
            this.addActor(false, [V(-25, 0, 7), V(-22.6, 0, 4.2)], 2.3, 0.2, 8); // Narendra
            this.addActor(false, [V(-26.5, 0, 6), V(-24, 0, 5)], 2.0, 0.3, 9); // Harsha
            say("NARENDRA", "Hold it— HOLD IT! Harsha, the desks, push the desks over!", "akhil");
            setTimeout(() => say("HARSHA", "Akhil? Akhil, you're bleeding— hey. HEY! Stay with us—", "akhil"), 3600);
          } else {
            // solo: Akhil alone drags a desk against the door, then collapses
            this.addActor(false, [V(-22.5, 0, 4), V(-21.6, 0, 3.4)], 1.6, 0, 4);
            this.actors[this.actors.length - 1].delay = 0;
            say("AKHIL", "Come on... come on, hold. Please hold.", "akhil");
            setTimeout(() => say("AKHIL", "My head... why is there so much blood— I just need to sit down. Just for a second.", "akhil"), 3600);
          }
          this.addActor(false, [V(-26, 0, 8.5), V(-27.2, 0, 9.2)], 1.4, this.squadMode ? 0.4 : 2.2, 4); // Akhil staggers to his spot
          setTimeout(() => audio.bang(V(-21, 1, 2)), 1500);
          setTimeout(() => audio.bang(V(-21, 1, 2)), 2200);
          setTimeout(() => audio.bang(V(-21, 1, 2)), 3100);
          setTimeout(() => audio.groan(V(-21, 1.5, 1), 1, true), 4000);
        },
        update: (t) => {
          const ak = this.actors[this.actors.length - 1]?.h;
          if (ak && t > 0.45) { const k = Math.min(1, (t - 0.45) / 0.3); ak.body.rotation.x = k * 1.3; ak.body.position.y = -k * 0.9; ak.head.rotation.x = k * 0.6; }
          if (t > 0.6) this.ui.fade = (t - 0.6) / 0.4;
          lv.lampMat.emissiveIntensity = Math.random() < 0.15 ? 0.1 : 1.0;
        },
      },
    ], () => {
      // chain into the existing Chapter 1 intro (breach, "SOME TIME LATER", wake-up)
      this.inPrologue = false;
      this.ui.subtitle = null;
      this.ui.fade = 1;
      this.clearActors();
      audio.stopAlarm();
      lv.labTank.visible = true;
      lv.labAlarm.intensity = 0;
      this.playIntro(2);
    });
  }

  inPrologue = false;

  playIntro(startAt = 0) {
    this.mode = "intro";
    this.ui.letterbox = true;
    this.ui.canSkip = true;
    this.vmGroup.visible = false;
    this.level.setNormalDay(true);
    this.entranceGlass.visible = true;
    this.scene.fog = new THREE.FogExp2(0x1a1c20, 0.018);
    const lab = this.level.doors.find((d) => d.id === "lab")!;
    const c1a = this.level.doors.find((d) => d.id === "c1a")!;
    const setDoor = (d: Door, open: boolean) => { d.open = open; d.angle = open ? d.openAngle : 0; d.pivot.rotation.y = d.angle; };
    setDoor(lab, false);
    let bangs = 0;
    this.runShots([
      {
        dur: 6, from: [V(-22, 1.7, 0), V(10, 1.4, 0)], to: [V(-14, 1.7, 0.4), V(10, 1.4, -0.5)],
        start: () => {
          audio.bell();
          this.ui.caption = "RIVERSIDE HIGH SCHOOL — 11:42 AM";
          for (let i = 0; i < 6; i++) {
            const x0 = -8 + i * 3.5, z0 = (i % 2 ? 0.8 : -0.8);
            this.addActor(false, [V(x0, 0, z0), V(x0 + (i % 2 ? -10 : 8), 0, z0 * -0.5)], 1.1 + Math.random() * 0.3, 0, i);
          }
        },
      },
      {
        dur: 5, from: [V(21, 1.6, 3), V(30, 1.5, 0)], to: [V(22.5, 1.6, 2), V(30, 1.5, -0.3)],
        start: () => {
          this.ui.caption = null;
          this.clearActors();
          for (let i = 0; i < 4; i++) this.addActor(true, [V(36 + i, 0, -1.5 + i), V(31.2, 0, -1.2 + i * 0.8)], 0.9, i * 0.5, i);
          audio.groan(V(32, 1.5, 0), 0.9);
          setTimeout(() => audio.groan(V(32, 1.5, 1), 0.8), 1500);
          setTimeout(() => audio.bang(V(30, 1.5, 0)), 3000);
          setTimeout(() => audio.bang(V(30, 1.5, 0)), 3800);
          setTimeout(() => audio.bang(V(30, 1.5, 0)), 4500);
        },
        update: () => { this.camera.position.x += (Math.random() - 0.5) * 0.01; },
      },
      {
        dur: 4.5, from: [V(23, 1.4, -3), V(30, 1.2, 0)], to: [V(21, 1.3, -3.5), V(26, 1.2, 0)], shake: 0.03,
        start: () => {
          this.entranceGlass.visible = false;
          audio.glass(V(30, 1.5, 0));
          audio.startAlarm();
          this.spawnBurst(29.8, 1.5, 0, 40, [0.6, 0.8, 0.9], 5);
          this.clearActors();
          for (let i = 0; i < 6; i++) this.addActor(true, [V(31.5, 0, -1.5 + i * 0.6), V(26, 0, -2 + i * 0.8), V(19, 0, (i - 3) * 0.4)], 2.3, i * 0.3, i);
          audio.groan(V(28, 1.5, 0), 1, true);
        },
      },
      {
        dur: 5, from: [V(-12, 1.7, 0.3), V(10, 1.3, 0)], to: [V(-15, 1.7, 0.3), V(10, 1.3, 0)], shake: 0.01,
        start: () => {
          this.clearActors();
          audio.crowd(4);
          for (let i = 0; i < 6; i++) this.addActor(false, [V(4 + i * 1.2, 0, (i % 3 - 1) * 0.6), V(-28, 0, (i % 3 - 1) * 0.5)], 5 + Math.random(), i * 0.15, i);
          for (let i = 0; i < 3; i++) this.addActor(true, [V(14 + i * 1.5, 0, (i - 1) * 0.6), V(-28, 0, 0)], 2.6, 0.8 + i * 0.4, i);
        },
      },
      {
        dur: 4.5, from: [V(-5.5, 1.6, -1.2), V(-9, 1.3, 2)], to: [V(-6, 1.5, -1.4), V(-9, 1.3, 2)],
        start: () => {
          this.clearActors();
          bangs = 0;
          this.addActor(true, [V(-9, 0, 4), V(-9, 0, 2.6), V(-9, 0, 0), V(-4, 0, 0)], 1.6, 2.4, 2);
          this.addActor(false, [V(-1, 0, -0.8), V(-20, 0, 0.5)], 5.5, 1.0, 1);
        },
        update: (t) => {
          const b = Math.floor((t * 4.5) / 0.7);
          if (b > bangs && b <= 3) { bangs = b; audio.bang(V(-9, 1.2, 2)); lab.pivot.rotation.y = 0.08; setTimeout(() => (lab.pivot.rotation.y = 0), 100); }
          if (t * 4.5 > 2.3 && !lab.open) { lab.open = true; audio.door(V(-9, 1, 2)); }
          if (lab.open) { lab.angle += (lab.openAngle - lab.angle) * 0.2; lab.pivot.rotation.y = lab.angle; }
          this.level.lampMat.emissiveIntensity = Math.random() < 0.15 ? 0.1 : 1.2;
        },
      },
      {
        dur: 5, from: [V(17.2, 6.4, -1.5), V(25, 0, 0)], to: [V(17.2, 6.2, 1.2), V(25, 0, 1)],
        start: () => {
          this.clearActors();
          this.level.hemi.intensity = 0.5;
          this.scene.fog = new THREE.FogExp2(0x05070a, 0.04);
          for (let i = 0; i < 9; i++) {
            const sx = 30 + Math.random() * 2, sz = (Math.random() - 0.5) * 3;
            this.addActor(true, [V(sx, 0, sz), V(20 + Math.random() * 8, 0, (Math.random() - 0.5) * 18), V(19, 0, (Math.random() - 0.5) * 2)], 1.4 + Math.random(), i * 0.35, i);
          }
          audio.groan(V(24, 1.5, 0), 1, true);
          setTimeout(() => audio.glass(V(24, 3, 12)), 1500);
        },
        update: () => { this.level.lampMat.emissiveIntensity = Math.random() < 0.3 ? 0 : 0.6; },
      },
      {
        dur: 1.5, from: [V(17.2, 6.2, 1.2), V(25, 0, 1)], to: [V(17.2, 6.2, 1.2), V(25, 0, 1)],
        update: (t) => { this.ui.fade = t; },
      },
      {
        dur: 4, from: [V(0, -50, 0), V(0, -50, 1)], to: [V(0, -50, 0), V(0, -50, 1)],
        start: () => {
          this.clearActors();
          audio.stopAlarm();
          this.ui.fade = 1;
          this.ui.bigText = "SOME TIME LATER...";
          this.level.setNormalDay(false);
          this.level.lampMat.emissiveIntensity = 1;
          this.scene.fog = new THREE.FogExp2(0x05070a, 0.055);
          setDoor(lab, true);
          setDoor(c1a, false);
        },
      },
      {
        dur: 7, from: [V(-27.2, 0.3, 9.2), V(-27.0, 4, 9.0)], to: [V(-27.2, 1.6, 9.2), V(-21, 1.4, 2)],
        start: () => {
          this.ui.bigText = null;
          this.ui.letterbox = false;
          audio.startAmbient();
          setTimeout(() => audio.bang(V(-21, 1, 2)), 2500);
          setTimeout(() => audio.groan(V(-19, 1.5, 0), 0.9), 3500);
        },
        update: (t) => {
          // blinking eyes
          const k = t * 7;
          this.ui.fade = k < 1 ? 1 - k * 0.6 : k < 1.6 ? 0.4 + (k - 1) * 1 : k < 2.6 ? 1 - (k - 1.6) * 0.9 : k < 3.0 ? 0.1 + (k - 2.6) * 1.5 : Math.max(0, 0.7 - (k - 3) * 0.5);
        },
      },
    ], () => {
      this.ui.fade = 0;
      const d = this.tmpV.set(-21 + 27.2, 0, 2 - 9.2);
      this.yaw = Math.atan2(-d.x, -d.z);
      this.pitch = -0.05;
      this.startGameplay(true);
      this.wakeUpScene();
    }, startAt === 2 ? 7 : 0);
  }

  wakeUpScene() {
    if (!this.squadMode) {
      this.toast("You wake up alone on the classroom floor. Your head is pounding. The school is silent — almost.");
      voice.sayText("akhil", "Mahesh... Narendra... Harsha? ...Anyone? ...Okay. Okay, Akhil. You're on your own. Think.");
      setTimeout(() => { voice.say("akhil", "area", { cooldown: 0, priority: 4, force: true }); this.toast("Search the classroom: there's a PISTOL on the teacher's desk and a MEDKIT in the locker."); }, 7500);
      setTimeout(() => this.toast("OBJECTIVE: FIND THE MILITARY RADIO."), 13000);
      return;
    }
    this.toast("You wake up on the classroom floor. Your head is pounding — but your friends are here.");
    voice.sayText("narendra", "Easy, Akhil. You went down hard. We dragged you in here and barricaded the door.");
    setTimeout(() => voice.say("mahesh", "intro", { cooldown: 0, priority: 4, force: true }), 5200);
    setTimeout(() => voice.say("harsha", "intro", { cooldown: 0, priority: 4, force: true }), 9800);
    setTimeout(() => { voice.say("narendra", "intro", { cooldown: 0, priority: 4, force: true }); this.toast("Grab the PISTOL on the teacher's desk and the MEDKIT in the locker, then move out together."); }, 14000);
    setTimeout(() => this.toast("OBJECTIVE: FIND THE MILITARY RADIO."), 19000);
  }

  /** Chapter 2 complete — free roam in the city. */
  finishChapter2() {
    this.mst[4] = 3;
    this.shots = [];
    this.cutsceneEnd = null;
    this.clearActors();
    this.boat.visible = false;
    this.boatLight.intensity = 0;
    audio.stopSpeech();
    this.stage = 8;
    this.mode = "complete";
    this.ui.letterbox = false;
    this.ui.canSkip = false;
    this.ui.bigText = null;
    this.ui.subtitle = null;
    this.ui.fade = 1;
    this.pos.set(300, 0, 55);
    this.yaw = Math.PI / 2;
    this.pitch = 0;
    this.placeSquad();
    this.updateObjective();
    this.save();
  }

  skipCutscene() {
    if (this.mode === "ending") {
      this.ui.fade = 1;
      if (this.stage >= 3) this.finishChapter2();
      else this.finishEnding();
      return;
    }
    if (this.mode === "intro" && this.shots.length) {
      this.shots = [];
      this.clearActors();
      audio.stopAlarm();
      audio.stopStatic();
      audio.stopSpeech();
      this.ui.subtitle = null;
      this.level.labTank.visible = true;
      this.level.labAlarm.intensity = 0;
      this.level.setNormalDay(false);
      this.level.hemi.intensity = 0.55;
      this.entranceGlass.visible = false;
      if (this.inPrologue) {
        // skipping the prologue: jump straight to the wake-up (skip chapter-1 intro too)
        this.inPrologue = false;
        this.cutsceneEnd = null;
        this.ui.fade = 0;
        this.ui.caption = null;
        this.ui.bigText = null;
        this.scene.fog = new THREE.FogExp2(0x05070a, 0.055);
        this.level.lampMat.emissiveIntensity = 1;
        const c1a = this.level.doors.find((d) => d.id === "c1a")!;
        c1a.open = false; c1a.angle = 0; c1a.pivot.rotation.y = 0;
        const dd = this.tmpV.set(-21 + 27.2, 0, 2 - 9.2);
        this.yaw = Math.atan2(-dd.x, -dd.z);
        this.pitch = -0.05;
        this.startGameplay(true);
        this.wakeUpScene();
        return;
      }
      const lab = this.level.doors.find((d) => d.id === "lab")!;
      lab.open = true; lab.angle = lab.openAngle; lab.pivot.rotation.y = lab.angle;
      const c1a = this.level.doors.find((d) => d.id === "c1a")!;
      c1a.open = false; c1a.angle = 0; c1a.pivot.rotation.y = 0;
      this.ui.bigText = null;
      this.ui.caption = null;
      this.scene.fog = new THREE.FogExp2(0x05070a, 0.055);
      this.level.lampMat.emissiveIntensity = 1;
      const end = this.cutsceneEnd;
      this.cutsceneEnd = null;
      end?.();
    }
  }

  playRadio() {
    this.mode = "radio";
    this.ui.letterbox = true;
    this.ui.prompt = null;
    this.input.fire = false;
    this.adsT = 0;
    this.vmGroup.visible = false;
    if (document.pointerLockElement) document.exitPointerLock();
    const R = this.level.radio.position;
    const eye = V(this.pos.x, this.pos.y + 1.6, this.pos.z);
    const fwd = V(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch));
    const look0 = eye.clone().add(fwd);
    const close = V(R.x + 0.25, R.y + 0.35, R.z + 0.8);
    const rl = V(R.x, R.y + 0.2, R.z);
    audio.radioBeep();
    audio.startStatic(0.3);
    this.radioLines = [
      { who: "SOLDIER", voice: "soldier", text: "Mayday, mayday! This is Bravo Squad. Is anyone inside the school responding?", dur: 5 },
      { who: "RADIO OPERATOR", voice: "operator", text: "We have reports of a major outbreak in your area. Survivors, respond immediately.", dur: 5 },
      { who: "SOLDIER", voice: "soldier", text: "If anyone can hear us, stay inside a secure location. Do not approach the main roads. We are attempting to establish a safe extraction point.", dur: 7.5 },
      { who: "RADIO OPERATOR", voice: "operator", text: "Repeat, this is military command. Identify yourself if you can hear this transmission.", dur: 5, choice: ["\"This is Akhil. I'm trapped inside the school. The building is overrun with infected. I need extraction!\"", "\"Hello?! Can anyone hear me?\""] },
    ];
    let lineIdx = -1, lineT = 0, waiting = false;
    const knobs = [0, 1, 2].map((i) => this.level.radio.getObjectByName("knob" + i)!);
    this.runShots([
      { dur: 1.5, from: [eye, look0], to: [close, rl] },
      {
        dur: 3, from: [close, rl], to: [V(R.x + 0.1, R.y + 0.3, R.z + 0.6), rl],
        update: (t) => {
          knobs[0].rotation.y = t * 6;
          knobs[2].rotation.y = -t * 4;
          (this.level.radioDial.material as THREE.MeshBasicMaterial).color.setHSL(0.1, 1, 0.3 + Math.random() * 0.4);
          audio.setStatic(0.15 + Math.random() * 0.25);
          this.ui.subtitle = { who: "", text: "[static] ... kssshhh ... [adjusting frequency] ..." };
        },
      },
      {
        dur: 9999, from: [V(R.x + 1.2, R.y + 0.6, R.z + 1.4), rl], to: [V(R.x - 1.2, R.y + 0.5, R.z + 1.5), rl],
        start: () => { audio.setStatic(0.06); this.ui.subtitle = null; },
        update: (_t, dt) => {
          const sh = this.shots[this.shotIdx];
          // custom orbit speed
          const ang = performance.now() * 0.00015;
          sh.from[0].set(R.x + Math.sin(ang) * 1.5, R.y + 0.55, R.z + 0.6 + Math.cos(ang) * 0.9);
          sh.to[0].copy(sh.from[0]);
          if (waiting) return;
          lineT -= dt;
          if (lineT <= 0) {
            const prev = this.radioLines[lineIdx];
            if (prev?.choice) {
              waiting = true;
              this.ui.choices = prev.choice;
              return;
            }
            lineIdx++;
            const ln = this.radioLines[lineIdx];
            if (!ln) {
              this.shotT = 0;
              this.shotIdx++;
              this.shots[this.shotIdx]?.start?.();
              return;
            }
            lineT = ln.dur;
            this.ui.subtitle = { who: ln.who, text: ln.text };
            audio.speak(ln.text, ln.voice);
            if (ln.voice !== "akhil") { audio.setStatic(0.12); setTimeout(() => audio.setStatic(0.05), 400); }
            else audio.radioBeep();
          }
        },
      },
      {
        dur: 2, from: [V(R.x + 0.3, R.y + 0.4, R.z + 0.9), rl], to: [V(R.x + 0.3, R.y + 0.4, R.z + 0.9), rl],
        start: () => { this.ui.subtitle = { who: "", text: "[transmission ends — static]" }; audio.setStatic(0.35); },
        update: (t) => { this.ui.fade = Math.max(0, (t - 0.5) * 2) * 0.8; },
      },
      { dur: 1.2, from: [V(R.x + 0.3, R.y + 0.4, R.z + 0.9), rl], to: [eye, look0], start: () => { audio.stopStatic(); this.ui.subtitle = null; this.ui.fade = 0; } },
    ], () => {
      this.stage = 1;
      this.killsAtRadio = this.kills;
      this.mode = "playing";
      this.placeSquad();
      setTimeout(() => this.squadSay("radio", "narendra", 2), 1500);
      setTimeout(() => this.squadSay("mission_start", "mahesh", 2), 6000);
      this.ui.letterbox = false;
      this.updateObjective();
      this.equip(this.current, true);
      this.spawnT = 6;
      this.save();
      this.toast("NEW OBJECTIVE: SURVIVE. SECURE THE SCHOOL. WAIT FOR FURTHER ORDERS.");
      setTimeout(() => this.toast("You pocket the radio handset. Bravo Squad can reach you anywhere now."), 2500);
      setTimeout(() => this.toast("The radio noise is drawing more infected..."), 5500);
      if (!this.isTouch) this.lockPointer();
    });
    // the choice handler continues dialogue
    this.onChoice = (i: number) => {
      if (!waiting) return;
      this.ui.choices = null;
      const rest: typeof this.radioLines = [];
      if (i === 1) {
        rest.push({ who: "AKHIL", voice: "akhil", text: "Hello?! Can anyone hear me?", dur: 2.8 });
        rest.push({ who: "RADIO OPERATOR", voice: "operator", text: "We hear you, survivor. Signal is weak. Identify yourself and your location.", dur: 4.5 });
      }
      rest.push({ who: "AKHIL", voice: "akhil", text: "This is Akhil. I'm trapped inside the school. The building is overrun with infected. I need extraction!", dur: 6 });
      rest.push({ who: "SOLDIER", voice: "soldier", text: "Copy that, Akhil. We received your transmission. Our unit is mobilizing, but we cannot reach you yet.", dur: 6 });
      rest.push({ who: "RADIO OPERATOR", voice: "operator", text: "Secure your position and keep this frequency open. We will transmit further instructions.", dur: 5.5 });
      this.radioLines = [...this.radioLines.slice(0, lineIdx + 1), ...rest];
      waiting = false;
      lineT = 0;
      // clear choice flag so loop advances
      this.radioLines[lineIdx] = { ...this.radioLines[lineIdx], choice: undefined };
    };
  }

  onChoice: (i: number) => void = () => {};
  choose(i: number) { this.onChoice(i); }

  startRooftopCall() {
    this.stage = 2;
    // the roof access door is now usable
    const rd = this.level.doors.find((d) => d.id === "roof");
    if (rd) { rd.locked = false; const lk = rd.pivot.getObjectByName("lock"); if (lk) lk.visible = false; }
    setTimeout(() => this.squadSay("mission_start", undefined, 2), 15000);
    const d = this.level.doors.find((x) => x.id === "roof");
    if (d) {
      d.locked = false;
      const lock = d.pivot.getObjectByName("lock");
      if (lock) lock.visible = false;
    }
    audio.radioBeep();
    const l1 = "Akhil, do you copy? A rescue bird is making one pass over your sector, right now. Get to the school roof!";
    const l2 = "We pushed a security override to the roof access door — stairwell, second floor. Move, kid, they won't wait!";
    this.ui.subtitle = { who: "SOLDIER", text: l1 };
    audio.speak(l1, "soldier");
    setTimeout(() => {
      if (this.stage !== 2) return;
      this.ui.subtitle = { who: "RADIO OPERATOR", text: l2 };
      audio.speak(l2, "operator");
    }, 7500);
    setTimeout(() => { if (this.ui.subtitle?.text === l2) this.ui.subtitle = null; }, 14500);
    this.toast("ROOF ACCESS unlocked — stairwell, 2nd floor!");
    audio.startHeli(0.045);
    // a last wave pushes toward the stairwell
    const pts = [V(24, 0, 4), V(20, 0, -3), V(6, 4, 0.5), V(-4, 4, -0.5)];
    pts.forEach((p, i) => {
      const z = this.spawnZombie("w" + i + Math.random().toString(36).slice(2, 5), p, i % 5, i % 2 === 0);
      z.state = "investigate";
      z.lastKnown.set(12, 4, 1);
    });
    this.updateObjective();
    this.save();
  }

  playEnding() {
    this.mode = "ending";
    this.ui.letterbox = true;
    this.ui.canSkip = true;
    this.ui.prompt = null;
    this.input.fire = false;
    this.adsT = 0;
    this.vmGroup.visible = false;
    if (document.pointerLockElement) document.exitPointerLock();
    audio.stopSpeech();
    this.clearActors();
    const H = this.heli;
    H.visible = true;
    this.heliCone.visible = false;
    audio.setHeliVol(0.1);
    audio.startHeli(0.1);
    // Akhil runs from the bulkhead to the helipad
    this.addActor(false, [V(16, 8.0, 1.6), V(13, 8.3, 0.6), V(-5.8, 8.3, 0.3)], 4.4, 1.2, 4);
    const akhil = this.actors[0].h;
    const say = (who: string, text: string, voice: "soldier" | "operator" | "akhil") => {
      this.ui.subtitle = { who, text };
      audio.speak(text, voice);
    };
    const hv = (t: number, a: THREE.Vector3, b: THREE.Vector3, lookAhead = true) => {
      const e = t * t * (3 - 2 * t);
      H.position.lerpVectors(a, b, e);
      if (lookAhead) {
        const dir = this.tmpV.subVectors(b, a);
        H.rotation.y = Math.atan2(dir.x, dir.z) + Math.PI;
        H.rotation.z = THREE.MathUtils.clamp(-dir.x * 0.004, -0.25, 0.25);
        H.rotation.x = 0.08;
      }
      H.position.y += Math.sin(performance.now() * 0.002) * 0.15;
    };
    const hA = V(170, 48, 90), hB = V(60, 22, 24), hC = V(21, 12.5, 1), hOut = V(190, 55, -120);
    this.runShots([
      {
        dur: 6, from: [V(-26, 13, -10), V(16, 9, 2)], to: [V(-18, 11, -5), V(6, 8.8, 1)],
        start: () => say("SOLDIER", "Bravo-2 on approach. Thermal shows one survivor coming up to the school roof — hold your pattern.", "soldier"),
        update: (t) => { hv(t, hA, hB); audio.setHeliVol(0.08 + t * 0.1); },
      },
      {
        dur: 5.5, from: [V(-3, 9.2, 5), V(40, 16, 10)], to: [V(-5, 9.4, 3.5), V(27, 12, 1)],
        start: () => say("RADIO OPERATOR", "Bravo-2, be advised: you are bingo fuel. One pass. If the pad is not clear, you pull out.", "operator"),
        update: (t) => { hv(t, hB, hC); audio.setHeliVol(0.18 + t * 0.12); },
      },
      {
        dur: 5, from: [V(-12, 9.6, -4), V(10, 10.5, 0)], to: [V(-10.5, 9.2, -2.5), V(14, 10.8, 0.5)],
        start: () => {
          this.heliSpot.intensity = 60;
          this.heliCone.visible = true;
          say("AKHIL", "HEY! DOWN HERE! I'M HERE — I'M RIGHT HERE!", "akhil");
        },
        update: (t, dt) => {
          hv(1, hC, hC, false);
          H.rotation.y = -Math.PI / 2 + Math.sin(t * 3) * 0.06;
          H.rotation.z = Math.sin(t * 5) * 0.03;
          void dt;
          // Akhil waves
          if (this.actors[0] && this.actors[0].seg >= this.actors[0].path.length - 1) {
            const w = performance.now() * 0.012;
            akhil.armR.rotation.x = -2.8 + Math.sin(w) * 0.35;
            akhil.armL.rotation.x = -2.6 - Math.sin(w) * 0.35;
          }
        },
      },
      {
        dur: 7, from: [V(-13, 9.0, 2.5), V(27, 12, 1)], to: [V(-11, 9.6, 4), V(80, 30, -40)],
        start: () => say("SOLDIER", "Negative — negative! Infected are flooding the floors below and we are past bingo. We can't set down. I'm sorry, kid. Bravo-2 pulling out.", "soldier"),
        update: (t) => {
          hv(t, hC, hOut);
          if (t > 0.25) { this.heliSpot.intensity = 0; this.heliCone.visible = false; }
          audio.setHeliVol(Math.max(0.03, 0.3 - t * 0.27));
          akhil.armR.rotation.x = Math.max(-2.8 + t * 6, -0.2);
          akhil.armL.rotation.x = Math.max(-2.6 + t * 6, -0.1);
          if (t > 0.5) akhil.body.rotation.x = Math.min(0.35, (t - 0.5) * 1.2);
        },
      },
      {
        dur: 7, from: [V(14, 9.8, 7), V(30, 9, 0)], to: [V(18.5, 9.5, 3), V(60, 10, -6)],
        start: () => {
          akhil.body.rotation.x = 0;
          const a = this.actors[0];
          a.path = [akhil.root.position.clone(), V(26.5, 8.3, 0)];
          a.seg = 0;
          a.speed = 1.5;
          say("SOLDIER", "Akhil, listen to me. Harbor district — far side of the city. Last evac zone still broadcasting. Keep the handset on. Stay alive.", "soldier");
        },
        update: (t) => { hv(t, hOut, V(260, 70, -180)); },
      },
      {
        dur: 7, from: [V(24.2, 9.7, 2.2), V(90, 2, -20)], to: [V(25.4, 9.55, 1.2), V(110, 10, -30)],
        start: () => say("AKHIL", "The whole city is burning... Fine. I survived the school — I'll survive out there too. I'm getting out of this apocalypse.", "akhil"),
        update: () => { H.visible = false; audio.setHeliVol(0.0); },
      },
      {
        dur: 2.5, from: [V(25.4, 9.55, 1.2), V(110, 10, -30)], to: [V(25.6, 9.5, 1.0), V(110, 10, -30)],
        start: () => { this.ui.subtitle = null; },
        update: (t) => { this.ui.fade = t; },
      },
      { dur: 4, from: [V(0, -50, 0), V(0, -50, 1)], to: [V(0, -50, 0), V(0, -50, 1)], start: () => { this.ui.fade = 1; this.ui.bigText = "THE SCHOOL WAS ONLY THE BEGINNING."; } },
      { dur: 3.5, from: [V(0, -50, 0), V(0, -50, 1)], to: [V(0, -50, 0), V(0, -50, 1)], start: () => { this.ui.bigText = "CHAPTER ONE COMPLETE"; } },
    ], () => this.finishEnding());
  }

  finishEnding() {
    this.shots = [];
    this.cutsceneEnd = null;
    this.clearActors();
    this.heli.visible = false;
    this.heliSpot.intensity = 0;
    this.heliCone.visible = false;
    audio.stopHeli();
    audio.stopSpeech();
    this.stage = 3;
    this.mode = "complete";
    this.ui.letterbox = false;
    this.ui.canSkip = false;
    this.ui.bigText = null;
    this.ui.subtitle = null;
    this.ui.fade = 1;
    this.pos.set(-8, 8.3, 0.5);
    this.yaw = -Math.PI / 2;
    this.pitch = 0;
    this.placeSquad();
    this.updateObjective();
    this.save();
  }

  continueFreeRoam() {
    this.mode = "playing";
    this.ui.fade = 0;
    this.health = Math.max(this.health, 60);
    this.applyCityStage();
    this.placeSquad();
    this.updateObjective();
    this.equip(this.current, true);
    this.spawnT = 20;
    if (this.stage >= 8) this.toast("FREE ROAM — the city is yours. Chapter 3 comes later.");
    else {
      this.toast("CHAPTER 2 — THE CITY. The barricade is open: head out the main entrance.");
      setTimeout(() => this.toast("Someone is signalling from the gas station up the street..."), 3500);
    }
    this.save();
    if (!this.isTouch) this.lockPointer();
  }

  updateCutscene(dt: number) {
    if (!this.shots.length) return;
    const sh = this.shots[this.shotIdx];
    if (!sh) return;
    this.shotT += dt;
    const t = Math.min(1, this.shotT / sh.dur);
    const e = t * t * (3 - 2 * t);
    this.camera.position.lerpVectors(sh.from[0], sh.to[0], e);
    this.tmpV2.lerpVectors(sh.from[1], sh.to[1], e);
    if (sh.shake) { this.camera.position.x += (Math.random() - 0.5) * sh.shake; this.camera.position.y += (Math.random() - 0.5) * sh.shake; }
    this.camera.lookAt(this.tmpV2);
    sh.update?.(t, dt);
    if (this.shots[this.shotIdx] !== sh) return;
    if (this.shotT >= sh.dur) {
      this.shotIdx++;
      this.shotT = 0;
      if (this.shotIdx >= this.shots.length) {
        this.shots = [];
        const end = this.cutsceneEnd;
        this.cutsceneEnd = null;
        end?.();
      } else this.shots[this.shotIdx].start?.();
    }
  }

  // ---------------- physics helpers ----------------
  rayBoxes(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxT: number) {
    const b = this.boxes;
    const ix = 1 / (dx || 1e-9), iy = 1 / (dy || 1e-9), iz = 1 / (dz || 1e-9);
    let best = maxT;
    const test = (minx: number, miny: number, minz: number, maxx: number, maxy: number, maxz: number) => {
      let t1 = (minx - ox) * ix, t2 = (maxx - ox) * ix;
      let tmin = Math.min(t1, t2), tmax = Math.max(t1, t2);
      t1 = (miny - oy) * iy; t2 = (maxy - oy) * iy;
      tmin = Math.max(tmin, Math.min(t1, t2)); tmax = Math.min(tmax, Math.max(t1, t2));
      t1 = (minz - oz) * iz; t2 = (maxz - oz) * iz;
      tmin = Math.max(tmin, Math.min(t1, t2)); tmax = Math.min(tmax, Math.max(t1, t2));
      if (tmax >= Math.max(tmin, 0) && tmin < best) best = Math.max(tmin, 0);
    };
    for (let i = 0; i < b.length; i += 6) test(b[i], b[i + 1], b[i + 2], b[i + 3], b[i + 4], b[i + 5]);
    for (const d of this.level.doors) {
      if (Math.abs(d.angle) < 0.35) { const x = d.box; test(x.minx, x.miny, x.minz, x.maxx, x.maxy, x.maxz); }
    }
    return best;
  }

  los = (ax: number, ay: number, az: number, bx: number, by: number, bz: number) => {
    const dx = bx - ax, dy = by - ay, dz = bz - az;
    const L = Math.hypot(dx, dy, dz);
    if (L < 0.01) return true;
    return this.rayBoxes(ax, ay, az, dx / L, dy / L, dz / L, L) >= L - 0.05;
  };

  move = (p: THREE.Vector3, dx: number, dz: number, r: number, h: number) => {
    p.x += dx;
    p.z += dz;
    const cols = this.level.colliders;
    const lo = p.y + 0.3, hi = p.y + h;
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < cols.length; i++) this.pushOut(p, cols[i], r, lo, hi);
      for (const d of this.level.doors) if (Math.abs(d.angle) < 0.35) this.pushOut(p, d.box, r, lo, hi);
    }
  };

  pushOut(p: THREE.Vector3, c: { minx: number; maxx: number; miny: number; maxy: number; minz: number; maxz: number }, r: number, lo: number, hi: number) {
    if (lo >= c.maxy || hi <= c.miny) return;
    if (p.x < c.minx - r || p.x > c.maxx + r || p.z < c.minz - r || p.z > c.maxz + r) return;
    const cx = Math.max(c.minx, Math.min(p.x, c.maxx)), cz = Math.max(c.minz, Math.min(p.z, c.maxz));
    const dx = p.x - cx, dz = p.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 > 1e-8) {
      if (d2 < r * r) { const d = Math.sqrt(d2); p.x = cx + (dx / d) * r; p.z = cz + (dz / d) * r; }
    } else {
      const l = p.x - c.minx, rr = c.maxx - p.x, f = p.z - c.minz, b = c.maxz - p.z;
      const m = Math.min(l, rr, f, b);
      if (m === l) p.x = c.minx - r; else if (m === rr) p.x = c.maxx + r; else if (m === f) p.z = c.minz - r; else p.z = c.maxz + r;
    }
  }

  // ---------------- effects ----------------
  spawnBurst(x: number, y: number, z: number, n: number, col: number[], spd: number) {
    let k = 0;
    for (let i = 0; i < this.particles.length && k < n; i++) {
      const p = this.particles[i];
      if (p.life > 0) continue;
      p.x = x; p.y = y; p.z = z;
      p.vx = (Math.random() - 0.5) * spd; p.vy = Math.random() * spd * 0.7; p.vz = (Math.random() - 0.5) * spd;
      p.life = 0.4 + Math.random() * 0.5;
      this.pColors[i * 3] = col[0] * (0.7 + Math.random() * 0.3);
      this.pColors[i * 3 + 1] = col[1] * (0.7 + Math.random() * 0.3);
      this.pColors[i * 3 + 2] = col[2] * (0.7 + Math.random() * 0.3);
      k++;
    }
    (this.pGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }

  updateParticles(dt: number) {
    const pos = this.pGeo.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (p.life > 0) {
        p.life -= dt;
        p.vy -= 9.8 * dt;
        p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
        if (p.life <= 0) p.y = -100;
      }
      arr[i * 3] = p.x; arr[i * 3 + 1] = p.y; arr[i * 3 + 2] = p.z;
    }
    pos.needsUpdate = true;
  }

  // ---------------- weapons ----------------
  equip(id: WeaponId | null, instant = false) {
    if (instant) {
      this.current = id;
      this.switchT = 0;
      this.pendingWeapon = undefined;
      for (const k in this.vms) this.vms[k].group.visible = k === (id ?? "hands");
      this.vmGroup.visible = true;
      return;
    }
    if (id === this.current || this.switchT > 0) return;
    this.reloadT = 0;
    this.pendingWeapon = id;
    this.switchT = 0.5;
  }

  cycleWeapon() {
    if (!this.owned.length) return;
    const order: WeaponId[] = ["pistol", "shotgun", "rifle"];
    const list = order.filter((w) => this.owned.includes(w));
    const i = this.current ? list.indexOf(this.current) : -1;
    this.equip(list[(i + 1) % list.length]);
  }

  reload() {
    if (!this.current || this.reloadT > 0 || this.switchT > 0) return;
    const a = this.ammo[this.current], def = WEAPONS[this.current];
    if (a.mag >= def.mag) return;
    if (a.reserve <= 0) { this.toast("No spare ammo for " + def.name); return; }
    this.reloadT = def.reload;
    audio.reload(this.current);
  }

  fire() {
    if (this.switchT > 0 || this.reloadT > 0 || this.fireCD > 0) return;
    const eye = this.camera.position;
    const cp = Math.cos(this.pitch);
    const fwd = new THREE.Vector3(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
    if (!this.current) {
      // unarmed shove/punch
      this.fireCD = 0.55;
      this.punchT = 0.35;
      audio.footstep(true);
      let best: Zombie | null = null, bd = 1.9;
      for (const z of this.zombies) {
        if (!z.alive || Math.abs(z.pos.y - this.pos.y) > 1) continue;
        const dx = z.pos.x - this.pos.x, dz = z.pos.z - this.pos.z, d = Math.hypot(dx, dz);
        if (d < bd && (dx * fwd.x + dz * fwd.z) / d > 0.5) { bd = d; best = z; }
      }
      if (best) {
        setTimeout(() => {
          if (!best!.alive) return;
          audio.zombieHit(best!.pos);
          this.spawnBurst(best!.pos.x, best!.pos.y + 1.4, best!.pos.z, 8, [0.5, 0.02, 0.02], 2);
          best!.knock(fwd, this.zworld);
          if (best!.damage(22, this.zworld)) this.onKill(best!);
          this.ui.hitT = performance.now();
        }, 120);
      }
      return;
    }
    const def = WEAPONS[this.current];
    const a = this.ammo[this.current];
    if (a.mag <= 0) {
      audio.click();
      this.fireCD = 0.25;
      if (a.reserve > 0) this.reload();
      else this.toast("Out of ammo! Find more or switch weapons.");
      return;
    }
    a.mag--;
    this.fireCD = def.rate;
    audio.gunshot(this.current);
    this.flashT = 0.05;
    const kick = def.recoil * (this.adsT > 0.5 ? 0.6 : 1);
    this.recoilPitch += 0.022 * kick;
    this.yaw += (Math.random() - 0.5) * 0.01 * kick;
    this.vmKick = Math.min(1.5, this.vmKick + kick * 0.6);
    const spread = def.spread * (this.adsT > 0.5 ? 0.35 : 1) * (this.vel.lengthSq() > 4 ? 1.5 : 1);
    let hitAny = false;
    // muzzle position for tracers (approximates the viewmodel muzzle)
    const mRight = 0.13 * (1 - this.adsT), mDown = 0.09 * (1 - this.adsT);
    const msx = eye.x + fwd.x * 0.35 + Math.cos(this.yaw) * mRight;
    const msy = eye.y + fwd.y * 0.35 - mDown;
    const msz = eye.z + fwd.z * 0.35 - Math.sin(this.yaw) * mRight;
    for (let p = 0; p < def.pellets; p++) {
      const d = this.tmpV2.copy(fwd);
      d.x += (Math.random() - 0.5) * spread * 2;
      d.y += (Math.random() - 0.5) * spread * 2;
      d.z += (Math.random() - 0.5) * spread * 2;
      d.normalize();
      const wallT = this.rayBoxes(eye.x, eye.y, eye.z, d.x, d.y, d.z, def.range);
      let hz: Zombie | null = null, ht = wallT, head = false;
      for (const z of this.zombies) {
        if (!z.alive) continue;
        if (Math.abs(z.pos.x - eye.x) > ht + 1 || Math.abs(z.pos.z - eye.z) > ht + 1) continue;
        for (const s of z.hitSpheres()) {
          const ox = s.x - eye.x, oy = s.y - eye.y, oz = s.z - eye.z;
          const tc = ox * d.x + oy * d.y + oz * d.z;
          if (tc < 0 || tc > ht) continue;
          const d2 = ox * ox + oy * oy + oz * oz - tc * tc;
          if (d2 < s.r * s.r) { ht = tc; hz = z; head = s.head; }
        }
      }
      const hx = eye.x + d.x * ht, hy = eye.y + d.y * ht, hzz = eye.z + d.z * ht;
      if (p < 3) this.spawnTracer(msx, msy, msz, hx, hy, hzz);
      if (hz) {
        const dmg = def.dmg * (head ? 2.3 : 1) * (this.current === "shotgun" ? Math.max(0.4, 1 - ht / 25) : 1);
        this.spawnBurst(hx, hy, hzz, head ? 14 : 7, [0.45, 0.02, 0.02], 2.5);
        hitAny = true;
        if (hz.damage(dmg, this.zworld)) this.onKill(hz);
        if (this.current === "shotgun") hz.knock(d, this.zworld, 0.25);
      } else if (ht < def.range) {
        if (p < 3) this.spawnBurst(hx - d.x * 0.05, hy - d.y * 0.05, hzz - d.z * 0.05, 4, [1, 0.85, 0.5], 2);
      }
    }
    if (hitAny) { this.ui.hitT = performance.now(); audio.zombieHit(this.pos); } else audio.impact();
    // gunshot noise alerts zombies
    for (const z of this.zombies) {
      if (!z.alive) continue;
      const dd = z.pos.distanceTo(this.pos);
      if (dd < 28 && (Math.abs(z.pos.y - this.pos.y) < 2 || dd < 14)) z.hear(this.pos, this.zworld);
    }
    if (a.mag === 0 && a.reserve > 0) setTimeout(() => this.reload(), 250);
  }

  vmKick = 0;

  onKill(z: Zombie) {
    this.kills++;
    this.ui.killT = performance.now();
    if (this.stage === 1) this.updateObjective();
    audio.groan(z.pos, z.pitch * 0.7);
    if (/^(z|cz|rb|m1|mx)/.test(z.id)) this.deadIds.add(z.id);
    this.missionKill(z);
    // drops (more generous when Akhil has no backup)
    if (Math.random() < (this.squadMode ? 0.38 : 0.5)) {
      const owned = this.owned.length ? this.owned : (["pistol"] as WeaponId[]);
      const w = owned[Math.floor(Math.random() * owned.length)];
      const kind = (Math.random() < 0.2 ? "health" : "ammo_" + w) as PickupKind;
      this.addPickup({ id: "drop" + this.dropN++, kind, x: z.pos.x, y: z.pos.y + 0.05, z: z.pos.z, where: "infected" });
    }
    setTimeout(() => {
      this.scene.remove(z.root);
      this.zombies = this.zombies.filter((q) => q !== z);
    }, 25000);
  }


  swayX = 0;
  swayY = 0;
  mouseAds = false;

  updatePlayer(dt: number) {
    const inp = this.input;
    // look
    const sens = 0.0022 * this.sensitivity * (this.adsT > 0.5 ? 0.6 : 1);
    this.yaw -= inp.lookX * sens;
    this.pitch -= inp.lookY * sens;
    this.swayX = THREE.MathUtils.clamp(this.swayX + inp.lookX * 0.0004, -0.04, 0.04);
    this.swayY = THREE.MathUtils.clamp(this.swayY + inp.lookY * 0.0004, -0.04, 0.04);
    inp.lookX = inp.lookY = 0;
    // recoil recovery
    if (this.recoilPitch > 0) {
      const rec = Math.min(this.recoilPitch, dt * 0.9 + this.recoilPitch * dt * 6);
      this.pitch += rec * 0.5;
      this.recoilPitch -= rec;
      if (this.recoilPitch < 0) this.recoilPitch = 0;
    }
    this.pitch = THREE.MathUtils.clamp(this.pitch, -1.45, 1.45);
    // move
    const k = inp.keys;
    let mx = inp.moveX, my = inp.moveY;
    if (k.has("KeyW") || k.has("ArrowUp")) my += 1;
    if (k.has("KeyS") || k.has("ArrowDown")) my -= 1;
    if (k.has("KeyA") || k.has("ArrowLeft")) mx -= 1;
    if (k.has("KeyD") || k.has("ArrowRight")) mx += 1;
    const ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; }
    const sprint = (k.has("ShiftLeft") || inp.sprint) && my > 0.3 && this.adsT < 0.3;
    const speed = this.adsT > 0.5 ? 2.2 : sprint ? 5.8 : 3.6;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw), rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    const wx = (fx * my + rx * mx) * speed, wz = (fz * my + rz * mx) * speed;
    const accel = this.onGround ? 14 : 3;
    this.vel.x += (wx - this.vel.x) * Math.min(1, accel * dt);
    this.vel.z += (wz - this.vel.z) * Math.min(1, accel * dt);
    const ox = this.pos.x, oz = this.pos.z;
    this.move(this.pos, this.vel.x * dt, this.vel.z * dt, 0.35, 1.75);
    const moved = Math.hypot(this.pos.x - ox, this.pos.z - oz);
    // jump / gravity
    if ((inp.jump || k.has("Space")) && this.onGround) { this.vel.y = 6.2; this.onGround = false; }
    inp.jump = false;
    const g = this.level.groundAt(this.pos.x, this.pos.z, this.pos.y);
    this.vel.y -= 20 * dt;
    this.pos.y += this.vel.y * dt;
    if (this.pos.y <= g) {
      if (!this.onGround && this.vel.y < -4) audio.land();
      this.pos.y = g; this.vel.y = 0; this.onGround = true;
    } else if (this.pos.y - g > 0.05 && this.vel.y < 0) {
      if (this.onGround && this.pos.y - g < 0.35) { this.pos.y = g; this.vel.y = 0; }
      else this.onGround = false;
    }
    // footsteps / bob
    if (this.onGround && moved > 0.001) {
      this.stepDist += moved;
      this.bobT += moved * (sprint ? 2.2 : 2.6);
      if (this.stepDist > (sprint ? 2.3 : 1.9)) {
        this.stepDist = 0;
        audio.footstep(sprint);
        if (sprint) for (const z of this.zombies) if (z.alive && z.pos.distanceTo(this.pos) < 7) z.hear(this.pos, this.zworld);
      }
    }
    const moving = moved / Math.max(dt, 1e-4);
    // weapons
    if (this.fireCD > 0) this.fireCD -= dt;
    if (this.punchT > 0) this.punchT -= dt;
    if (inp.flash || k.has("KeyF")) {
      inp.flash = false; k.delete("KeyF");
      if (this.hasFlashlight) { this.flashOn = !this.flashOn; audio.click(); } else this.toast("You don't have a flashlight yet.");
    }
    if (inp.follow || k.has("KeyG")) { inp.follow = false; k.delete("KeyG"); this.followMe(); }
    if (inp.switchW || k.has("KeyQ")) { inp.switchW = false; k.delete("KeyQ"); this.cycleWeapon(); }
    if (inp.weaponSlot) {
      const w = (["pistol", "shotgun", "rifle"] as WeaponId[])[inp.weaponSlot - 1];
      inp.weaponSlot = 0;
      if (this.owned.includes(w)) this.equip(w);
    }
    if (inp.reload || k.has("KeyR")) { inp.reload = false; k.delete("KeyR"); this.reload(); }
    if (this.switchT > 0) {
      const prev = this.switchT;
      this.switchT -= dt;
      if (prev > 0.25 && this.switchT <= 0.25 && this.pendingWeapon !== undefined) {
        this.current = this.pendingWeapon;
        this.pendingWeapon = undefined;
        for (const kk in this.vms) this.vms[kk].group.visible = kk === (this.current ?? "hands");
        audio.reload("x");
      }
      if (this.switchT < 0) this.switchT = 0;
    }
    if (this.reloadT > 0) {
      this.reloadT -= dt;
      if (this.reloadT <= 0 && this.current) {
        this.reloadT = 0;
        const a = this.ammo[this.current], def = WEAPONS[this.current];
        const need = Math.min(def.mag - a.mag, a.reserve);
        a.mag += need; a.reserve -= need;
      }
    }
    const wantAds = (inp.ads || this.mouseAds) && !!this.current && this.reloadT <= 0 && this.switchT <= 0;
    this.adsT += ((wantAds ? 1 : 0) - this.adsT) * Math.min(1, dt * 12);
    if (inp.fire) {
      const auto = this.current ? WEAPONS[this.current].auto : false;
      if (auto || !this.triggerHeld) this.fire();
      this.triggerHeld = true;
    } else this.triggerHeld = false;
    // ---- target lock & auto-shoot ----
    this.ui.lockOn = false;
    if (this.current && this.health > 0) {
      const def = WEAPONS[this.current];
      const eye = this.camera.position;
      const cpch = Math.cos(this.pitch);
      const fwx = -Math.sin(this.yaw) * cpch, fwy = Math.sin(this.pitch), fwz = -Math.cos(this.yaw) * cpch;
      let found = false;
      for (const z of this.zombies) {
        if (!z.alive) continue;
        for (const [ty, r] of [[1.6, 0.22], [1.15, 0.34]] as [number, number][]) {
          const dx = z.pos.x - eye.x, dy = z.pos.y + ty * z.scale - eye.y, dz = z.pos.z - eye.z;
          const dist = Math.hypot(dx, dy, dz);
          if (dist > def.range || dist < 0.5) continue;
          const proj = dx * fwx + dy * fwy + dz * fwz;
          if (proj <= 0) continue;
          const perp = Math.sqrt(Math.max(0, dist * dist - proj * proj));
          if (perp > r * z.scale + 0.1 + dist * 0.014) continue;
          if (!this.los(eye.x, eye.y, eye.z, z.pos.x, z.pos.y + ty * z.scale, z.pos.z)) continue;
          found = true;
          break;
        }
        if (found) break;
      }
      this.ui.lockOn = found;
      if (found && this.autoShoot && this.fireCD <= 0 && this.reloadT <= 0 && this.switchT <= 0 && !inp.fire) {
        const a = this.ammo[this.current];
        if (a.mag > 0) this.fire();
        else if (a.reserve > 0) this.reload();
      }
    }
    // interaction
    this.interactT -= dt;
    if (this.interactT <= 0) { this.interactT = 0.12; this.currentInteract = this.findInteract(); }
    this.ui.prompt = this.currentInteract?.label ?? null;
    if (inp.interact || k.has("KeyE")) {
      inp.interact = false; k.delete("KeyE");
      if (this.currentInteract) { this.currentInteract.act(); this.interactT = 0; }
    }
    // camera
    const bob = this.onGround ? Math.sin(this.bobT * Math.PI) * 0.04 * Math.min(1, moving / 3.6) * (1 - this.adsT * 0.8) : 0;
    let shake = 0;
    if (this.shakeT > 0) { this.shakeT -= dt; shake = this.shakeT * 0.15; }
    this.camera.position.set(this.pos.x + (Math.random() - 0.5) * shake, this.pos.y + 1.6 + bob + (Math.random() - 0.5) * shake, this.pos.z);
    this.camera.rotation.set(this.pitch, this.yaw, Math.sin(this.bobT * Math.PI * 0.5) * 0.004 * Math.min(1, moving / 3.6));
    const baseFov = 72 + (sprint ? 6 : 0);
    const targetFov = this.current ? THREE.MathUtils.lerp(baseFov, WEAPONS[this.current].adsFov * (72 / 72), this.adsT) : baseFov;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) { this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 10); this.camera.updateProjectionMatrix(); }
    audio.setListener(this.pos.x, this.pos.y + 1.6, this.pos.z, fx, fz);
    // reached the terrace -> the extraction cutscene
    if (this.stage === 2 && this.pos.y > 7.5 && Math.abs(this.pos.x) < 30 && Math.abs(this.pos.z) < 12) {
      this.playEnding();
      return;
    }

    this.updateViewModel(dt, moving, sprint);
  }

  updateViewModel(dt: number, moving: number, sprint: boolean) {
    const id = this.current ?? "hands";
    const vm = this.vms[id];
    const g = vm.group;
    this.swayX *= 1 - Math.min(1, dt * 8);
    this.swayY *= 1 - Math.min(1, dt * 8);
    this.vmKick *= 1 - Math.min(1, dt * 14);
    const def = this.current ? WEAPONS[this.current] : null;
    const hip = def ? def.hip : V(0.22, -0.24, -0.4);
    const ads = def ? def.ads : hip;
    const p = this.tmpV.lerpVectors(hip, ads, this.adsT);
    const mv = Math.min(1, moving / 3.6) * (1 - this.adsT * 0.85);
    const bx = Math.sin(this.bobT * Math.PI * 0.5) * 0.012 * mv;
    const by = -Math.abs(Math.cos(this.bobT * Math.PI * 0.5)) * 0.01 * mv;
    const idle = Math.sin(performance.now() * 0.0015) * 0.003;
    g.position.set(p.x + bx - this.swayX, p.y + by + idle + this.swayY, p.z + this.vmKick * 0.05);
    g.rotation.set(this.vmKick * 0.12, 0, 0);
    if (sprint && this.reloadT <= 0) { g.rotation.set(-0.3, 0.6, 0.2); g.position.y -= 0.04; g.position.x += 0.04; }
    if (this.switchT > 0) {
      const s = this.switchT > 0.25 ? (0.5 - this.switchT) / 0.25 : this.switchT / 0.25;
      g.position.y -= s * 0.3;
      g.rotation.x -= s * 0.6;
    }
    if (this.reloadT > 0 && def) {
      const r = 1 - this.reloadT / def.reload;
      const w = Math.sin(r * Math.PI);
      g.rotation.z = w * 0.5;
      g.rotation.x = -w * 0.3;
      g.position.y -= w * 0.06;
      if (vm.mag) vm.mag.position.y = (id === "pistol" ? -0.09 : -0.06) - Math.max(0, Math.sin(r * Math.PI)) * 0.15;
      if (vm.pump) vm.pump.position.z = -0.3 + Math.abs(Math.sin(r * Math.PI * 3)) * 0.08;
    } else {
      if (vm.mag) vm.mag.position.y = id === "pistol" ? -0.09 : -0.06;
      if (vm.pump) {
        const pr = this.current === "shotgun" ? Math.max(0, this.fireCD - 0.2) / 0.65 : 0;
        vm.pump.position.z = -0.3 + Math.sin(pr * Math.PI) * 0.1;
      }
    }
    if (id === "hands") {
      const pk = this.punchT > 0 ? Math.sin((this.punchT / 0.35) * Math.PI) : 0;
      g.position.z -= pk * 0.25;
      g.rotation.x += pk * 0.2;
    }
    const flash = vm.muzzle.getObjectByName("flash");
    const fon = this.flashT > 0;
    if (flash) { flash.visible = fon; flash.rotation.z = Math.random() * 6; }
    this.vmLight.intensity = fon ? 3 : 0;
    if (fon) {
      const cp = this.camera.position, d = this.camera.getWorldDirection(this.tmpV2);
      this.muzzleLight.position.set(cp.x + d.x * 0.8, cp.y + d.y * 0.8, cp.z + d.z * 0.8);
      this.muzzleLight.intensity = 4;
    } else this.muzzleLight.intensity = 0;
    this.vmAmb.intensity = this.flashOn ? 1.0 : 0.6;
    this.vmCam.fov = 60 - this.adsT * 8;
    this.vmCam.updateProjectionMatrix();
  }

  // ================= INTERACTION =================
  /** Find the best interaction candidate in front of the player. */
  findInteract() {
    const eyeY = this.pos.y + 1.6;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    let best: { label: string; act: () => void; score: number } | null = null;
    const consider = (x: number, y: number, z: number, maxD: number, label: string, act: () => void, bias = 0) => {
      const dx = x - this.pos.x, dz = z - this.pos.z, dy = y - eyeY;
      if (Math.abs(dy) > 2) return;
      const d = Math.hypot(dx, dz);
      if (d > maxD) return;
      const facing = d < 0.8 ? 1 : (dx * fx + dz * fz) / d;
      if (facing < 0.45) return;
      // lower score wins; a bias lets priority targets (the chapter-3 crew) win ties
      const score = d - facing - (bias ?? 0);
      if (!best || score < best.score) best = { label, act, score };
    };
    for (const p of this.pickups) {
      if (p.taken) continue;
      consider(p.def.x, p.def.y, p.def.z, 2.0, "Pick up " + this.pickupName(p.def.kind), () => this.takePickup(p));
    }
    for (const d of this.level.doors) {
      const cx = d.x, cz = d.z;
      const label = d.locked ? (this.keys.includes(d.keyId!) ? `Unlock ${d.label} (${KEY_NAMES[d.keyId!]})` : `${d.label} — Locked`) : `${d.open ? "Close" : "Open"} ${d.label}`;
      consider(cx, d.y + 1.2, cz, 2.0, label, () => this.useDoor(d));
    }
    for (const n of this.level.notes) consider(n.x, n.y, n.z, 1.8, "Read: " + n.title, () => { this.readNotes.add(n.id); this.ui.note = { title: n.title, text: n.text }; this.updateObjective(); audio.pickup(); });
    for (const e of this.level.exits) {
      if (this.stage >= 3 && e.x > 20) continue; // entrance barricade is torn open now
      consider(e.x, e.y + 1.2, e.z, 2.4, "Inspect exit", () => { this.toast(e.text); audio.bang(V(e.x, 1, e.z)); });
    }
    for (const c of this.companions) if (c.alive) consider(c.pos.x, c.pos.y + 1.4, c.pos.z, 2.4, `Talk to ${c.def.name}`, () => this.openCompanionDialog(c));
    // chapter 2: vehicles, NPCs
    if (this.stage >= 3) {
      for (const v of this.vehicles) {
        const K = VKINDS[v.kind];
        const locked = K.eng !== null && !this.vehiclesUnlocked;
        consider(v.pos.x, v.pos.y + 1, v.pos.z, K.r + 1.7, locked ? `${K.name} — dead battery (Ravi can fix it)` : `Ride ${K.name}`, () => {
          if (locked) { audio.click(); this.toast("No power. Ravi at the garage talks about jump packs..."); }
          else this.enterVehicle(v);
        });
      }
      for (const n of this.npcs) consider(n.def.x, 1.5, n.def.z, 2.6, `Talk to ${n.def.name}`, () => this.openDialog(n.def.id));
    }
    const R = this.level.radio.position;
    if (this.stage === 0) consider(R.x, R.y, R.z, 2.2, "USE MILITARY RADIO", () => this.playRadio());
    else consider(R.x, R.y, R.z, 2.2, "Radio (listening for orders...)", () => { audio.startStatic(0.2); setTimeout(() => audio.stopStatic(), 1200); this.toast("Only static. Bravo Squad hasn't transmitted yet."); });
    return best as { label: string; act: () => void } | null;
  }

  pickupName(k: PickupKind) {
    const m: Record<PickupKind, string> = {
      pistol: "M9 Pistol", shotgun: "Pump Shotgun", rifle: "M4 Assault Rifle", ammo_pistol: "9mm Ammo", ammo_shotgun: "Shotgun Shells", ammo_rifle: "5.56 Rifle Ammo",
      health: "Medkit", key_janitor: "Janitor's Key", key_principal: "Principal's Key", key_office: "Office Key", flashlight: "Flashlight",
      toolbox: "Ravi's Toolbox", city_map: "City Map", file_4b: "Medical File — Room 4B", helix_keycard: "Helix Keycard (Dr. E. Varma)",
    };
    return m[k];
  }

  takePickup(p: { def: PickupDef; mesh: THREE.Object3D; taken: boolean }) {
    const k = p.def.kind;
    if (k === "health") {
      this.medkits++;
      this.toast(`+1 Medkit (${this.medkits}) — press H / tap ✚ to heal`);
    } else if (k === "pistol" || k === "shotgun" || k === "rifle") {
      const def = WEAPONS[k];
      if (!this.owned.includes(k)) {
        this.owned.push(k);
        this.ammo[k].mag = def.mag;
        this.ammo[k].reserve += def.mag;
        this.toast(`Picked up ${def.name}`);
        this.equip(k);
      } else { this.ammo[k].reserve += def.pickupAmmo; this.toast(`+${def.pickupAmmo} ${def.name} ammo`); }
    } else if (k.startsWith("ammo_")) {
      const w = k.slice(5) as WeaponId;
      this.ammo[w].reserve += WEAPONS[w].pickupAmmo;
      this.toast(`+${WEAPONS[w].pickupAmmo} ${this.pickupName(k)}${this.owned.includes(w) ? "" : " (no weapon yet)"}`);
    } else if (k === "flashlight") {
      this.hasFlashlight = true;
      this.flashOn = true;
      this.toast("Flashlight acquired — toggle with F / LIGHT");
    } else if (k === "toolbox") {
      this.keys.push("toolbox");
      this.toast("Ravi's Toolbox — heavy. Bring it back to the garage.");
      if (this.mStatus(2) === 1) { this.mst[2] = 2; this.toast("MISSION: TOOLBOX RECOVERY — return to Ravi"); this.squadSay("mission_done", undefined, 2); this.updateObjective(); }
    } else if (k === "city_map") {
      this.keys.push("city_map");
      this.toast("CITY MAP acquired — press M / MAP to view it");
    } else {
      this.keys.push(k);
      this.toast(`Found ${KEY_NAMES[k]}`);
    }
    p.taken = true;
    this.scene.remove(p.mesh);
    if (!p.def.id.startsWith("drop")) this.taken.add(p.def.id);
    audio.pickup();
    this.updateObjective();
    this.save();
  }

  useDoor(d: Door) {
    if (d.locked) {
      if (d.keyId && this.keys.includes(d.keyId)) {
        d.locked = false;
        const lock = d.pivot.getObjectByName("lock");
        if (lock) lock.visible = false;
        audio.unlock();
        this.toast(`Unlocked ${d.label}`);
        d.open = true;
        audio.door(V(d.x, d.y + 1, d.z));
        this.save();
      } else {
        audio.click();
        this.toast(`${d.label} is locked. Requires ${KEY_NAMES[d.keyId!]}.`);
        this.squadSay("door_locked", undefined, 1);
      }
      return;
    }
    d.open = !d.open;
    audio.door(V(d.x, d.y + 1, d.z));
  }

  doorOpen = (id: string) => {
    const d = this.level.doors.find((x) => x.id === id);
    if (d && !d.locked && !d.open) { d.open = true; audio.bang(V(d.x, d.y + 1, d.z)); }
  };

  damagePlayer = (n: number) => {
    if (this.mode !== "playing" || this.health <= 0) return;
    if (this.driving) n *= 0.5; // a vehicle shields you a bit
    if (n <= 0) return;
    this.health -= n;
    this.ui.damageT = performance.now();
    this.shakeT = 0.25;
    audio.hurt();
    if (this.health < 35 && this.health > 0) this.squadSay("heal", "harsha", 1);
    if (this.health <= 0) {
      this.health = 0;
      this.mode = "dead";
      this.input.fire = false;
      if (this.driving) { audio.setEngine(null, 0); this.driving.speed = 0; this.driving = null; }
      if (document.pointerLockElement) document.exitPointerLock();
    }
  };

  zworld: ZWorld = {
    level: null as unknown as Level,
    playerPos: this.pos,
    playerAlive: true,
    flashlightOn: false,
    los: (a, b, c, d, e, f) => this.los(a, b, c, d, e, f),
    move: (p, dx, dz, r, h) => this.move(p, dx, dz, r, h),
    damagePlayer: (n) => this.damagePlayer(n),
    groan: (p, pitch, ag) => audio.groan(p, pitch, ag),
    bang: (p) => audio.bang(p),
    doorOpen: (id) => this.doorOpen(id),
    victims: [],
  };

  cworld!: CompanionWorld;
  makeCWorld() {
    this.cworld = {
      ...this.zworld,
      level: this.level,
      playerPos: this.pos,
      playerYaw: 0,
      playerMoving: false,
      playerInteracting: false,
      zombies: this.zombies,
      followOrderT: Infinity,
      shoot: (c, t, hit) => this.companionShoot(c, t, hit),
      event: (c, ev) => this.companionEvent(c, ev),
    };
  }

  // ================= MAIN LOOP =================
  loop = (t: number) => {
    if (!this.running) return;
    requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (t - (this.lastTime || t)) / 1000);
    this.lastTime = t;
    this.frames++;
    this.fpsT += dt;
    if (this.fpsT >= 1) { this.ui.fps = Math.round(this.frames / this.fpsT); this.frames = 0; this.fpsT = 0; }
    // adaptive quality: sustained low framerate steps the preset down once
    if (!this.autoDowngraded && this.mode === "playing") {
      this.perfSamples.push(dt);
      if (this.perfSamples.length > 90) {
        const avg = this.perfSamples.reduce((a, b) => a + b, 0) / this.perfSamples.length;
        this.perfSamples.length = 0;
        if (avg > 0.042 && this.quality > 0) {   // below ~24fps
          const next = this.quality - 1;
          this.autoDowngraded = true;
          this.setQuality(next);
          this.toast(`Graphics lowered to ${PRESETS[next].name} to keep the game smooth.`);
        }
      }
    }
    this.zworld.level = this.level;
    this.update(dt);
    this.render();
  };

  update(dt: number) {
    const lv = this.level;
    const now = performance.now() / 1000;
    // nearest-N light culling
    this.lightCullT -= dt;
    if (this.lightCullT <= 0) {
      this.lightCullT = 0.6;
      const cp = this.camera.position;
      if (this.lightBudget >= lv.flickerLights.length) {
        for (const fl of lv.flickerLights) fl.light.visible = true;
      } else {
        const sorted = lv.flickerLights
          .map((fl) => ({ fl, d: (fl.light.position.x - cp.x) ** 2 + (fl.light.position.y - cp.y) ** 2 + (fl.light.position.z - cp.z) ** 2 }))
          .sort((a, b) => a.d - b.d);
        sorted.forEach((s, i) => { s.fl.light.visible = i < this.lightBudget && s.d < 90 * 90; });
      }
    }
    for (const fl of lv.flickerLights) {
      if (!fl.light.visible) continue;
      if (fl.red) fl.light.intensity = fl.base * (0.62 + 0.42 * Math.sin(now * 3 + fl.phase));
      else fl.light.intensity = Math.random() < 0.02 ? fl.base * 0.4 : fl.base * (0.94 + Math.random() * 0.08);
    }
    if (this.mode === "playing" || this.mode === "paused" || this.mode === "dead") lv.lampMat.emissiveIntensity = Math.random() < 0.02 ? 0.2 : 0.9;
    // doors animate
    for (const d of lv.doors) {
      const target = d.open ? d.openAngle : 0;
      if (Math.abs(d.angle - target) > 0.001) {
        const s = Math.sign(target - d.angle);
        d.angle += s * Math.min(Math.abs(target - d.angle), dt * 3.5);
        d.pivot.rotation.y = d.angle;
      }
    }
    for (const p of this.pickups) {
      if (p.taken) continue;
      p.mesh.rotation.y += dt * 0.8;
      const g = p.mesh.getObjectByName("glint");
      if (g) g.scale.setScalar(0.6 + Math.abs(Math.sin(now * 3 + p.def.x)) * 0.8);
    }
    this.updateParticles(dt);
    this.updateTracers(dt);
    if (this.flashT > 0) this.flashT -= dt;
    // helicopter rotor + blink + fire flicker
    if (this.heli.visible) {
      this.heliRotor.rotation.y += dt * 28;
      this.heliTailRotor.rotation.x += dt * 45;
      this.blinkT += dt;
      this.heliBlink.visible = this.blinkT % 1 < 0.15;
    }
    const fg = lv.fireGlows;
    for (let i = 0; i < fg.length; i++) fg[i].opacity = 0.45 + 0.25 * Math.sin(now * 11 + i * 2.3) + 0.12 * Math.sin(now * 29 + i);
    if (this.dustPts.visible) this.updateDust(dt);
    // dynamic view distance & fog
    if (this.mode === "playing" || this.mode === "paused" || this.mode === "dead" || this.mode === "ending") {
      const cp = this.camera.position;
      const roofView = cp.y > 6.9;
      // ---- sun: outdoors only (school interior stays lamp-lit) ----
      const outdoors = cp.x > 32 || cp.x < -32 || Math.abs(cp.z) > 13 || roofView;
      const sunTarget = outdoors ? 1.35 : 0.0;
      this.sun.intensity += (sunTarget - this.sun.intensity) * Math.min(1, dt * 2.2);
      this.sun.visible = this.sun.intensity > 0.02;
      if (this.sun.visible) {
        this.sun.position.set(cp.x - 26, cp.y + 44, cp.z + 20);
        this.sun.target.position.set(cp.x + 8, 0, cp.z - 6);
        this.sun.target.updateMatrixWorld();
      }
      // Chapter 3's city is outdoors and moonlit — it needs a longer view and more light
      const greyWard = cp.x > 190;
      const wantFar = roofView ? 460 : greyWard ? 380 : this.quality === 0 ? 50 : 80;
      const wantFog = roofView ? 0.0040 : greyWard ? 0.0085 : 0.05;
      if (greyWard) {
        const wantHemi = 0.95;
        lv.hemi.intensity += (wantHemi - lv.hemi.intensity) * Math.min(1, dt * 2);
        if (this.lightBudget < 22) this.lightBudget = this.quality === 0 ? 10 : this.quality === 1 ? 22 : 99;
      }
      this.fogDen += (wantFog - this.fogDen) * Math.min(1, dt * 2.5);
      (this.scene.fog as THREE.FogExp2).density = this.fogDen;
      if (Math.abs(this.camera.far - wantFar) > 2) {
        this.camera.far += (wantFar - this.camera.far) * Math.min(1, dt * 3);
        this.camera.updateProjectionMatrix();
      }
    }
    if (this.mode === "intro" || this.mode === "radio" || this.mode === "ending") {
      this.updateCutscene(dt);
      this.updateActors(dt);
      this.ui.mode = this.mode;
      this.syncUI();
      return;
    }
    if (this.mode === "menu") {
      const a = now * 0.05;
      this.camera.position.set(24 + Math.sin(a) * 3, 2.2, Math.cos(a) * 6);
      this.camera.lookAt(10, 1.5, 0);
      this.ui.mode = this.mode;
      this.syncUI();
      return;
    }
    // NPC dialog freezes the world
    if (this.ui.dialog && this.mode === "playing") {
      for (const n of this.npcs) n.h.animWalk(dt * 0.25, 0.25, false);
      this.ui.mode = this.mode;
      this.syncUI();
      return;
    }
    // NPC idle + facing
    if (this.stage >= 3) {
      for (const n of this.npcs) {
        const d2 = (n.def.x - this.pos.x) ** 2 + (n.def.z - this.pos.z) ** 2;
        n.h.root.visible = d2 < 70 * 70;
        if (d2 > 70 * 70) continue;
        n.h.animWalk(dt * 0.25, 0.25, false);
        if (d2 < 100) {
          const want = Math.atan2(this.pos.x - n.def.x, this.pos.z - n.def.z);
          n.h.root.rotation.y += (((want - n.h.root.rotation.y + Math.PI * 3) % (Math.PI * 2)) - Math.PI) * Math.min(1, dt * 4);
        }
      }
    }
    if (this.mode === "playing") {
      // waypoint sprite
      const wp = this.waypointTarget();
      if (wp) {
        this.waySprite.visible = true;
        this.waySprite.position.set(wp.x, wp.y + 1.6 + Math.sin(now * 2.2) * 0.25, wp.z);
        const wd = Math.hypot(wp.x - this.pos.x, wp.z - this.pos.z);
        this.waySprite.scale.setScalar(THREE.MathUtils.clamp(1.2 + wd * 0.02, 1.2, 6));
        this.ui.waypoint = { label: wp.label, dist: Math.round(wd) };
      } else {
        this.waySprite.visible = false;
        this.ui.waypoint = null;
      }
      // leaving the school for the first time
      if (this.stage >= 3 && !this.leftSchool && this.pos.x > 31) {
        this.leftSchool = true;
        this.updateObjective();
        this.toast("The night air hits you. The city is burning on the horizon.");
      }
      // mission reach checks
      if (this.stage === 3) this.missionReachCheck();
      // harbor arrival
      if (this.stage === 3 && this.mStatus(4) >= 2 && this.pos.x > 304 && Math.abs(this.pos.z - 55) < 5) {
        this.playChapter2End();
        this.ui.mode = this.mode;
        this.syncUI();
        return;
      }
    }
    if (this.mode === "playing") {
      if (this.driving) this.updateDriving(dt);
      else this.updatePlayer(dt);
      this.updateCompanions(dt);
    }
    if (this.mode === "playing" || this.mode === "dead") {
      this.zworld.playerAlive = this.mode === "playing";
      this.zworld.flashlightOn = this.flashOn;
      for (const z of this.zombies) {
        const d2 = z.pos.distanceToSquared(this.pos);
        z.root.visible = d2 < 72 * 72;
        if (z.state !== "dead" && d2 > 50 * 50) continue;
        z.update(dt, this.zworld);
      }
      // separation between zombies
      const zs = this.zombies;
      for (let i = 0; i < zs.length; i++) {
        const a = zs[i];
        if (!a.alive) continue;
        for (let j = i + 1; j < zs.length; j++) {
          const b = zs[j];
          if (!b.alive || Math.abs(a.pos.y - b.pos.y) > 1) continue;
          const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, d2 = dx * dx + dz * dz;
          if (d2 < 0.36 && d2 > 1e-6) { const d = Math.sqrt(d2), push = (0.6 - d) / 2; a.pos.x -= (dx / d) * push; a.pos.z -= (dz / d) * push; b.pos.x += (dx / d) * push; b.pos.z += (dz / d) * push; }
        }
        // push the player out of zombies
        if (Math.abs(a.pos.y - this.pos.y) < 1) {
          const dx = this.pos.x - a.pos.x, dz = this.pos.z - a.pos.z, d2 = dx * dx + dz * dz;
          if (d2 < 0.42 && d2 > 1e-6) { const d = Math.sqrt(d2); this.move(this.pos, (dx / d) * (0.65 - d), (dz / d) * (0.65 - d), 0.35, 1.8); }
        }
      }
    }
    if (this.mode === "playing") {
      // the rooftop extraction call: survive long enough after the radio
      if (this.stage === 1 && (this.kills - this.killsAtRadio >= 8 || this.surviveTime > 150)) this.startRooftopCall();
      // reinforcements
      if (this.stage >= 1) {
        this.surviveTime += dt;
        this.spawnT -= dt;
        const alive = this.zombies.filter((z) => z.alive).length;
        if (this.spawnT <= 0) {
          this.spawnT = 14 + Math.random() * 8;
          if (alive < 12) {
            const pts = [V(26, 0, -6), V(26, 0, 6), V(16, 0, 0), V(14, 2, 11.5), V(16, 4, -0.5), V(-28, 4, 0), V(-28, 0, 0.5), V(12, 0, -8)];
            const far = pts.filter((p) => p.distanceTo(this.pos) > 12);
            for (let i = 0; i < 2 && far.length; i++) {
              const p = far.splice(Math.floor(Math.random() * far.length), 1)[0];
              const z = this.spawnZombie("r" + Math.random().toString(36).slice(2, 7), p, Math.floor(Math.random() * 5), Math.random() < 0.25);
              z.state = "investigate";
              z.lastKnown.copy(this.pos);
            }
          }
        }
      }
      this.ambientT -= dt;
      if (this.ambientT <= 0) { this.ambientT = 6 + Math.random() * 10; audio.distantGroan(); }
      if (this.health < 35) { this.heartT -= dt; if (this.heartT <= 0) { this.heartT = 0.9; audio.heartbeat(); } }
      this.saveT += dt;
      if (this.saveT > 30 && !this.zombies.some((z) => z.alive && (z.state === "chase" || z.state === "attack"))) { this.saveT = 0; this.save(); }
    }
    if (this.preset.vegetationWind) this.vegetation.update(dt, 1);
    if (this.dust) this.dust.update(dt, this.camera.position, 1);
    voice.update(dt);
    this.ui.vsub = voice.subtitle;
    this.ui.mode = this.mode;
    this.syncUI();
  }

  render() {
    this.flashlight.intensity = this.hasFlashlight && this.flashOn && (this.mode === "playing" || this.mode === "paused" || this.mode === "dead") ? 9 : 0;
    if (this.pipeline) {
      this.pipeline.render();
    } else {
      this.renderer.clear();
      this.renderer.render(this.scene, this.camera);
    }
    if ((this.mode === "playing" || this.mode === "paused") && !this.driving) {
      this.renderer.clearDepth();
      this.renderer.render(this.vmScene, this.vmCam);
    }
  }

  syncUI() {
    const u = this.ui;
    u.health = Math.ceil(this.health);
    u.weaponId = this.current;
    u.weapon = this.current ? WEAPONS[this.current].name : "UNARMED";
    u.mag = this.current ? this.ammo[this.current].mag : 0;
    u.reserve = this.current ? this.ammo[this.current].reserve : 0;
    u.owned = this.owned;
    u.keys = this.keys.map((k) => KEY_NAMES[k]);
    u.hasFlashlight = this.hasFlashlight;
    u.flashOn = this.flashOn;
    u.ads = this.adsT > 0.5;
    u.reloading = this.reloadT > 0;
    u.kills = this.kills;
    u.stage = this.stage;
    u.surviveTime = this.surviveTime;
    u.speed = this.driving ? Math.round(Math.abs(this.driving.speed) * 3.6) : null;
    u.hasMap = this.keys.includes("city_map");
    u.medkits = this.medkits;
    if (this.driving || this.mode !== "playing") u.lockOn = false;
    u.squadMode = this.squadMode;
    u.missions = MISSIONS.map((m) => ({ id: m.id, title: m.title, status: this.mStatus(m.id), giver: m.giver, prog: m.type === "kill" ? `${this.mkills[m.id] || 0}/${m.need}` : m.type === "fetch" ? (this.mStatus(m.id) >= 2 ? "item found" : "find item") : m.type === "reach" ? "reach location" : "" }));
    const nowS = performance.now() / 1000;
    u.squad = this.companions.map((c) => ({ name: c.def.name, hp: Math.round(c.chp), down: !c.alive, weapon: c.def.weapon, cd: Math.max(0, Math.ceil(60 - (nowS - (this.ammoCD[c.def.id] ?? -999)))) }));
  }
}
